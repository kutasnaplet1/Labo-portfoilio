# Spike na Androida

To jest instalowalna aplikacja Android oparta na Expo i natywnym `WebView`.
Nie jest to osobny, ręcznie przepisany interfejs IDE: otwiera opublikowaną
stronę Spike w aplikacji, więc korzysta z jej logowania, projektów, API i
zapisanych danych.

## Budowanie APK przez GitHub Actions

1. Rozpakuj zawartość ZIP-a do głównego katalogu repozytorium GitHub.
2. Wypchnij pliki na gałąź `main`.
3. Otwórz **Actions → Build APK → Run workflow**.
4. Po zakończeniu pobierz artefakt `spike-android-apk`. Zawiera on
   `spike-android.apk`.

Workflow jest w `.github/workflows/build-apk.yml`. Nie wymaga klucza API ani
innych sekretów do samego zbudowania. Adres opublikowanego serwera jest ustawiany w workflow jako
`EXPO_PUBLIC_DOMAIN`. Jeśli domena Spike się zmieni, zaktualizuj tę wartość.

## Podpis APK i ostrzeżenia Androida

Workflow obsługuje trwały podpis wydania, który pomaga utrzymać tę samą
tożsamość aplikacji przy kolejnych aktualizacjach. W ustawieniach repozytorium
GitHub dodaj sekrety Actions:

- `ANDROID_KEYSTORE_BASE64` — plik klucza JKS zakodowany jako Base64
- `ANDROID_KEYSTORE_PASSWORD` — hasło magazynu
- `ANDROID_KEY_ALIAS` — alias klucza
- `ANDROID_KEY_PASSWORD` — hasło klucza

Wygeneruj własny klucz poleceniem `keytool -genkeypair -v -keystore
spike-release.jks -alias spike -keyalg RSA -keysize 2048 -validity 10000`,
a plik zakoduj do Base64 lokalnie. Nie dodawaj klucza ani haseł do repozytorium
lub ZIP-a. Bez tych sekretów workflow nadal tworzy APK testowe podpisane
kluczem debug — może wtedy pojawić się ostrzeżenie przy instalacji. Podpis nie
gwarantuje, że Play Protect nie pokaże ostrzeżenia dla aplikacji instalowanej
spoza Google Play; nie da się tego bezpiecznie wyłączyć z poziomu aplikacji.

## Aktualizowanie bez odinstalowania

Zachowaj identyfikator `com.labo17dev.spike` i ten sam klucz podpisu, a przy
każdym nowym APK zwiększ `VERSION_CODE` w
`.github/workflows/build-apk.yml` (np. 2, potem 3). Możesz też zmienić `VERSION`
na kolejną wersję, np. `1.0.2`. Po zbudowaniu pobierz APK i zainstaluj go
bezpośrednio na obecnej aplikacji — Android powinien zaoferować aktualizację,
zachowując jej dane.

Nowy APK musi być podpisany dokładnie tym samym kluczem co zainstalowana wersja.
Zachowaj więc tę samą konfigurację podpisu, której użyto do obecnego APK. Nie
przełączaj się na inny klucz w trakcie aktualizacji — Android odrzuci wtedy
instalację na istniejącej aplikacji. Do publicznego wydania używaj trwałego,
prywatnego klucza przechowywanego wyłącznie w GitHub Actions Secrets; zmiana
klucza po instalacji wymaga odinstalowania starej wersji.

## Logowanie

Aplikacja korzysta z tej samej strony Spike i tego samego logowania Clerk.
Logowanie musi być dozwolone w osadzonym Android WebView przez konfigurację
Clerk. Jeżeli ekran logowania zgłosi blokadę osadzonej przeglądarki, trzeba
włączyć obsługę logowania w aplikacjach natywnych/WebView po stronie
konfiguracji dostawcy. Kod aplikacji nie obchodzi ani nie osłabia kontroli
dostępu.
Użytkownicy Spike nie muszą mieć konta Replit. Przy domyślnych danych Google
zgoda Google może jednak wyświetlać nazwę Replit; własną nazwę Spike ustawia
się przez własne dane OAuth Google w narzędziu **Users & Auth** w obszarze
**SSO providers**. Danych OAuth nie wpisuj do źródeł ani do ZIP-a.

## Ustawienia

- Nazwa aplikacji: `Spike`
- Identyfikator Androida: `com.labo17dev.spike`
- Wersja aktualizacji: `1.0.1` (kod wersji `2`)
- Ikona korzysta z postaci Spike z projektu.

APK nie jest dołączony do ZIP-a — workflow tworzy go przy każdym uruchomieniu.
