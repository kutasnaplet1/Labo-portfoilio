import { Feather } from "@expo/vector-icons";
import { StatusBar } from "expo-status-bar";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  Image,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import SpikeWebView from "../components/SpikeWebView";
import type {
  SpikeWebViewHandle,
  SpikeWebViewNavigation,
} from "../components/SpikeWebView.types";
import { useColors } from "../hooks/useColors";

type ConnectionState = "checking" | "online" | "offline" | "misconfigured";

const SERVER_URL = getServerUrl();
const SERVER_HOST = SERVER_URL ? new URL(SERVER_URL).hostname.toLowerCase() : "";
const AUTH_HOSTS = new Set([
  "accounts.google.com",
  "github.com",
  "appleid.apple.com",
  "login.microsoftonline.com",
]);

function getServerUrl(): string | null {
  const configuredDomain = process.env.EXPO_PUBLIC_DOMAIN?.trim();
  if (!configuredDomain) return null;

  try {
    const url = new URL(
      /^https?:\/\//i.test(configuredDomain)
        ? configuredDomain
        : `https://${configuredDomain}`,
    );
    if (url.protocol !== "https:" || url.username || url.password) return null;
    return url.origin;
  } catch {
    return null;
  }
}

export default function SpikeAndroidScreen() {
  const colors = useColors();
  const webViewRef = useRef<SpikeWebViewHandle>(null);
  const [connection, setConnection] = useState<ConnectionState>(
    SERVER_URL ? "checking" : "misconfigured",
  );
  const [retryCount, setRetryCount] = useState(0);
  const [webError, setWebError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [canGoBack, setCanGoBack] = useState(false);

  const checkServer = useCallback(async () => {
    if (!SERVER_URL) {
      setConnection("misconfigured");
      return;
    }

    setConnection("checking");
    setWebError(false);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12_000);

    try {
      const response = await fetch(`${SERVER_URL}/api/healthz`, {
        headers: { Accept: "application/json" },
        signal: controller.signal,
      });
      if (!response.ok) throw new Error("Server health check failed");
      const result = (await response.json()) as { status?: string };
      if (result.status !== "ok") throw new Error("Server is not ready");
      setConnection("online");
    } catch {
      setConnection("offline");
    } finally {
      clearTimeout(timeout);
    }
  }, []);

  useEffect(() => {
    if (Platform.OS === "web") return;
    void checkServer();
  }, [checkServer, retryCount]);

  useEffect(() => {
    if (Platform.OS !== "android") return;
    const subscription = BackHandler.addEventListener(
      "hardwareBackPress",
      () => {
        if (!canGoBack) return false;
        webViewRef.current?.goBack();
        return true;
      },
    );
    return () => subscription.remove();
  }, [canGoBack]);

  const retry = useCallback(() => {
    if (connection === "online" && !webError && webViewRef.current) {
      setLoading(true);
      webViewRef.current.reload();
      return;
    }
    setRetryCount((count) => count + 1);
  }, [connection, webError]);

  const handleNavigation = useCallback((navigation: SpikeWebViewNavigation) => {
    setCanGoBack(navigation.canGoBack);
  }, []);

  const handleRequest = useCallback(
    (request: { url: string }) => {
      try {
        const url = new URL(request.url);
        const host = url.hostname.toLowerCase();
        if (
          url.protocol === "https:" &&
          (host === SERVER_HOST || AUTH_HOSTS.has(host))
        ) {
          return true;
        }
        if (url.protocol === "mailto:" || url.protocol === "tel:") {
          void Linking.openURL(request.url).catch(() => undefined);
          return false;
        }
        if (url.protocol === "https:") {
          void Linking.openURL(request.url).catch(() => undefined);
        }
      } catch {
        // Invalid, file, and non-HTTPS navigations are deliberately blocked.
      }
      return false;
    },
    [],
  );

  const stateLabel =
    Platform.OS === "web"
      ? "Podgląd przeglądarkowy"
      : connection === "online" && !webError
        ? loading
          ? "Łączenie ze Spike"
          : "Połączono"
        : connection === "checking"
          ? "Sprawdzanie serwera"
          : "Brak połączenia";
  const isReady = connection === "online" && !webError;

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <View style={styles.brand}>
          <View style={[styles.logoFrame, { backgroundColor: colors.card }]}>
            <Image
              source={require("../assets/images/adaptive-icon.png")}
              resizeMode="cover"
              style={styles.logoImage}
            />
          </View>
          <View>
            <Text style={[styles.brandName, { color: colors.foreground }]}>
              Spike
            </Text>
            <View style={styles.statusLine}>
              <View
                style={[
                  styles.statusDot,
                  {
                    backgroundColor:
                      isReady && !loading
                        ? colors.primary
                        : connection === "offline"
                          ? colors.destructive
                          : colors.mutedForeground,
                  },
                ]}
              />
              <Text style={[styles.statusText, { color: colors.mutedForeground }]}>
                {stateLabel}
              </Text>
            </View>
          </View>
        </View>
        <View style={styles.actions}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Wróć"
            disabled={!canGoBack}
            onPress={() => webViewRef.current?.goBack()}
            style={({ pressed }) => [
              styles.iconButton,
              { opacity: !canGoBack ? 0.35 : pressed ? 0.65 : 1 },
            ]}
            testID="web-back"
          >
            <Feather name="arrow-left" size={19} color={colors.foreground} />
          </Pressable>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Odśwież"
            onPress={retry}
            style={({ pressed }) => [
              styles.iconButton,
              { opacity: pressed ? 0.65 : 1 },
            ]}
            testID="web-refresh"
          >
            <Feather name="refresh-cw" size={17} color={colors.foreground} />
          </Pressable>
        </View>
      </View>

      <View style={styles.content}>
        {Platform.OS === "web" ? (
          <PreviewNotice
            colors={colors}
            onOpen={() => {
              if (SERVER_URL) void Linking.openURL(SERVER_URL);
            }}
            serverUrl={SERVER_URL}
          />
        ) : connection === "checking" ? (
          <ConnectionNotice colors={colors} kind="checking" onRetry={retry} />
        ) : connection !== "online" ? (
          <ConnectionNotice
            colors={colors}
            kind={connection}
            onRetry={retry}
          />
        ) : webError ? (
          <ConnectionNotice colors={colors} kind="site-error" onRetry={retry} />
        ) : (
          <>
            {loading && (
              <View
                pointerEvents="none"
                style={[styles.progressTrack, { backgroundColor: colors.muted }]}
              >
                <View
                  style={[
                    styles.progressBar,
                    {
                      backgroundColor: colors.primary,
                      width: `${Math.max(8, progress * 100)}%`,
                    },
                  ]}
                />
              </View>
            )}
            <SpikeWebView
              ref={webViewRef}
              source={{ uri: SERVER_URL! }}
              originWhitelist={["https://*"]}
              javaScriptEnabled
              domStorageEnabled
              sharedCookiesEnabled
              thirdPartyCookiesEnabled
              cacheEnabled
              pullToRefreshEnabled
              setSupportMultipleWindows={false}
              mixedContentMode="never"
              allowFileAccess={false}
              allowFileAccessFromFileURLs={false}
              allowUniversalAccessFromFileURLs={false}
              downloadingMessage="Pobieranie pliku"
              lackPermissionToDownloadMessage="Brak uprawnień do pobrania pliku"
              onShouldStartLoadWithRequest={handleRequest}
              onNavigationStateChange={handleNavigation}
              onOpenWindow={(event) =>
                handleRequest({ url: event.nativeEvent.targetUrl })
              }
              onLoadStart={() => {
                setLoading(true);
                setWebError(false);
              }}
              onLoadProgress={({ nativeEvent }) =>
                setProgress(nativeEvent.progress)
              }
              onLoadEnd={() => {
                setLoading(false);
                setProgress(1);
              }}
              onError={() => {
                setLoading(false);
                setWebError(true);
              }}
              startInLoadingState
              renderLoading={() => (
                <View
                  style={[
                    styles.webLoading,
                    { backgroundColor: colors.background },
                  ]}
                >
                  <ActivityIndicator size="large" color={colors.primary} />
                  <Text
                    style={[
                      styles.webLoadingText,
                      { color: colors.mutedForeground },
                    ]}
                  >
                    Ładowanie Spike…
                  </Text>
                </View>
              )}
              style={[styles.webView, { backgroundColor: colors.background }]}
            />
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

type NoticeColors = ReturnType<typeof useColors>;

function ConnectionNotice({
  colors,
  kind,
  onRetry,
}: {
  colors: NoticeColors;
  kind: "checking" | "offline" | "misconfigured" | "site-error";
  onRetry: () => void;
}) {
  const isChecking = kind === "checking";
  const title =
    kind === "offline"
      ? "Serwer Spike jest niedostępny"
      : kind === "misconfigured"
        ? "Brak konfiguracji serwera"
        : kind === "site-error"
          ? "Nie udało się wczytać Spike"
          : "Sprawdzam połączenie";
  const message =
    kind === "offline"
      ? "Nie udało się połączyć z API Spike. Sprawdź internet i spróbuj ponownie."
      : kind === "misconfigured"
        ? "Ta wersja aplikacji nie ma ustawionego adresu serwera. Ustaw EXPO_PUBLIC_DOMAIN podczas budowania."
        : kind === "site-error"
          ? "Serwer odpowiada, ale strona nie została wczytana. Spróbuj ponownie."
          : "Weryfikuję dostępność serwera przed otwarciem projektu.";

  return (
    <View style={styles.notice}>
      <View
        style={[
          styles.noticeIcon,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        {isChecking ? (
          <ActivityIndicator size="small" color={colors.primary} />
        ) : (
          <Feather
            name={kind === "misconfigured" ? "settings" : "cloud-off"}
            size={22}
            color={kind === "offline" ? colors.destructive : colors.primary}
          />
        )}
      </View>
      <Text style={[styles.noticeTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      <Text style={[styles.noticeMessage, { color: colors.mutedForeground }]}>
        {message}
      </Text>
      {!isChecking && kind !== "misconfigured" && (
        <Pressable
          accessibilityRole="button"
          onPress={onRetry}
          style={({ pressed }) => [
            styles.retryButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
          ]}
          testID="connection-retry"
        >
          <Feather name="refresh-cw" size={15} color={colors.primaryForeground} />
          <Text style={[styles.retryLabel, { color: colors.primaryForeground }]}>
            Spróbuj ponownie
          </Text>
        </Pressable>
      )}
    </View>
  );
}

function PreviewNotice({
  colors,
  serverUrl,
  onOpen,
}: {
  colors: NoticeColors;
  serverUrl: string | null;
  onOpen: () => void;
}) {
  return (
    <View style={styles.notice}>
      <View
        style={[
          styles.noticeIcon,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <Feather name="smartphone" size={22} color={colors.primary} />
      </View>
      <Text style={[styles.noticeTitle, { color: colors.foreground }]}>
        Spike na Androidzie
      </Text>
      <Text style={[styles.noticeMessage, { color: colors.mutedForeground }]}>
        Podgląd przeglądarkowy pokazuje tylko powłokę. W aplikacji Android
        otworzy się pełny Spike z logowaniem, projektami i połączeniem z
        serwerem.
      </Text>
      {serverUrl && (
        <Pressable
          accessibilityRole="button"
          onPress={onOpen}
          style={({ pressed }) => [
            styles.retryButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
          ]}
          testID="open-spike-web"
        >
          <Feather name="external-link" size={16} color={colors.primaryForeground} />
          <Text style={[styles.retryLabel, { color: colors.primaryForeground }]}>
            Otwórz Spike w przeglądarce
          </Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    minHeight: 58,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  brand: { flexDirection: "row", alignItems: "center", gap: 10 },
  logoFrame: {
    width: 34,
    height: 34,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  logoImage: { width: 34, height: 34, borderRadius: 11 },
  brandName: { fontFamily: "Inter_600SemiBold", fontSize: 14, lineHeight: 19 },
  statusLine: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 1 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontFamily: "Inter_400Regular", fontSize: 10, lineHeight: 13 },
  actions: { flexDirection: "row", alignItems: "center", gap: 3 },
  iconButton: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
  },
  content: { flex: 1 },
  webView: { flex: 1 },
  progressTrack: { height: 2 },
  progressBar: { height: 2 },
  webLoading: {
    ...StyleSheet.absoluteFill,
    zIndex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  webLoadingText: { fontFamily: "Inter_500Medium", fontSize: 13 },
  notice: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 28,
  },
  noticeIcon: {
    height: 54,
    width: 54,
    borderRadius: 18,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 19,
  },
  noticeTitle: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 18,
    lineHeight: 25,
    textAlign: "center",
  },
  noticeMessage: {
    maxWidth: 340,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 20,
    textAlign: "center",
    marginTop: 8,
  },
  retryButton: {
    minHeight: 44,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
    paddingHorizontal: 16,
    borderRadius: 13,
    marginTop: 20,
  },
  retryLabel: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
});
