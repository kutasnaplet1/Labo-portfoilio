import React from "react";
import { WebView as WebViewComponent } from "react-native-webview";
import type {
  SpikeWebViewComponent,
  SpikeWebViewHandle,
  SpikeWebViewProps,
} from "./SpikeWebView.types";

const NativeWebView =
  WebViewComponent as unknown as SpikeWebViewComponent;

const SpikeWebView = React.forwardRef<
  SpikeWebViewHandle,
  SpikeWebViewProps
>((props, ref) => <NativeWebView {...props} ref={ref} />);

SpikeWebView.displayName = "SpikeWebView";

export default SpikeWebView;
