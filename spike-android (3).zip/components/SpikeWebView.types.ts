import type { ReactElement, RefAttributes } from "react";
import type { StyleProp, ViewStyle } from "react-native";

export type SpikeWebViewHandle = {
  goBack: () => void;
  reload: () => void;
};

export type SpikeWebViewNavigation = { canGoBack: boolean };

export type SpikeWebViewProps = {
  source: { uri: string };
  originWhitelist: string[];
  javaScriptEnabled?: boolean;
  domStorageEnabled?: boolean;
  sharedCookiesEnabled?: boolean;
  thirdPartyCookiesEnabled?: boolean;
  cacheEnabled?: boolean;
  pullToRefreshEnabled?: boolean;
  setSupportMultipleWindows?: boolean;
  mixedContentMode?: "never" | "always" | "compatibility";
  allowFileAccess?: boolean;
  allowFileAccessFromFileURLs?: boolean;
  allowUniversalAccessFromFileURLs?: boolean;
  downloadingMessage?: string;
  lackPermissionToDownloadMessage?: string;
  onShouldStartLoadWithRequest?: (request: { url: string }) => boolean;
  onNavigationStateChange?: (navigation: SpikeWebViewNavigation) => void;
  onLoadStart?: () => void;
  onLoadProgress?: (event: { nativeEvent: { progress: number } }) => void;
  onLoadEnd?: () => void;
  onError?: () => void;
  onOpenWindow?: (event: { nativeEvent: { targetUrl: string } }) => void;
  startInLoadingState?: boolean;
  renderLoading?: () => ReactElement;
  style?: StyleProp<ViewStyle>;
};

export type SpikeWebViewComponent = React.ForwardRefExoticComponent<
  SpikeWebViewProps & RefAttributes<SpikeWebViewHandle>
>;
