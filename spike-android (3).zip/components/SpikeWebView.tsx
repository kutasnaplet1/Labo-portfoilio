import React from "react";
import type {
  SpikeWebViewHandle,
  SpikeWebViewProps,
} from "./SpikeWebView.types";

const SpikeWebView = React.forwardRef<
  SpikeWebViewHandle,
  SpikeWebViewProps
>(() => null);

SpikeWebView.displayName = "SpikeWebView";

export default SpikeWebView;
