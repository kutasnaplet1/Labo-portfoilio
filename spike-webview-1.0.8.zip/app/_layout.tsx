import React, { useEffect, useState } from "react";
import { ClerkProvider } from "@clerk/expo";
import { tokenCache } from "@clerk/expo/token-cache";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { ErrorBoundary } from "../components/ErrorBoundary";
import { SpikeWebViewApp } from "../components/SpikeWebViewApp";
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { SERVER_ORIGIN } from "../lib/api";
import { useColors } from "../hooks/useColors";

void SplashScreen.preventAutoHideAsync();

function BootstrapMessage({
  error,
  retry,
}: {
  error: string;
  retry: () => void;
}) {
  const colors = useColors();
  return (
    <View style={[styles.bootstrap, { backgroundColor: colors.background }]}>
      <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
      <Text style={[styles.message, { color: colors.mutedForeground }]}>
        {error}
      </Text>
      <Pressable
        onPress={retry}
        style={[styles.retry, { backgroundColor: colors.primary }]}
      >
        <Text style={[styles.retryText, { color: colors.primaryForeground }]}>
          Spróbuj ponownie
        </Text>
      </Pressable>
    </View>
  );
}

function WebPreviewNotice() {
  const colors = useColors();
  return (
    <View
      style={[
        styles.bootstrap,
        styles.webPreview,
        { backgroundColor: colors.background },
      ]}
    >
      <Text style={[styles.brand, { color: colors.foreground }]}>
        Spike Android
      </Text>
      <Text style={[styles.message, { color: colors.mutedForeground }]}>
        To natywna aplikacja Expo. Logowanie Clerk, projekty i pliki są dostępne
        w APK na Androidzie; podgląd przeglądarkowy nie uruchamia aplikacji ani
        nie pokazuje strony Spike w WebView.
      </Text>
    </View>
  );
}

function AuthBootstrap() {
  const useWebView = process.env.EXPO_PUBLIC_APP_MODE === "webview";
  const [authConfig, setAuthConfig] = useState<{
    publishableKey: string;
    proxyUrl?: string;
  } | null>(null);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);
    if (Platform.OS === "web" || useWebView) {
      clearTimeout(timeout);
      return () => {
        cancelled = true;
        controller.abort();
      };
    }
    if (!SERVER_ORIGIN) {
      setError(
        "Brak adresu serwera. Sprawdź konfigurację EXPO_PUBLIC_DOMAIN w buildzie APK.",
      );
      return () => {
        cancelled = true;
        clearTimeout(timeout);
      };
    }
    setError("");
    void fetch(`${SERVER_ORIGIN}/api/auth/public-config`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        const body = (await response.json()) as {
          publishableKey?: string;
          proxyUrl?: string;
          error?: string;
        };
        if (!response.ok || !body.publishableKey?.startsWith("pk_")) {
          throw new Error(
            body.error || "Serwer nie udostępnił konfiguracji logowania.",
          );
        }
        if (!cancelled) {
          setAuthConfig({
            publishableKey: body.publishableKey,
            proxyUrl: body.proxyUrl,
          });
        }
      })
      .catch((cause) => {
        if (!cancelled)
          setError(
            cause instanceof Error
              ? cause.message
              : "Nie udało się połączyć z serwerem Spike.",
          );
      })
      .finally(() => clearTimeout(timeout));
    return () => {
      cancelled = true;
      controller.abort();
      clearTimeout(timeout);
    };
  }, [attempt, useWebView]);

  if (Platform.OS === "web") return <WebPreviewNotice />;
  if (useWebView) return <SpikeWebViewApp />;
  if (!authConfig) {
    return (
      <BootstrapMessage
        error={error || "Łączenie z serwerem Spike…"}
        retry={() => setAttempt((value) => value + 1)}
      />
    );
  }
  return (
    <ClerkProvider
      publishableKey={authConfig.publishableKey}
      tokenCache={tokenCache}
      proxyUrl={authConfig.proxyUrl}
    >
      <Stack screenOptions={{ headerShown: false, animation: "fade" }}>
        <Stack.Screen name="index" />
      </Stack>
    </ClerkProvider>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });
  useEffect(() => {
    if (fontsLoaded || fontError) void SplashScreen.hideAsync();
  }, [fontsLoaded, fontError]);
  if (!fontsLoaded && !fontError) return null;
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <KeyboardProvider>
          <ErrorBoundary>
            <StatusBar style="light" />
            <AuthBootstrap />
          </ErrorBoundary>
        </KeyboardProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  bootstrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 28,
  },
  webPreview: { paddingTop: 67, paddingBottom: 34 },
  brand: { fontFamily: "Inter_700Bold", fontSize: 28 },
  message: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    lineHeight: 19,
    textAlign: "center",
    marginTop: 10,
  },
  retry: {
    minHeight: 42,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 18,
    marginTop: 18,
  },
  retryText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
});
