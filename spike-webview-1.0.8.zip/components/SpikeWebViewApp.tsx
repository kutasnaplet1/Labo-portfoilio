import { Feather } from "@expo/vector-icons";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  Image,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  type ViewProps,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import WebView from "react-native-webview";
import { useColors } from "../hooks/useColors";

const configuredUrl = process.env.EXPO_PUBLIC_WEBVIEW_URL?.trim() || "";
type WebViewHandle = { goBack: () => void; reload: () => void };
type WebViewNavigation = { url: string; canGoBack: boolean };
type SpikeWebViewProps = ViewProps & {
  ref?: React.Ref<WebViewHandle>;
  source: { uri: string };
  originWhitelist?: readonly string[];
  onNavigationStateChange?: (event: WebViewNavigation) => void;
  onFileDownload?: (event: { nativeEvent: { downloadUrl: string } }) => void;
  onShouldStartLoadWithRequest?: (event: { url: string }) => boolean;
  onLoadStart?: () => void;
  onLoadEnd?: () => void;
  onLoadProgress?: (event: { nativeEvent: { progress: number } }) => void;
  onError?: (event: { nativeEvent: { description: string } }) => void;
  javaScriptEnabled?: boolean;
  javaScriptCanOpenWindowsAutomatically?: boolean;
  thirdPartyCookiesEnabled?: boolean;
  sharedCookiesEnabled?: boolean;
  cacheEnabled?: boolean;
  domStorageEnabled?: boolean;
  mixedContentMode?: "never" | "always" | "compatibility";
  allowFileAccess?: boolean;
  allowUniversalAccessFromFileURLs?: boolean;
  setSupportMultipleWindows?: boolean;
  allowsBackForwardNavigationGestures?: boolean;
  pullToRefreshEnabled?: boolean;
};
const CompatibleWebView =
  WebView as unknown as React.ComponentType<SpikeWebViewProps>;

export function SpikeWebViewApp() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const webView = useRef<WebViewHandle>(null);
  const [navigation, setNavigation] = useState<WebViewNavigation | null>(null);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");

  const target = useMemo(() => {
    try {
      const parsed = new URL(configuredUrl);
      if (parsed.protocol !== "https:" || parsed.username || parsed.password)
        return null;
      return parsed;
    } catch {
      return null;
    }
  }, []);

  const canGoBack = Boolean(navigation?.canGoBack);
  useEffect(() => {
    if (Platform.OS !== "android") return;
    const subscription = BackHandler.addEventListener(
      "hardwareBackPress",
      () => {
        if (canGoBack) {
          webView.current?.goBack();
          return true;
        }
        return false;
      },
    );
    return () => subscription.remove();
  }, [canGoBack]);

  const allowNavigation = (request: { url: string }) => {
    try {
      const url = new URL(request.url);
      if (target && url.origin === target.origin && url.protocol === "https:")
        return true;
      const host = url.hostname.toLowerCase();
      const trustedClerkHost =
        host === "clerk.accounts.dev" ||
        host.endsWith(".clerk.accounts.dev") ||
        host === "accounts.clerk.com" ||
        host.endsWith(".clerk.com");
      if (url.protocol === "https:" && trustedClerkHost) return true;
      if (url.protocol === "mailto:" || url.protocol === "tel:") {
        void Linking.openURL(request.url).catch(() => undefined);
        return false;
      }
      if (url.protocol === "https:")
        void Linking.openURL(request.url).catch(() => undefined);
      return false;
    } catch {
      return false;
    }
  };

  const retry = () => {
    setError("");
    setProgress(0);
    setLoading(true);
    webView.current?.reload();
  };

  if (!target) {
    return (
      <View
        style={[
          styles.center,
          { backgroundColor: colors.background, paddingTop: insets.top },
        ]}
      >
        <Image
          source={require("../assets/images/icon.png")}
          style={styles.errorLogo}
          resizeMode="contain"
        />
        <Text style={[styles.title, { color: colors.foreground }]}>Spike</Text>
        <Text style={[styles.message, { color: colors.mutedForeground }]}>
          W tym buildzie nie ustawiono poprawnego adresu strony. Sprawdź wartość
          EXPO_PUBLIC_WEBVIEW_URL w workflow GitHub Actions.
        </Text>
      </View>
    );
  }

  return (
    <View
      style={[
        styles.screen,
        { backgroundColor: colors.background, paddingTop: insets.top },
      ]}
    >
      <View
        style={[
          styles.header,
          { backgroundColor: colors.card, borderBottomColor: colors.border },
        ]}
      >
        <Pressable
          onPress={() => canGoBack && webView.current?.goBack()}
          disabled={!canGoBack}
          style={styles.headerAction}
          accessibilityRole="button"
          accessibilityLabel="Wróć"
        >
          <Feather
            name="arrow-left"
            size={19}
            color={canGoBack ? colors.foreground : colors.mutedForeground}
          />
        </Pressable>
        <Image
          source={require("../assets/images/icon.png")}
          style={styles.logo}
          resizeMode="contain"
          accessibilityLabel="Spike"
        />
        <View style={styles.brandCopy}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            Spike
          </Text>
          <View style={styles.statusRow}>
            <View
              style={[
                styles.statusDot,
                {
                  backgroundColor: error
                    ? colors.destructive
                    : loading
                      ? colors.mutedForeground
                      : colors.primary,
                },
              ]}
            />
            <Text
              numberOfLines={1}
              style={[styles.status, { color: colors.mutedForeground }]}
            >
              {error ? "Brak połączenia" : loading ? "Łączenie…" : "Połączono"}
            </Text>
          </View>
        </View>
        {loading ? (
          <ActivityIndicator
            size="small"
            color={colors.primary}
            style={styles.headerAction}
          />
        ) : (
          <Pressable
            onPress={retry}
            style={styles.headerAction}
            accessibilityRole="button"
            accessibilityLabel="Odśwież stronę"
          >
            <Feather name="refresh-cw" size={17} color={colors.foreground} />
          </Pressable>
        )}
      </View>
      {loading ? (
        <View
          style={[styles.progressTrack, { backgroundColor: colors.border }]}
        >
          <View
            style={[
              styles.progress,
              {
                backgroundColor: colors.primary,
                width: `${Math.round(progress * 100)}%`,
              },
            ]}
          />
        </View>
      ) : null}
      <CompatibleWebView
        ref={webView}
        source={{ uri: target.href }}
        originWhitelist={["*"]}
        onShouldStartLoadWithRequest={allowNavigation}
        onNavigationStateChange={setNavigation}
        onLoadStart={() => {
          setLoading(true);
          setError("");
        }}
        onLoadEnd={() => {
          setLoading(false);
          setProgress(1);
        }}
        onLoadProgress={(event) => setProgress(event.nativeEvent.progress)}
        onError={(event) => {
          setLoading(false);
          setError(
            event.nativeEvent.description ||
              "Nie udało się połączyć ze stroną Spike.",
          );
        }}
        onFileDownload={(event) => {
          void Linking.openURL(event.nativeEvent.downloadUrl).catch(() =>
            setError("Nie udało się otworzyć pobieranego pliku."),
          );
        }}
        javaScriptEnabled
        domStorageEnabled
        sharedCookiesEnabled
        thirdPartyCookiesEnabled
        cacheEnabled
        mixedContentMode="never"
        allowFileAccess={false}
        allowUniversalAccessFromFileURLs={false}
        javaScriptCanOpenWindowsAutomatically={false}
        setSupportMultipleWindows={false}
        allowsBackForwardNavigationGestures
        style={[styles.webView, { backgroundColor: colors.background }]}
        pullToRefreshEnabled={Platform.OS === "android"}
      />
      {error ? (
        <View
          style={[styles.errorOverlay, { backgroundColor: colors.background }]}
        >
          <Feather name="wifi-off" size={30} color={colors.mutedForeground} />
          <Text style={[styles.errorTitle, { color: colors.foreground }]}>
            Nie udało się wczytać Spike
          </Text>
          <Text style={[styles.message, { color: colors.mutedForeground }]}>
            {error}
          </Text>
          <Pressable
            onPress={retry}
            style={[styles.retryButton, { backgroundColor: colors.primary }]}
            accessibilityRole="button"
          >
            <Feather
              name="refresh-cw"
              size={15}
              color={colors.primaryForeground}
            />
            <Text
              style={[styles.retryLabel, { color: colors.primaryForeground }]}
            >
              Spróbuj ponownie
            </Text>
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 28,
  },
  header: {
    height: 58,
    borderBottomWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 7,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
  },
  headerAction: {
    width: 40,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
  },
  logo: { width: 32, height: 32, borderRadius: 9 },
  errorLogo: { width: 56, height: 56, marginBottom: 12 },
  brandCopy: { flex: 1, justifyContent: "center", minWidth: 0 },
  title: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    marginTop: 2,
  },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  status: { fontFamily: "Inter_400Regular", fontSize: 10 },
  progressTrack: { height: 2 },
  progress: { height: 2 },
  webView: { flex: 1 },
  errorOverlay: {
    ...StyleSheet.absoluteFill,
    top: 58,
    alignItems: "center",
    justifyContent: "center",
    padding: 26,
  },
  errorTitle: { fontFamily: "Inter_600SemiBold", fontSize: 17, marginTop: 13 },
  message: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    lineHeight: 18,
    textAlign: "center",
    marginTop: 8,
  },
  retryButton: {
    minHeight: 42,
    borderRadius: 12,
    paddingHorizontal: 16,
    marginTop: 18,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  retryLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
});
