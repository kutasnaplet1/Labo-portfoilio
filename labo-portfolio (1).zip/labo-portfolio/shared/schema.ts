import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const CATEGORIES = [
  "websites",
  "video-edit",
  "graphics",
  "music",
  "other",
] as const;

export type Category = (typeof CATEGORIES)[number];

export const portfolioItemSchema = z.object({
  id: z.string(),
  title: z.string().min(1),
  description: z.string().default(""),
  category: z.enum(CATEGORIES),
  previewUrl: z.string().min(1),
  thumbnailUrl: z.string().optional().default(""),
  createdAt: z.number(),
});

export const insertPortfolioItemSchema = portfolioItemSchema.omit({
  id: true,
  createdAt: true,
}).extend({
  email: z.string().email(),
});

export type PortfolioItem = z.infer<typeof portfolioItemSchema>;
export type InsertPortfolioItem = z.infer<typeof insertPortfolioItemSchema>;
