import { useState, useMemo, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, LogOut, Sparkles } from "lucide-react";
import type { PortfolioItem, Category } from "@shared/schema";
import { CATEGORIES } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PortfolioCard } from "@/components/portfolio-card";
import { PreviewModal } from "@/components/preview-modal";
import { UploadDialog, CATEGORY_LABELS } from "@/components/upload-dialog";
import { AdminGate } from "@/components/admin-gate";
import { isOwner, clearAdminEmail } from "@/lib/admin";
import { useToast } from "@/hooks/use-toast";

type Filter = Category | "all";

export default function Home() {
  const [filter, setFilter] = useState<Filter>("all");
  const [preview, setPreview] = useState<PortfolioItem | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [gateOpen, setGateOpen] = useState(false);
  const [admin, setAdmin] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setAdmin(isOwner());
  }, []);

  const { data: items = [], isLoading } = useQuery<PortfolioItem[]>({
    queryKey: ["/api/portfolio"],
  });

  const filtered = useMemo(
    () => (filter === "all" ? items : items.filter((i) => i.category === filter)),
    [items, filter],
  );

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: items.length };
    for (const cat of CATEGORIES) c[cat] = 0;
    for (const it of items) c[it.category] = (c[it.category] ?? 0) + 1;
    return c;
  }, [items]);

  return (
    <div className="min-h-screen">
      <header className="border-b border-border/40 backdrop-blur-md sticky top-0 z-30 bg-background/70">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <div className="flex items-center gap-3">
            <motion.div
              initial={{ rotate: -10, scale: 0.8 }}
              animate={{ rotate: 0, scale: 1 }}
              className="flex h-10 w-10 items-center justify-center rounded-xl brand-gradient text-white shadow-lg shadow-primary/30"
            >
              <Sparkles className="h-5 w-5" />
            </motion.div>
            <div>
              <h1 className="text-xl font-bold leading-none brand-gradient-text">
                Łabo
              </h1>
              <p className="text-xs text-muted-foreground">
                portfolio · projects · ideas
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {admin ? (
              <>
                <Button
                  size="sm"
                  onClick={() => setUploadOpen(true)}
                  data-testid="button-add"
                >
                  <Plus className="mr-1.5 h-4 w-4" /> New work
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    clearAdminEmail();
                    setAdmin(false);
                    toast({ title: "Logged out" });
                  }}
                  data-testid="button-logout"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setGateOpen(true)}
                data-testid="button-admin"
              >
                Author mode
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-10">
        <section className="mb-12 text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold sm:text-6xl"
          >
            I build, edit &{" "}
            <span className="brand-gradient-text">make things.</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mx-auto mt-4 max-w-xl text-lg text-muted-foreground"
          >
            A little playground of websites, edits, graphics and other projects
            by Łabo. Hit{" "}
            <span className="font-semibold text-foreground">Preview</span> on
            anything to take a look.
          </motion.p>
        </section>

        <div className="mb-8 flex flex-wrap items-center justify-center gap-2">
          <FilterPill
            active={filter === "all"}
            onClick={() => setFilter("all")}
            label="Everything"
            count={counts.all}
          />
          {CATEGORIES.map((cat) => (
            <FilterPill
              key={cat}
              active={filter === cat}
              onClick={() => setFilter(cat)}
              label={CATEGORY_LABELS[cat]}
              count={counts[cat] ?? 0}
            />
          ))}
        </div>

        {isLoading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-72 rounded-2xl" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            isAdmin={admin}
            onAdd={() => setUploadOpen(true)}
            onUnlock={() => setGateOpen(true)}
          />
        ) : (
          <motion.div
            layout
            className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
          >
            <AnimatePresence mode="popLayout">
              {filtered.map((item) => (
                <PortfolioCard
                  key={item.id}
                  item={item}
                  isAdmin={admin}
                  onPreview={setPreview}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </main>

      <footer className="border-t border-border/40 py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} Łabo · made with care
      </footer>

      <PreviewModal item={preview} onClose={() => setPreview(null)} />
      <UploadDialog open={uploadOpen} onOpenChange={setUploadOpen} />
      <AdminGate
        open={gateOpen}
        onOpenChange={setGateOpen}
        onUnlock={() => setAdmin(true)}
      />
    </div>
  );
}

function FilterPill({
  active,
  onClick,
  label,
  count,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  count: number;
}) {
  return (
    <button
      onClick={onClick}
      className={`relative rounded-full border px-4 py-1.5 text-sm font-medium transition ${
        active
          ? "border-transparent text-white"
          : "border-border bg-card hover:bg-muted"
      }`}
      data-testid={`filter-${label}`}
    >
      {active && (
        <motion.span
          layoutId="filter-bg"
          className="absolute inset-0 -z-10 rounded-full brand-gradient"
          transition={{ type: "spring", stiffness: 400, damping: 30 }}
        />
      )}
      {label}
      <span
        className={`ml-2 rounded-full px-1.5 text-xs ${
          active ? "bg-white/25" : "bg-muted text-muted-foreground"
        }`}
      >
        {count}
      </span>
    </button>
  );
}

function EmptyState({
  isAdmin,
  onAdd,
  onUnlock,
}: {
  isAdmin: boolean;
  onAdd: () => void;
  onUnlock: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto max-w-md rounded-2xl border border-dashed bg-card/50 p-10 text-center"
    >
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl brand-gradient text-white">
        <Sparkles className="h-7 w-7" />
      </div>
      <h3 className="text-lg font-semibold">Nothing here yet</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        {isAdmin
          ? "Add your first project to start building the portfolio."
          : "New projects will show up here soon."}
      </p>
      <div className="mt-5">
        {isAdmin ? (
          <Button onClick={onAdd}>
            <Plus className="mr-1.5 h-4 w-4" /> Add work
          </Button>
        ) : (
          <Button variant="outline" onClick={onUnlock}>
            Author mode
          </Button>
        )}
      </div>
    </motion.div>
  );
}
