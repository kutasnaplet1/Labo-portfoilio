const KEY = "labo_admin_email";
export const OWNER_EMAIL = "di80pkonto@gmail.com";

export function getAdminEmail(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(KEY);
}

export function setAdminEmail(email: string) {
  window.localStorage.setItem(KEY, email.trim().toLowerCase());
}

export function clearAdminEmail() {
  window.localStorage.removeItem(KEY);
}

export function isOwner(): boolean {
  return getAdminEmail() === OWNER_EMAIL;
}
