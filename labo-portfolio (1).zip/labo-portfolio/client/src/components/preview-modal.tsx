import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, AlertTriangle } from "lucide-react";
import type { PortfolioItem } from "@shared/schema";
import { useState } from "react";

interface PreviewModalProps {
  item: PortfolioItem | null;
  onClose: () => void;
}

function isImage(url: string) {
  return /\.(png|jpe?g|gif|webp|svg|avif)(\?|$)/i.test(url);
}
function isVideoFile(url: string) {
  return /\.(mp4|webm|mov|m4v)(\?|$)/i.test(url);
}
function isAudio(url: string) {
  return /\.(mp3|wav|ogg|m4a|flac)(\?|$)/i.test(url);
}
function youTubeEmbed(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu.be")) {
      return `https://www.youtube.com/embed${u.pathname}`;
    }
    if (u.hostname.includes("youtube.com")) {
      const id = u.searchParams.get("v");
      if (id) return `https://www.youtube.com/embed/${id}`;
      if (u.pathname.startsWith("/embed/")) return url;
    }
    if (u.hostname.includes("vimeo.com")) {
      const id = u.pathname.split("/").filter(Boolean)[0];
      if (id) return `https://player.vimeo.com/video/${id}`;
    }
  } catch {}
  return null;
}

export function PreviewModal({ item, onClose }: PreviewModalProps) {
  const [iframeFailed, setIframeFailed] = useState(false);

  if (!item) return null;

  const url = item.previewUrl;
  const embed = youTubeEmbed(url);

  let body: React.ReactNode;
  if (isImage(url)) {
    body = (
      <img
        src={url}
        alt={item.title}
        className="max-h-[70vh] w-full rounded-lg object-contain"
      />
    );
  } else if (isVideoFile(url)) {
    body = (
      <video
        src={url}
        controls
        autoPlay
        className="max-h-[70vh] w-full rounded-lg bg-black"
      />
    );
  } else if (isAudio(url)) {
    body = <audio src={url} controls autoPlay className="w-full" />;
  } else if (embed) {
    body = (
      <div className="aspect-video w-full overflow-hidden rounded-lg bg-black">
        <iframe
          src={embed}
          title={item.title}
          className="h-full w-full"
          allow="autoplay; encrypted-media; picture-in-picture"
          allowFullScreen
        />
      </div>
    );
  } else {
    body = iframeFailed ? (
      <div className="flex flex-col items-center gap-3 rounded-lg border bg-muted/50 p-8 text-center">
        <AlertTriangle className="h-10 w-10 text-amber-500" />
        <p className="text-sm text-muted-foreground">
          Tej strony nie da się osadzić w ramce. Otwórz ją w nowej karcie.
        </p>
        <Button asChild>
          <a href={url} target="_blank" rel="noreferrer">
            <ExternalLink className="mr-2 h-4 w-4" /> Otwórz w nowej karcie
          </a>
        </Button>
      </div>
    ) : (
      <div className="h-[70vh] w-full overflow-hidden rounded-lg border bg-white">
        <iframe
          src={url}
          title={item.title}
          className="h-full w-full"
          onError={() => setIframeFailed(true)}
        />
      </div>
    );
  }

  return (
    <Dialog
      open={!!item}
      onOpenChange={(o) => {
        if (!o) {
          setIframeFailed(false);
          onClose();
        }
      }}
    >
      <DialogContent className="max-w-5xl" data-testid="dialog-preview">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between gap-3 pr-6">
            <span>{item.title}</span>
            <Button asChild variant="outline" size="sm">
              <a href={url} target="_blank" rel="noreferrer">
                <ExternalLink className="mr-2 h-3 w-3" /> Nowa karta
              </a>
            </Button>
          </DialogTitle>
        </DialogHeader>
        {body}
        {item.description && (
          <p className="text-sm text-muted-foreground">{item.description}</p>
        )}
      </DialogContent>
    </Dialog>
  );
}
