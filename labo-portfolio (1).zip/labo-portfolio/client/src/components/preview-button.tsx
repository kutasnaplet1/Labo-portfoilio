import { motion } from "framer-motion";
import { Play } from "lucide-react";

interface PreviewButtonProps {
  onClick: () => void;
  label?: string;
}

export function PreviewButton({ onClick, label = "Preview" }: PreviewButtonProps) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-primary/30"
      data-testid="button-preview"
    >
      <span className="absolute inset-0 brand-gradient" />
      <motion.span
        className="absolute inset-0 brand-gradient"
        style={{ filter: "blur(20px)", opacity: 0.7 }}
        animate={{ opacity: [0.4, 0.8, 0.4] }}
        transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.span
        className="absolute inset-y-0 -left-1/2 w-1/2 bg-white/30"
        style={{ skewX: "-20deg" }}
        animate={{ x: ["0%", "400%"] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.span
        className="relative z-10 flex h-6 w-6 items-center justify-center rounded-full bg-white/25"
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
      >
        <Play className="h-3 w-3 fill-white" />
      </motion.span>
      <span className="relative z-10">{label}</span>
    </motion.button>
  );
}
