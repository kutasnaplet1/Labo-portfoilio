import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  CATEGORIES,
  insertPortfolioItemSchema,
  type Category,
} from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { getAdminEmail } from "@/lib/admin";

const formSchema = insertPortfolioItemSchema.omit({ email: true });
type FormValues = z.infer<typeof formSchema>;

const CATEGORY_LABELS: Record<Category, string> = {
  websites: "Websites",
  "video-edit": "Video edit",
  graphics: "Graphics",
  music: "Music",
  other: "Other",
};

interface UploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultCategory?: Category;
}

export function UploadDialog({
  open,
  onOpenChange,
  defaultCategory,
}: UploadDialogProps) {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<Category>(
    defaultCategory ?? "websites",
  );

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      category: defaultCategory ?? "websites",
      previewUrl: "",
      thumbnailUrl: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const email = getAdminEmail();
      const res = await apiRequest("POST", "/api/portfolio", {
        ...values,
        email,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
      toast({ title: "Dodano!", description: "Praca pojawiła się w portfolio." });
      form.reset({
        title: "",
        description: "",
        category: selectedCategory,
        previewUrl: "",
        thumbnailUrl: "",
      });
      onOpenChange(false);
    },
    onError: (e: Error) => {
      toast({
        title: "Nie udało się dodać",
        description: e.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg" data-testid="dialog-upload">
        <DialogHeader>
          <DialogTitle>New work</DialogTitle>
          <DialogDescription>
            Add something new to your portfolio.
          </DialogDescription>
        </DialogHeader>
        <form
          onSubmit={form.handleSubmit((v) => mutation.mutate(v))}
          className="space-y-4"
        >
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              {...form.register("title")}
              placeholder="e.g. Pizzeria website"
              data-testid="input-title"
            />
            {form.formState.errors.title && (
              <p className="text-xs text-destructive">
                {form.formState.errors.title.message}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label>Category</Label>
            <Select
              value={form.watch("category")}
              onValueChange={(v) => {
                form.setValue("category", v as Category);
                setSelectedCategory(v as Category);
              }}
            >
              <SelectTrigger data-testid="select-category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    {CATEGORY_LABELS[c]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="previewUrl">Preview link / URL</Label>
            <Input
              id="previewUrl"
              {...form.register("previewUrl")}
              placeholder="http://localhost:3000 or https://..."
              data-testid="input-preview-url"
            />
            {form.formState.errors.previewUrl && (
              <p className="text-xs text-destructive">
                {form.formState.errors.previewUrl.message}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              For websites you can use a local address (e.g.
              http://localhost:3000); for videos/graphics paste a file link or
              YouTube URL.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="thumbnailUrl">Thumbnail (image URL)</Label>
            <Input
              id="thumbnailUrl"
              {...form.register("thumbnailUrl")}
              placeholder="optional — link to an image"
              data-testid="input-thumbnail-url"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              placeholder="A short description of the project..."
              data-testid="input-description"
            />
          </div>

          <DialogFooter>
            <Button
              type="submit"
              disabled={mutation.isPending}
              data-testid="button-submit-upload"
            >
              {mutation.isPending ? "Adding..." : "Add work"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export { CATEGORY_LABELS };
