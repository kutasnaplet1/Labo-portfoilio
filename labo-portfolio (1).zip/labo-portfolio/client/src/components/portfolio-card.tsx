import { motion } from "framer-motion";
import { forwardRef } from "react";
import { Trash2, Globe, Film, Image as ImageIcon, Music, Sparkles } from "lucide-react";
import type { PortfolioItem, Category } from "@shared/schema";
import { PreviewButton } from "./preview-button";
import { Button } from "@/components/ui/button";
import { CATEGORY_LABELS } from "./upload-dialog";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getAdminEmail } from "@/lib/admin";
import { useToast } from "@/hooks/use-toast";

const CATEGORY_ICON: Record<Category, typeof Globe> = {
  websites: Globe,
  "video-edit": Film,
  graphics: ImageIcon,
  music: Music,
  other: Sparkles,
};

interface PortfolioCardProps {
  item: PortfolioItem;
  isAdmin: boolean;
  onPreview: (item: PortfolioItem) => void;
}

export const PortfolioCard = forwardRef<HTMLDivElement, PortfolioCardProps>(
  function PortfolioCard({ item, isAdmin, onPreview }, ref) {
  const { toast } = useToast();
  const Icon = CATEGORY_ICON[item.category];

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const email = encodeURIComponent(getAdminEmail() ?? "");
      await apiRequest("DELETE", `/api/portfolio/${item.id}?email=${email}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
      toast({ title: "Deleted" });
    },
    onError: (e: Error) =>
      toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  return (
    <motion.div
      ref={ref}
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -4 }}
      className="group relative overflow-hidden rounded-2xl border bg-card shadow-sm hover:shadow-xl transition-shadow"
      data-testid={`card-item-${item.id}`}
    >
      <div className="relative aspect-video overflow-hidden bg-muted">
        {item.thumbnailUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={item.thumbnailUrl}
            alt={item.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = "none";
            }}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center brand-gradient opacity-80">
            <Icon className="h-16 w-16 text-white/80" />
          </div>
        )}
        <div className="absolute left-3 top-3 rounded-full bg-background/90 px-3 py-1 text-xs font-medium backdrop-blur">
          <span className="inline-flex items-center gap-1.5">
            <Icon className="h-3 w-3" />
            {CATEGORY_LABELS[item.category]}
          </span>
        </div>
      </div>

      <div className="space-y-3 p-5">
        <div>
          <h3
            className="text-lg font-semibold leading-tight"
            data-testid={`text-title-${item.id}`}
          >
            {item.title}
          </h3>
          {item.description && (
            <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">
              {item.description}
            </p>
          )}
        </div>

        <div className="flex items-center justify-between gap-2">
          <PreviewButton onClick={() => onPreview(item)} />
          {isAdmin && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                if (confirm("Delete this work?")) deleteMutation.mutate();
              }}
              disabled={deleteMutation.isPending}
              data-testid={`button-delete-${item.id}`}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          )}
        </div>
      </div>
    </motion.div>
  );
});
