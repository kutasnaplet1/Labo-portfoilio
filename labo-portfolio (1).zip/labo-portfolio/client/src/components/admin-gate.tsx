import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { setAdminEmail, OWNER_EMAIL } from "@/lib/admin";
import { useToast } from "@/hooks/use-toast";

interface AdminGateProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUnlock: () => void;
}

export function AdminGate({ open, onOpenChange, onUnlock }: AdminGateProps) {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const SECRET_CODE = "26012019";

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const value = email.trim();
    if (value === SECRET_CODE) {
      toast({
        title: "Secret unlocked",
        description: "Downloading the site source as a ZIP...",
      });
      const a = document.createElement("a");
      a.href = `/api/source.zip?code=${encodeURIComponent(SECRET_CODE)}`;
      a.download = "labo-portfolio.zip";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setEmail("");
      onOpenChange(false);
      return;
    }
    if (value.toLowerCase() === OWNER_EMAIL) {
      setAdminEmail(value);
      toast({ title: "Welcome back, Łabo!", description: "Edit mode enabled." });
      setEmail("");
      onOpenChange(false);
      onUnlock();
    } else {
      toast({
        title: "Wrong address",
        description: "Only the owner can add new works.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" data-testid="dialog-admin-gate">
        <DialogHeader>
          <DialogTitle>Author mode</DialogTitle>
          <DialogDescription>
            Enter your email address to unlock adding new works.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="admin-email">Email</Label>
            <Input
              id="admin-email"
              type="text"
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@email.com"
              data-testid="input-admin-email"
            />
          </div>
          <DialogFooter>
            <Button type="submit" data-testid="button-admin-unlock">
              Unlock
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
