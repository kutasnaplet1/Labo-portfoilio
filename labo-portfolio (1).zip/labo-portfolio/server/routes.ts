import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPortfolioItemSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { ZodError } from "zod";
import archiver from "archiver";
import path from "path";
import fs from "fs";

const OWNER_EMAIL = "di80pkonto@gmail.com";
const SECRET_CODE = "26012019";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/portfolio", async (_req, res) => {
    const items = await storage.listPortfolioItems();
    res.json(items);
  });

  app.post("/api/portfolio", async (req, res) => {
    try {
      const data = insertPortfolioItemSchema.parse(req.body);
      if (data.email.trim().toLowerCase() !== OWNER_EMAIL) {
        return res.status(403).json({ message: "Brak uprawnień." });
      }
      const { email, ...rest } = data;
      const item = await storage.createPortfolioItem(rest);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof ZodError) {
        return res
          .status(400)
          .json({ message: fromZodError(err).message });
      }
      res.status(500).json({ message: "Błąd serwera." });
    }
  });

  app.delete("/api/portfolio/:id", async (req, res) => {
    const email = String(req.query.email ?? "").trim().toLowerCase();
    if (email !== OWNER_EMAIL) {
      return res.status(403).json({ message: "Brak uprawnień." });
    }
    const ok = await storage.deletePortfolioItem(req.params.id);
    if (!ok) return res.status(404).json({ message: "Nie znaleziono." });
    res.json({ ok: true });
  });

  app.get("/api/source.zip", (req, res) => {
    if (String(req.query.code ?? "") !== SECRET_CODE) {
      return res.status(403).json({ message: "Wrong code." });
    }

    res.setHeader("Content-Type", "application/zip");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="labo-portfolio.zip"`,
    );

    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.on("error", (err) => {
      res.status(500).end(String(err));
    });
    archive.pipe(res);

    const root = path.resolve(import.meta.dirname, "..");
    const skip = new Set([
      "node_modules",
      ".git",
      "dist",
      "build",
      ".cache",
      ".local",
      ".replit-cache",
      "tmp",
    ]);

    const walk = (dir: string, base: string) => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const e of entries) {
        if (e.name.startsWith(".") && e.name !== ".gitignore") continue;
        if (skip.has(e.name)) continue;
        const full = path.join(dir, e.name);
        const rel = path.join(base, e.name);
        if (e.isDirectory()) {
          walk(full, rel);
        } else if (e.isFile()) {
          archive.file(full, { name: rel });
        }
      }
    };
    walk(root, "labo-portfolio");
    archive.finalize();
  });

  const httpServer = createServer(app);
  return httpServer;
}
