import {
  type User,
  type InsertUser,
  type PortfolioItem,
  type InsertPortfolioItem,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  listPortfolioItems(): Promise<PortfolioItem[]>;
  createPortfolioItem(
    item: Omit<InsertPortfolioItem, "email">,
  ): Promise<PortfolioItem>;
  deletePortfolioItem(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private items: Map<string, PortfolioItem>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.items = new Map();
    this.currentId = 1;
    this.seed();
  }

  private seed() {
    const now = Date.now();
    const samples: PortfolioItem[] = [
      {
        id: randomUUID(),
        title: "Animated CodePen demo",
        description:
          "Sample interactive web demo embedded straight from CodePen — opens right inside the preview.",
        category: "websites",
        previewUrl: "https://codepen.io/chriscoyier/embed/oNjLjjm?default-tab=result",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200&q=70",
        createdAt: now - 5000,
      },
      {
        id: randomUUID(),
        title: "Me at the zoo",
        description:
          "The very first YouTube video — used here as a video-edit sample. Plays directly inside the preview.",
        category: "video-edit",
        previewUrl: "https://www.youtube.com/watch?v=jNQXAC9IVRw",
        thumbnailUrl: "https://i.ytimg.com/vi/jNQXAC9IVRw/hqdefault.jpg",
        createdAt: now - 4000,
      },
      {
        id: randomUUID(),
        title: "Random photo",
        description: "A high-res sample image from picsum.photos.",
        category: "graphics",
        previewUrl: "https://picsum.photos/seed/labo/1600/1000",
        thumbnailUrl: "https://picsum.photos/seed/labo/800/500",
        createdAt: now - 3000,
      },
      {
        id: randomUUID(),
        title: "Lo-Fi beats",
        description: "A music sample embedded via YouTube.",
        category: "music",
        previewUrl: "https://www.youtube.com/watch?v=jfKfPfyJRdk",
        thumbnailUrl: "https://i.ytimg.com/vi/jfKfPfyJRdk/hqdefault.jpg",
        createdAt: now - 2000,
      },
      {
        id: randomUUID(),
        title: "Abstract gradient",
        description: "Just a colorful sample to fill the 'Other' bucket.",
        category: "other",
        previewUrl: "https://picsum.photos/seed/labo-abstract/1600/1000",
        thumbnailUrl: "https://picsum.photos/seed/labo-abstract/800/500",
        createdAt: now - 1000,
      },
    ];
    for (const it of samples) this.items.set(it.id, it);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async listPortfolioItems(): Promise<PortfolioItem[]> {
    return Array.from(this.items.values()).sort(
      (a, b) => b.createdAt - a.createdAt,
    );
  }

  async createPortfolioItem(
    item: Omit<InsertPortfolioItem, "email">,
  ): Promise<PortfolioItem> {
    const newItem: PortfolioItem = {
      id: randomUUID(),
      title: item.title,
      description: item.description ?? "",
      category: item.category,
      previewUrl: item.previewUrl,
      thumbnailUrl: item.thumbnailUrl ?? "",
      createdAt: Date.now(),
    };
    this.items.set(newItem.id, newItem);
    return newItem;
  }

  async deletePortfolioItem(id: string): Promise<boolean> {
    return this.items.delete(id);
  }
}

export const storage = new MemStorage();
