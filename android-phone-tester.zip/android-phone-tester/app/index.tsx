import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  Vibration,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Battery from 'expo-battery';
import * as Location from 'expo-location';
import * as Network from 'expo-network';
import { Accelerometer, Gyroscope } from 'expo-sensors';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type AxisReading = { x: number; y: number; z: number };
type Tone = 'good' | 'warn' | 'bad' | 'quiet';
type CameraFacing = 'back' | 'front';

function formatAxis(value: number | undefined) {
  return typeof value === 'number' ? value.toFixed(2) : '—';
}

function networkName(state: Network.NetworkState | null) {
  if (!state) return 'Sprawdzanie';
  switch (state.type) {
    case Network.NetworkStateType.WIFI:
      return 'Wi‑Fi';
    case Network.NetworkStateType.CELLULAR:
      return 'Dane komórkowe';
    case Network.NetworkStateType.ETHERNET:
      return 'Ethernet';
    case Network.NetworkStateType.VPN:
      return 'VPN';
    case Network.NetworkStateType.BLUETOOTH:
      return 'Bluetooth';
    case Network.NetworkStateType.NONE:
      return 'Brak połączenia';
    default:
      return state.isConnected ? 'Połączono' : 'Nieznana sieć';
  }
}

function batteryStateName(state: Battery.BatteryState | null) {
  if (state === Battery.BatteryState.CHARGING) return 'Ładowanie';
  if (state === Battery.BatteryState.FULL) return 'Pełna';
  if (state === Battery.BatteryState.NOT_CHARGING) return 'Podłączona';
  if (state === Battery.BatteryState.UNPLUGGED) return 'Na baterii';
  return 'Brak odczytu';
}

function StatusPill({ label, tone = 'quiet' }: { label: string; tone?: Tone }) {
  const colors = useColors();
  const toneColor =
    tone === 'good'
      ? colors.success
      : tone === 'warn'
        ? colors.warning
        : tone === 'bad'
          ? colors.destructive
          : colors.mutedForeground;
  return (
    <View
      style={[
        styles.statusPill,
        { backgroundColor: `${toneColor}1C`, borderColor: `${toneColor}40` },
      ]}
    >
      <View style={[styles.statusDot, { backgroundColor: toneColor }]} />
      <Text style={[styles.statusPillText, { color: toneColor }]}>{label}</Text>
    </View>
  );
}

function ModuleCard({
  icon,
  eyebrow,
  title,
  detail,
  status,
  tone,
  onPress,
  testID,
  children,
}: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  eyebrow: string;
  title: string;
  detail: string;
  status: string;
  tone: Tone;
  onPress: () => void;
  testID: string;
  children?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      testID={testID}
      style={({ pressed }) => [
        styles.moduleCard,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          opacity: pressed ? 0.8 : 1,
          transform: [{ scale: pressed ? 0.985 : 1 }],
        },
      ]}
    >
      <View style={styles.moduleTop}>
        <View style={[styles.moduleIcon, { backgroundColor: colors.accent }]}>
          <Ionicons name={icon} size={20} color={colors.primary} />
        </View>
        <StatusPill label={status} tone={tone} />
      </View>
      <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
        {eyebrow}
      </Text>
      <Text style={[styles.moduleTitle, { color: colors.cardForeground }]}>
        {title}
      </Text>
      <Text style={[styles.moduleDetail, { color: colors.mutedForeground }]}>
        {detail}
      </Text>
      {children}
      <View style={[styles.moduleArrow, { backgroundColor: colors.primary + '1A' }]}>
        <Ionicons name="arrow-forward" size={16} color={colors.primary} />
      </View>
    </Pressable>
  );
}

function AxisReadout({
  label,
  reading,
  unit,
}: {
  label: string;
  reading: AxisReading | null;
  unit: string;
}) {
  const colors = useColors();
  const axes: Array<keyof AxisReading> = ['x', 'y', 'z'];
  return (
    <View style={styles.axisBlock}>
      <Text style={[styles.axisLabel, { color: colors.mutedForeground }]}>
        {label}
      </Text>
      <View style={styles.axisValues}>
        {axes.map((axis) => (
          <View
            key={`${label}-${axis}`}
            style={[styles.axisCell, { backgroundColor: colors.secondary }]}
          >
            <Text style={[styles.axisKey, { color: colors.mutedForeground }]}>
              {axis.toUpperCase()}
            </Text>
            <Text style={[styles.axisNumber, { color: colors.cardForeground }]}>
              {formatAxis(reading?.[axis])}
            </Text>
          </View>
        ))}
      </View>
      <Text style={[styles.axisUnit, { color: colors.mutedForeground }]}>
        {unit}
      </Text>
    </View>
  );
}

export default function PhoneCheckScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [cameraAvailable, setCameraAvailable] = useState<boolean | null>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [cameraFacing, setCameraFacing] = useState<CameraFacing>('back');
  const [torchEnabled, setTorchEnabled] = useState(false);
  const [capturedUri, setCapturedUri] = useState<string | null>(null);
  const [capturing, setCapturing] = useState(false);
  const cameraRef = useRef<CameraView | null>(null);

  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [batteryState, setBatteryState] =
    useState<Battery.BatteryState | null>(null);
  const [batteryAvailable, setBatteryAvailable] = useState<boolean | null>(
    null,
  );
  const [lowPower, setLowPower] = useState<boolean | null>(null);
  const [network, setNetwork] = useState<Network.NetworkState | null>(null);
  const [locationPermission, setLocationPermission] =
    useState<Awaited<ReturnType<typeof Location.getForegroundPermissionsAsync>> | null>(
      null,
    );
  const [location, setLocation] = useState<{
    latitude: number;
    longitude: number;
    accuracy: number | null;
    timestamp: number;
  } | null>(null);
  const [locationBusy, setLocationBusy] = useState(false);
  const [locationMessage, setLocationMessage] = useState('');
  const [sensorAvailable, setSensorAvailable] = useState<boolean | null>(null);
  const [accelerometer, setAccelerometer] = useState<AxisReading | null>(null);
  const [gyroscope, setGyroscope] = useState<AxisReading | null>(null);
  const [vibrationMessage, setVibrationMessage] = useState('');

  useEffect(() => {
    let active = true;

    if (Platform.OS !== 'web') {
      void CameraView.isAvailableAsync()
        .then((available) => {
          if (active) setCameraAvailable(available);
        })
        .catch(() => {
          if (active) setCameraAvailable(false);
        });

      void Location.getForegroundPermissionsAsync()
        .then((permission) => {
          if (active) setLocationPermission(permission);
        })
        .catch(() => {
          if (active) setLocationPermission(null);
        });

      void Promise.all([Battery.isAvailableAsync(), Battery.getPowerStateAsync()])
        .then(([available, power]) => {
          if (!active) return;
          setBatteryAvailable(available && power.batteryLevel >= 0);
          setBatteryLevel(power.batteryLevel >= 0 ? power.batteryLevel : null);
          setBatteryState(power.batteryState);
          setLowPower(power.lowPowerMode);
        })
        .catch(() => {
          if (active) setBatteryAvailable(false);
        });
    } else {
      setCameraAvailable(false);
      setBatteryAvailable(false);
      setSensorAvailable(false);
    }

    void Network.getNetworkStateAsync()
      .then((state) => {
        if (active) setNetwork(state);
      })
      .catch(() => {
        if (active) setNetwork(null);
      });

    const networkSubscription = Network.addNetworkStateListener((state) => {
      if (active) setNetwork(state);
    });

    let batteryLevelSubscription:
      | ReturnType<typeof Battery.addBatteryLevelListener>
      | undefined;
    let batteryStateSubscription:
      | ReturnType<typeof Battery.addBatteryStateListener>
      | undefined;

    if (Platform.OS !== 'web') {
      batteryLevelSubscription = Battery.addBatteryLevelListener((event) => {
        setBatteryLevel(event.batteryLevel >= 0 ? event.batteryLevel : null);
      });
      batteryStateSubscription = Battery.addBatteryStateListener((event) => {
        setBatteryState(event.batteryState);
      });
    }

    return () => {
      active = false;
      networkSubscription.remove();
      batteryLevelSubscription?.remove();
      batteryStateSubscription?.remove();
    };
  }, []);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    let active = true;
    let accelerometerSubscription:
      | ReturnType<typeof Accelerometer.addListener>
      | undefined;
    let gyroscopeSubscription:
      | ReturnType<typeof Gyroscope.addListener>
      | undefined;

    const connectSensors = async () => {
      const [hasAccelerometer, hasGyroscope] = await Promise.all([
        Accelerometer.isAvailableAsync(),
        Gyroscope.isAvailableAsync(),
      ]);
      if (!active) return;
      setSensorAvailable(hasAccelerometer || hasGyroscope);

      if (hasAccelerometer) {
        Accelerometer.setUpdateInterval(400);
        accelerometerSubscription = Accelerometer.addListener((reading) => {
          setAccelerometer({ x: reading.x, y: reading.y, z: reading.z });
        });
      }
      if (hasGyroscope) {
        Gyroscope.setUpdateInterval(400);
        gyroscopeSubscription = Gyroscope.addListener((reading) => {
          setGyroscope({ x: reading.x, y: reading.y, z: reading.z });
        });
      }
    };

    void connectSensors().catch(() => {
      if (active) setSensorAvailable(false);
    });

    return () => {
      active = false;
      accelerometerSubscription?.remove();
      gyroscopeSubscription?.remove();
    };
  }, []);

  const openCamera = async () => {
    setCameraOpen(true);
    setCameraReady(false);
    setCameraError('');
    setCapturedUri(null);
    setTorchEnabled(false);
    setCameraFacing('back');

    if (Platform.OS === 'web') {
      setCameraError('Otwórz aplikację na Androidzie, aby sprawdzić aparat.');
      return;
    }
    if (cameraPermission?.granted) return;

    try {
      const permission = await requestCameraPermission();
      if (!permission.granted) {
        setCameraError(
          permission.canAskAgain
            ? 'Aby uruchomić podgląd, zezwól na dostęp do aparatu.'
            : 'Dostęp do aparatu jest zablokowany. Zmień go w ustawieniach telefonu.',
        );
      }
    } catch {
      setCameraError('Nie udało się poprosić o dostęp do aparatu.');
    }
  };

  const requestCameraAgain = async () => {
    setCameraError('');
    try {
      const permission = await requestCameraPermission();
      if (!permission.granted) {
        setCameraError(
          permission.canAskAgain
            ? 'Aby uruchomić podgląd, zezwól na dostęp do aparatu.'
            : 'Dostęp do aparatu jest zablokowany. Zmień go w ustawieniach telefonu.',
        );
      }
    } catch {
      setCameraError('Nie udało się poprosić o dostęp do aparatu.');
    }
  };

  const capturePhoto = async () => {
    if (!cameraRef.current || !cameraReady) return;
    setCapturing(true);
    setCameraError('');
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.75 });
      setCapturedUri(photo.uri);
    } catch {
      setCameraError('Zdjęcie nie powiodło się. Sprawdź, czy aparat jest gotowy.');
    } finally {
      setCapturing(false);
    }
  };

  const closeCamera = () => {
    setCameraOpen(false);
    setTorchEnabled(false);
    setCameraReady(false);
  };

  const openSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      setLocationMessage('Otwórz ustawienia aplikacji telefonu ręcznie.');
    }
  };

  const runLocationTest = async () => {
    if (Platform.OS === 'web') {
      setLocationMessage('Uruchom aplikację na Androidzie, aby sprawdzić GPS.');
      return;
    }

    setLocationBusy(true);
    setLocationMessage('');
    try {
      let permission = await Location.getForegroundPermissionsAsync();
      if (!permission.granted) {
        permission = await Location.requestForegroundPermissionsAsync();
        setLocationPermission(permission);
        if (!permission.granted) {
          setLocationMessage(
            permission.canAskAgain
              ? 'Zezwól na lokalizację, aby wykonać test GPS.'
              : 'Dostęp do lokalizacji jest zablokowany. Zmień go w ustawieniach telefonu.',
          );
          return;
        }
      } else {
        setLocationPermission(permission);
      }

      const servicesEnabled = await Location.hasServicesEnabledAsync();
      if (!servicesEnabled) {
        setLocationMessage('Włącz lokalizację w ustawieniach Androida.');
        return;
      }

      const current = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      setLocation({
        latitude: current.coords.latitude,
        longitude: current.coords.longitude,
        accuracy: current.coords.accuracy,
        timestamp: current.timestamp,
      });
      setLocationMessage('');
    } catch {
      setLocationMessage(
        'Nie udało się pobrać pozycji. Sprawdź GPS i spróbuj ponownie.',
      );
    } finally {
      setLocationBusy(false);
    }
  };

  const testVibration = () => {
    if (Platform.OS === 'web') {
      setVibrationMessage('Wibracja działa w aplikacji uruchomionej na telefonie.');
      return;
    }
    try {
      Vibration.vibrate([0, 180, 100, 180, 100, 320]);
      setVibrationMessage('Wysłano testowy sygnał');
    } catch {
      setVibrationMessage('Telefon nie udostępnił silnika wibracji.');
    }
  };

  const batteryPercent =
    batteryLevel === null ? null : Math.round(batteryLevel * 100);
  const networkConnected = network?.isConnected === true;
  const networkTone: Tone =
    network === null ? 'quiet' : networkConnected ? 'good' : 'bad';
  const cameraTone: Tone = cameraPermission?.granted ? 'good' : 'warn';
  const locationTone: Tone = location ? 'good' : 'warn';
  const sensorTone =
    sensorAvailable === null
      ? 'quiet'
      : sensorAvailable
        ? 'good'
        : 'bad';
  const topInset =
    Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset =
    Platform.OS === 'web' ? Math.max(insets.bottom, 34) : insets.bottom;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <StatusBar style="light" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: topInset + 12,
            paddingBottom: bottomInset + 28,
            paddingLeft: Math.max(insets.left, 20),
            paddingRight: Math.max(insets.right, 20),
          },
        ]}
      >
        <View style={styles.header}>
          <View
            style={[
              styles.brandIcon,
              {
                borderColor: colors.primary + '55',
                backgroundColor: colors.primary + '1A',
              },
            ]}
          >
            <Ionicons name="scan-outline" size={22} color={colors.primary} />
          </View>
          <View style={styles.headerCopy}>
            <Text style={[styles.brandName, { color: colors.foreground }]}>
              DEVICE CHECK
            </Text>
            <Text style={[styles.brandCaption, { color: colors.mutedForeground }]}>
              Tester podzespołów telefonu
            </Text>
          </View>
          <View
            style={[
              styles.platformTag,
              { backgroundColor: colors.secondary, borderColor: colors.border },
            ]}
          >
            <Ionicons name="phone-portrait-outline" size={13} color={colors.primary} />
            <Text style={[styles.platformTagText, { color: colors.secondaryForeground }]}>
              ANDROID
            </Text>
          </View>
        </View>

        <LinearGradient
          colors={[colors.card, colors.secondary] as [string, string]}
          style={[styles.hero, { borderColor: colors.border }]}
        >
          <View style={styles.heroContent}>
            <View style={styles.heroKicker}>
              <View style={[styles.liveDot, { backgroundColor: colors.primary }]} />
              <Text style={[styles.heroKickerText, { color: colors.primary }]}>
                TESTY NA ŻYWO
              </Text>
            </View>
            <Text style={[styles.heroTitle, { color: colors.foreground }]}>
              Sprawdź, co działa.
            </Text>
            <Text style={[styles.heroBody, { color: colors.mutedForeground }]}>
              Uruchom każdy test i zobacz prawdziwe odczyty z telefonu.
            </Text>
          </View>
          <View style={styles.heroGraphic} pointerEvents="none">
            <View style={[styles.heroRingOuter, { borderColor: colors.primary + '45' }]} />
            <View style={[styles.heroRingInner, { borderColor: colors.primary + '85' }]} />
            <View style={[styles.heroCore, { backgroundColor: colors.primary + '1F' }]}>
              <Ionicons name="hardware-chip-outline" size={30} color={colors.primary} />
            </View>
            <View style={[styles.heroSpark, styles.heroSparkOne, { backgroundColor: colors.primary }]} />
            <View style={[styles.heroSpark, styles.heroSparkTwo, { backgroundColor: colors.warning }]} />
          </View>
        </LinearGradient>

        <View style={styles.overviewRow}>
          <View
            style={[
              styles.overviewCard,
              { backgroundColor: colors.card, borderColor: colors.border },
            ]}
          >
            <View style={styles.overviewTop}>
              <View style={styles.overviewLabelRow}>
                <Ionicons name="battery-half-outline" size={15} color={colors.primary} />
                <Text style={[styles.overviewLabel, { color: colors.mutedForeground }]}>
                  BATERIA
                </Text>
              </View>
              <Text style={[styles.overviewValue, { color: colors.foreground }]}>
                {batteryPercent === null ? '—' : `${batteryPercent}%`}
              </Text>
            </View>
            <View style={[styles.progressTrack, { backgroundColor: colors.track }]}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${batteryPercent ?? 0}%`,
                    backgroundColor:
                      batteryPercent !== null && batteryPercent < 15
                        ? colors.warning
                        : colors.primary,
                  },
                ]}
              />
            </View>
            <Text style={[styles.overviewHint, { color: colors.mutedForeground }]}>
              {batteryAvailable === false
                ? 'Odczyt niedostępny'
                : `${batteryStateName(batteryState)}${lowPower ? ' · oszczędzanie' : ''}`}
            </Text>
          </View>

          <View
            style={[
              styles.overviewCard,
              { backgroundColor: colors.card, borderColor: colors.border },
            ]}
          >
            <View style={styles.overviewTop}>
              <View style={styles.overviewLabelRow}>
                <Ionicons
                  name={networkConnected ? 'wifi' : 'cloud-offline-outline'}
                  size={15}
                  color={networkTone === 'bad' ? colors.warning : colors.primary}
                />
                <Text style={[styles.overviewLabel, { color: colors.mutedForeground }]}>
                  ŁĄCZNOŚĆ
                </Text>
              </View>
              <View
                style={[
                  styles.networkSignal,
                  { backgroundColor: networkConnected ? colors.success : colors.warning },
                ]}
              />
            </View>
            <Text
              numberOfLines={1}
              style={[styles.networkValue, { color: colors.foreground }]}
            >
              {networkName(network)}
            </Text>
            <Text style={[styles.overviewHint, { color: colors.mutedForeground }]}>
              {network?.isInternetReachable === true
                ? 'Internet dostępny'
                : network?.isConnected
                  ? 'Sieć połączona'
                  : network
                    ? 'Brak dostępu do Internetu'
                    : 'Sprawdzanie sieci…'}
            </Text>
          </View>
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Testy sprzętu
            </Text>
            <Text style={[styles.sectionCaption, { color: colors.mutedForeground }]}>
              Dotknij modułu, aby wykonać test
            </Text>
          </View>
          <View style={[styles.sectionCount, { backgroundColor: colors.accent }]}>
            <Ionicons name="pulse-outline" size={15} color={colors.primary} />
          </View>
        </View>

        <View style={styles.moduleGrid}>
          <ModuleCard
            icon="camera-outline"
            eyebrow="OBRAZ"
            title="Aparat"
            detail="Podgląd, zdjęcie i latarka"
            status={
              cameraPermission?.granted
                ? 'Gotowy'
                : cameraPermission
                  ? 'Sprawdź'
                  : 'Otwórz test'
            }
            tone={cameraTone}
            onPress={() => void openCamera()}
            testID="test-camera"
          />
          <ModuleCard
            icon="navigate-outline"
            eyebrow="LOKALIZACJA"
            title="GPS"
            detail={
              location
                ? `Dokładność ±${location.accuracy === null ? '—' : `${Math.round(location.accuracy)} m`}`
                : locationPermission?.granted
                  ? 'Zezwolono na dostęp'
                  : 'Sprawdź pozycję'
            }
            status={location ? 'Działa' : locationPermission?.granted ? 'Gotowy' : 'Sprawdź'}
            tone={locationTone}
            onPress={() => void runLocationTest()}
            testID="test-location"
          >
            {location ? (
              <View style={[styles.coordinateBox, { backgroundColor: colors.secondary }]}>
                <Text style={[styles.coordinateText, { color: colors.cardForeground }]}>
                  {location.latitude.toFixed(5)}°
                </Text>
                <Text style={[styles.coordinateText, { color: colors.cardForeground }]}>
                  {location.longitude.toFixed(5)}°
                </Text>
              </View>
            ) : null}
            {locationBusy ? (
              <ActivityIndicator
                style={styles.inlineSpinner}
                size="small"
                color={colors.primary}
              />
            ) : locationMessage ? (
              <Text style={[styles.inlineMessage, { color: colors.warning }]}>
                {locationMessage}
              </Text>
            ) : null}
          </ModuleCard>

          <View
            style={[
              styles.sensorCard,
              { backgroundColor: colors.card, borderColor: colors.border },
            ]}
          >
            <View style={styles.sensorHeader}>
              <View style={[styles.moduleIcon, { backgroundColor: colors.accent }]}>
                <Ionicons name="speedometer-outline" size={20} color={colors.primary} />
              </View>
              <View style={styles.sensorHeadingCopy}>
                <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
                  RUCH I ORIENTACJA
                </Text>
                <Text style={[styles.moduleTitle, { color: colors.cardForeground }]}>
                  Czujniki
                </Text>
              </View>
              <StatusPill
                label={
                  sensorAvailable === null
                    ? 'Sprawdzanie'
                    : sensorAvailable
                      ? 'Aktywne'
                      : 'Niedostępne'
                }
                tone={sensorTone}
              />
            </View>
            <View style={styles.sensorReadings}>
              <AxisReadout label="AKCELEROMETR" reading={accelerometer} unit="g" />
              <View style={[styles.sensorDivider, { backgroundColor: colors.border }]} />
              <AxisReadout label="ŻYROSKOP" reading={gyroscope} unit="rad/s" />
            </View>
            <View style={styles.sensorFooter}>
              <View style={[styles.liveDot, { backgroundColor: sensorAvailable ? colors.primary : colors.mutedForeground }]} />
              <Text style={[styles.sensorFooterText, { color: colors.mutedForeground }]}>
                Porusz telefonem — wartości powinny się zmieniać
              </Text>
            </View>
          </View>

          <Pressable
            accessibilityRole="button"
            onPress={testVibration}
            testID="test-vibration"
            style={({ pressed }) => [
              styles.vibrationCard,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.985 : 1 }],
              },
            ]}
          >
            <View style={styles.moduleTop}>
              <View style={[styles.moduleIcon, { backgroundColor: colors.accent }]}>
                <Ionicons name="radio-outline" size={20} color={colors.primary} />
              </View>
              <View style={[styles.tapIcon, { backgroundColor: colors.secondary }]}>
                <Ionicons name="play" size={12} color={colors.primary} />
              </View>
            </View>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
              SPRZĘŻENIE ZWROTNE
            </Text>
            <Text style={[styles.moduleTitle, { color: colors.cardForeground }]}>
              Wibracja
            </Text>
            <Text style={[styles.moduleDetail, { color: colors.mutedForeground }]}>
              Krótki wzór impulsów
            </Text>
            <View style={[styles.vibrationWave, { borderColor: colors.primary + '65' }]}>
              {[12, 24, 15, 31, 18, 11, 27, 14, 22].map((height, index) => (
                <View
                  key={`pulse-${index}`}
                  style={[
                    styles.waveBar,
                    {
                      height,
                      backgroundColor: index % 3 === 1 ? colors.warning : colors.primary,
                    },
                  ]}
                />
              ))}
            </View>
            {vibrationMessage ? (
              <Text style={[styles.vibrationMessage, { color: colors.success }]}>
                {vibrationMessage}
              </Text>
            ) : null}
            <View style={[styles.moduleArrow, { backgroundColor: colors.primary + '1A' }]}>
              <Ionicons name="play" size={15} color={colors.primary} />
            </View>
          </Pressable>

          <View
            style={[
              styles.noteCard,
              { backgroundColor: colors.secondary, borderColor: colors.border },
            ]}
          >
            <Ionicons name="information-circle-outline" size={19} color={colors.primary} />
            <Text style={[styles.noteText, { color: colors.secondaryForeground }]}>
              Testy aparatu i GPS poproszą o zgodę Androida dopiero po ich uruchomieniu.
            </Text>
          </View>
        </View>

        <View style={styles.footer}>
          <View style={[styles.footerLine, { backgroundColor: colors.border }]} />
          <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
            Odczyty są pobierane bezpośrednio z tego telefonu
          </Text>
        </View>
      </ScrollView>

      <Modal
        visible={cameraOpen}
        animationType="slide"
        onRequestClose={closeCamera}
        statusBarTranslucent
      >
        <View style={[styles.cameraScreen, { backgroundColor: colors.background }]}>
          <StatusBar style="light" />
          <View style={[styles.cameraHeader, { paddingTop: Math.max(insets.top, 18) }]}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Zamknij aparat"
              onPress={closeCamera}
              testID="close-camera"
              style={[styles.cameraClose, { backgroundColor: colors.card }]}
            >
              <Ionicons name="close" size={23} color={colors.foreground} />
            </Pressable>
            <View style={styles.cameraTitleGroup}>
              <Text style={[styles.cameraTitle, { color: colors.foreground }]}>
                Test aparatu
              </Text>
              <Text style={[styles.cameraSubtitle, { color: colors.mutedForeground }]}>
                {cameraReady ? 'Podgląd na żywo' : 'Łączenie z kamerą'}
              </Text>
            </View>
            <StatusPill
              label={cameraReady ? 'Aktywny' : 'TEST'}
              tone={cameraReady ? 'good' : 'quiet'}
            />
          </View>

          {Platform.OS === 'web' || !cameraPermission?.granted || cameraAvailable === false ? (
            <View style={styles.cameraGate}>
              <View style={[styles.cameraGateIcon, { backgroundColor: colors.accent }]}>
                <Ionicons
                  name={Platform.OS === 'web' ? 'phone-portrait-outline' : 'camera-outline'}
                  size={30}
                  color={colors.primary}
                />
              </View>
              <Text style={[styles.cameraGateTitle, { color: colors.foreground }]}>
                {Platform.OS === 'web'
                  ? 'Otwórz na Androidzie'
                  : cameraAvailable === false
                    ? 'Aparat niedostępny'
                    : 'Potrzebny dostęp do aparatu'}
              </Text>
              <Text style={[styles.cameraGateBody, { color: colors.mutedForeground }]}>
                {cameraError ||
                  'Aplikacja potrzebuje zgody, aby pokazać prawdziwy obraz z kamery.'}
              </Text>
              {Platform.OS !== 'web' && cameraAvailable !== false ? (
                <Pressable
                  accessibilityRole="button"
                  onPress={
                    cameraPermission?.canAskAgain === false
                      ? () => void openSettings()
                      : () => void requestCameraAgain()
                  }
                  testID="camera-permission-action"
                  style={({ pressed }) => [
                    styles.primaryAction,
                    { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 },
                  ]}
                >
                  <Ionicons
                    name={cameraPermission?.canAskAgain === false ? 'settings-outline' : 'checkmark'}
                    size={18}
                    color={colors.primaryForeground}
                  />
                  <Text style={[styles.primaryActionText, { color: colors.primaryForeground }]}>
                    {cameraPermission?.canAskAgain === false
                      ? 'Otwórz ustawienia'
                      : 'Poproś o zgodę'}
                  </Text>
                </Pressable>
              ) : null}
            </View>
          ) : (
            <>
              <View style={[styles.previewFrame, { backgroundColor: colors.background }]}>
                <CameraView
                  ref={cameraRef}
                  style={styles.cameraPreview}
                  facing={cameraFacing}
                  mode="picture"
                  enableTorch={torchEnabled}
                  onCameraReady={() => setCameraReady(true)}
                />
                {!cameraReady ? (
                  <View style={[styles.cameraLoading, { backgroundColor: colors.background }]}>
                    <ActivityIndicator size="large" color={colors.primary} />
                    <Text style={[styles.cameraLoadingText, { color: colors.foreground }]}>
                      Uruchamianie podglądu…
                    </Text>
                  </View>
                ) : null}
                <View style={[styles.cameraCornerTL, { borderColor: colors.primary }]} />
                <View style={[styles.cameraCornerTR, { borderColor: colors.primary }]} />
                <View style={[styles.cameraCornerBL, { borderColor: colors.primary }]} />
                <View style={[styles.cameraCornerBR, { borderColor: colors.primary }]} />
              </View>
              {cameraError ? (
                <Text style={[styles.cameraInlineError, { color: colors.warning }]}>
                  {cameraError}
                </Text>
              ) : null}
              <View style={styles.cameraControls}>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={torchEnabled ? 'Wyłącz latarkę' : 'Włącz latarkę'}
                  onPress={() => setTorchEnabled((value) => !value)}
                  testID="toggle-torch"
                  style={[
                    styles.cameraControl,
                    { backgroundColor: torchEnabled ? colors.primary : colors.card },
                  ]}
                >
                  <Ionicons
                    name={torchEnabled ? 'flash' : 'flash-outline'}
                    size={21}
                    color={torchEnabled ? colors.primaryForeground : colors.foreground}
                  />
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Zrób zdjęcie testowe"
                  disabled={!cameraReady || capturing}
                  onPress={() => void capturePhoto()}
                  testID="capture-photo"
                  style={({ pressed }) => [
                    styles.shutterOuter,
                    {
                      borderColor: colors.primary,
                      opacity: !cameraReady || capturing ? 0.45 : pressed ? 0.7 : 1,
                    },
                  ]}
                >
                  {capturing ? (
                    <ActivityIndicator color={colors.primary} />
                  ) : (
                    <View style={[styles.shutterInner, { backgroundColor: colors.primary }]} />
                  )}
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Zmień aparat"
                  onPress={() =>
                    setCameraFacing((facing) => (facing === 'back' ? 'front' : 'back'))
                  }
                  testID="switch-camera"
                  style={[styles.cameraControl, { backgroundColor: colors.card }]}
                >
                  <Ionicons name="camera-reverse-outline" size={21} color={colors.foreground} />
                </Pressable>
              </View>
              <Text style={[styles.cameraTip, { color: colors.mutedForeground }]}>
                Przełącz aparat, włącz latarkę lub zrób zdjęcie testowe.
              </Text>
              {capturedUri ? (
                <View style={[styles.captureResult, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <Image
                    source={{ uri: capturedUri }}
                    style={[styles.captureThumbnail, { backgroundColor: colors.secondary }]}
                  />
                  <View style={styles.captureCopy}>
                    <Text style={[styles.captureTitle, { color: colors.foreground }]}>
                      Zdjęcie wykonane
                    </Text>
                    <Text style={[styles.captureSubtitle, { color: colors.mutedForeground }]}>
                      Aparat odpowiada prawidłowo
                    </Text>
                  </View>
                  <Ionicons name="checkmark-circle" size={22} color={colors.success} />
                </View>
              ) : null}
            </>
          )}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { gap: 18 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandIcon: {
    width: 42,
    height: 42,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  headerCopy: { flex: 1, gap: 3 },
  brandName: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.5 },
  brandCaption: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  platformTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 7,
    borderWidth: 1,
    borderRadius: 99,
  },
  platformTagText: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.8 },
  hero: {
    minHeight: 174,
    borderWidth: 1,
    borderRadius: 24,
    overflow: 'hidden',
    paddingHorizontal: 20,
    paddingVertical: 22,
    justifyContent: 'center',
  },
  heroContent: { maxWidth: '72%', zIndex: 1, gap: 8 },
  heroKicker: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  heroKickerText: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.4 },
  liveDot: { width: 7, height: 7, borderRadius: 5 },
  heroTitle: { fontFamily: 'Inter_700Bold', fontSize: 25, letterSpacing: -0.8 },
  heroBody: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18 },
  heroGraphic: {
    position: 'absolute',
    right: -4,
    top: 8,
    width: 158,
    height: 158,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroRingOuter: {
    position: 'absolute',
    width: 148,
    height: 148,
    borderRadius: 80,
    borderWidth: 1,
  },
  heroRingInner: {
    position: 'absolute',
    width: 112,
    height: 112,
    borderRadius: 60,
    borderWidth: 1,
  },
  heroCore: {
    width: 68,
    height: 68,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroSpark: { position: 'absolute', width: 7, height: 7, borderRadius: 5 },
  heroSparkOne: { top: 22, right: 48 },
  heroSparkTwo: { bottom: 28, left: 35 },
  overviewRow: { flexDirection: 'row', gap: 11 },
  overviewCard: {
    flex: 1,
    minWidth: 0,
    padding: 13,
    borderRadius: 18,
    borderWidth: 1,
    gap: 8,
  },
  overviewTop: {
    minHeight: 21,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 4,
  },
  overviewLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  overviewLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.9 },
  overviewValue: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  progressTrack: { height: 5, borderRadius: 5, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 5 },
  overviewHint: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  networkSignal: { width: 7, height: 7, borderRadius: 5 },
  networkValue: { fontFamily: 'Inter_700Bold', fontSize: 14, marginTop: 1 },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 3,
  },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 19, letterSpacing: -0.3 },
  sectionCaption: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 4 },
  sectionCount: {
    width: 34,
    height: 34,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  moduleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 11 },
  moduleCard: {
    flexBasis: '47%',
    flexGrow: 1,
    minWidth: 148,
    minHeight: 174,
    padding: 15,
    borderRadius: 19,
    borderWidth: 1,
    overflow: 'hidden',
  },
  moduleTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 6,
    marginBottom: 15,
  },
  moduleIcon: {
    width: 38,
    height: 38,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderRadius: 99,
    borderWidth: 1,
    paddingHorizontal: 7,
    paddingVertical: 5,
    maxWidth: '68%',
  },
  statusDot: { width: 5, height: 5, borderRadius: 3 },
  statusPillText: { fontFamily: 'Inter_600SemiBold', fontSize: 8 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 1.15, marginBottom: 5 },
  moduleTitle: { fontFamily: 'Inter_700Bold', fontSize: 17, letterSpacing: -0.25 },
  moduleDetail: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 5, paddingRight: 5 },
  moduleArrow: {
    position: 'absolute',
    right: 14,
    bottom: 14,
    width: 26,
    height: 26,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  coordinateBox: { marginTop: 9, borderRadius: 9, paddingHorizontal: 7, paddingVertical: 6, gap: 3 },
  coordinateText: { fontFamily: 'Inter_600SemiBold', fontSize: 9, letterSpacing: 0.2 },
  inlineSpinner: { alignSelf: 'flex-start', marginTop: 11 },
  inlineMessage: { fontFamily: 'Inter_500Medium', fontSize: 9, lineHeight: 13, marginTop: 9, paddingRight: 13 },
  sensorCard: { flexBasis: '100%', padding: 15, borderRadius: 19, borderWidth: 1 },
  sensorHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  sensorHeadingCopy: { flex: 1 },
  sensorReadings: { flexDirection: 'row', alignItems: 'stretch', marginTop: 17 },
  axisBlock: { flex: 1, minWidth: 0 },
  axisLabel: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 0.8, marginBottom: 8 },
  axisValues: { flexDirection: 'row', gap: 5 },
  axisCell: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 9 },
  axisKey: { fontFamily: 'Inter_700Bold', fontSize: 8, marginBottom: 3 },
  axisNumber: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  axisUnit: { fontFamily: 'Inter_400Regular', fontSize: 8, marginTop: 6 },
  sensorDivider: { width: 1, marginHorizontal: 11, marginTop: 18, marginBottom: 6 },
  sensorFooter: { flexDirection: 'row', alignItems: 'center', gap: 7, marginTop: 14 },
  sensorFooterText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 9 },
  vibrationCard: {
    flexBasis: '47%',
    flexGrow: 1,
    minWidth: 148,
    minHeight: 178,
    padding: 15,
    borderRadius: 19,
    borderWidth: 1,
    overflow: 'hidden',
  },
  tapIcon: { width: 25, height: 25, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  vibrationWave: {
    height: 47,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginTop: 11,
    marginRight: 28,
  },
  waveBar: { width: 3, borderRadius: 3 },
  vibrationMessage: { fontFamily: 'Inter_600SemiBold', fontSize: 9, marginTop: 7, paddingRight: 18 },
  noteCard: {
    flexBasis: '100%',
    flexDirection: 'row',
    gap: 9,
    alignItems: 'flex-start',
    borderWidth: 1,
    borderRadius: 15,
    padding: 13,
  },
  noteText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
  footer: { alignItems: 'center', gap: 10, paddingTop: 5 },
  footerLine: { width: 44, height: 2, borderRadius: 2 },
  footerText: { fontFamily: 'Inter_400Regular', fontSize: 9, textAlign: 'center' },
  cameraScreen: { flex: 1, paddingHorizontal: 18, paddingBottom: 26 },
  cameraHeader: {
    minHeight: 70,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
    paddingBottom: 15,
  },
  cameraClose: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  cameraTitleGroup: { flex: 1, alignItems: 'center' },
  cameraTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  cameraSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  cameraGate: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 25 },
  cameraGateIcon: { width: 66, height: 66, borderRadius: 23, alignItems: 'center', justifyContent: 'center', marginBottom: 19 },
  cameraGateTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, textAlign: 'center' },
  cameraGateBody: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, textAlign: 'center', marginTop: 9, marginBottom: 22 },
  primaryAction: { minHeight: 46, borderRadius: 15, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  primaryActionText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  previewFrame: { flex: 1, minHeight: 260, borderRadius: 24, overflow: 'hidden', position: 'relative' },
  cameraPreview: { flex: 1 },
  cameraLoading: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center', gap: 11 },
  cameraLoadingText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  cameraCornerTL: { position: 'absolute', left: 14, top: 14, width: 20, height: 20, borderLeftWidth: 2, borderTopWidth: 2 },
  cameraCornerTR: { position: 'absolute', right: 14, top: 14, width: 20, height: 20, borderRightWidth: 2, borderTopWidth: 2 },
  cameraCornerBL: { position: 'absolute', left: 14, bottom: 14, width: 20, height: 20, borderLeftWidth: 2, borderBottomWidth: 2 },
  cameraCornerBR: { position: 'absolute', right: 14, bottom: 14, width: 20, height: 20, borderRightWidth: 2, borderBottomWidth: 2 },
  cameraInlineError: { fontFamily: 'Inter_500Medium', fontSize: 11, textAlign: 'center', marginTop: 10 },
  cameraControls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingVertical: 22 },
  cameraControl: { width: 48, height: 48, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  shutterOuter: { width: 70, height: 70, borderWidth: 3, borderRadius: 38, alignItems: 'center', justifyContent: 'center' },
  shutterInner: { width: 52, height: 52, borderRadius: 29 },
  cameraTip: { fontFamily: 'Inter_400Regular', fontSize: 10, textAlign: 'center', marginBottom: 5 },
  captureResult: { borderWidth: 1, borderRadius: 16, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 12 },
  captureThumbnail: { width: 43, height: 43, borderRadius: 10 },
  captureCopy: { flex: 1 },
  captureTitle: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  captureSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 3 },
});
