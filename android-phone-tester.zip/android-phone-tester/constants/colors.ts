/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#102033',
    tint: '#00A987',

    // Core surfaces
    background: '#F2F6F8',
    foreground: '#102033',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#102033',

    // Primary action color (buttons, links, active states)
    primary: '#00A987',
    primaryForeground: '#06251F',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E3ECEF',
    secondaryForeground: '#1B3348',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#E9F0F2',
    mutedForeground: '#687B8D',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#D5F6ED',
    accentForeground: '#0A604D',

    // Destructive actions (delete, error states)
    destructive: '#D94E58',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#D9E3E7',
    input: '#D9E3E7',
    success: '#008B6E',
    warning: '#A86509',
    track: '#DCE6E9',
  },

  dark: {
    text: '#F1F6FA',
    tint: '#6AE5C8',
    background: '#08111F',
    foreground: '#F1F6FA',
    card: '#101D30',
    cardForeground: '#EEF5FB',
    primary: '#6AE5C8',
    primaryForeground: '#06221D',
    secondary: '#1B2A40',
    secondaryForeground: '#E4EDF7',
    muted: '#17263A',
    mutedForeground: '#91A2B7',
    accent: '#173B3B',
    accentForeground: '#8AF0D6',
    destructive: '#FF7880',
    destructiveForeground: '#2A1015',
    border: '#24374D',
    input: '#293E54',
    success: '#73E4C7',
    warning: '#FFD27B',
    track: '#25374C',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 8,
};

export default colors;
