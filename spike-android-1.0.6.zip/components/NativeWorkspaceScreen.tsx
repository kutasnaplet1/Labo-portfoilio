import { Feather } from "@expo/vector-icons";
import {
  createFile,
  deleteFile,
  listFiles,
  updateFile,
  type Project,
  type ProjectFile,
} from "../lib/api";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from "react-native";
import { useColors } from "../hooks/useColors";

type Props = { project: Project; onBack: () => void };

export default function NativeWorkspaceScreen({ project, onBack }: Props) {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const wideLayout = width >= 760;
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [active, setActive] = useState<ProjectFile | null>(null);
  const activeRef = useRef<ProjectFile | null>(null);
  activeRef.current = active;
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [modal, setModal] = useState<"file" | "folder" | "rename" | null>(null);
  const [pathInput, setPathInput] = useState("");
  const [mobileSection, setMobileSection] = useState<"files" | "editor">("files");
  const [pathSaving, setPathSaving] = useState(false);

  const loadFiles = useCallback(async (keepSelection = true) => {
    setLoading(true);
    setError("");
    try {
      const result = await listFiles(project.id);
      setFiles(result);
      const selected = activeRef.current;
      if (keepSelection && selected) {
        const updated = result.find((file) => file.id === selected.id);
        if (updated) {
          setActive(updated);
          setDraft(updated.content);
        } else {
          setActive(null);
          setDraft("");
        }
      } else if (!keepSelection) {
        setActive(null);
        setDraft("");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się pobrać plików.");
    } finally {
      setLoading(false);
    }
  }, [project.id]);

  useEffect(() => { void loadFiles(false); }, [loadFiles]);

  const shownFiles = useMemo(() => files.filter((file) => {
    if (search.trim()) return file.path.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase());
    const parts = file.path.split("/");
    return !parts.slice(0, -1).some((_, index) => collapsed.has(parts.slice(0, index + 1).join("/")));
  }), [files, search, collapsed]);

  const isDirty = !!active && active.kind === "file" && draft !== active.content;

  const selectFile = (file: ProjectFile) => {
    if (isDirty) {
      Alert.alert("Niezapisane zmiany", "Zapisz lub odrzuć zmiany przed otwarciem innego pliku.", [
        { text: "Zostań", style: "cancel" },
        { text: "Odrzuć", style: "destructive", onPress: () => { setActive(file); setDraft(file.content); setMobileSection("editor"); } },
      ]);
      return;
    }
    if (file.kind === "folder") {
      setCollapsed((current) => {
        const next = new Set(current);
        if (next.has(file.path)) next.delete(file.path);
        else next.add(file.path);
        return next;
      });
      return;
    }
    setActive(file);
    setDraft(file.content);
    setMobileSection("editor");
  };

  const saveFile = async () => {
    if (!active || !isDirty) return;
    setSaving(true);
    setError("");
    try {
      const updated = await updateFile(project.id, active.id, { content: draft, version: active.version });
      setFiles((current) => current.map((file) => file.id === updated.id ? updated : file));
      setActive(updated);
      setDraft(updated.content);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się zapisać pliku.");
    } finally {
      setSaving(false);
    }
  };

  const openCreate = (kind: "file" | "folder") => {
    setPathInput("");
    setModal(kind);
  };

  const submitPath = async () => {
    const path = pathInput.trim().replace(/^\/+|\/+$/g, "");
    if (!path || path.split("/").some((part) => !part || part === "." || part === "..")) {
      setError("Podaj prawidłową ścieżkę bez segmentów „.” ani „..”.");
      return;
    }
    setError("");
    setPathSaving(true);
    try {
      if (modal === "rename" && active) {
        const updated = await updateFile(project.id, active.id, { path, version: active.version });
        setFiles((current) => current.map((file) => file.id === updated.id ? updated : file));
        setActive(updated);
        setDraft(updated.content);
      } else if (modal === "file" || modal === "folder") {
        const created = await createFile(project.id, { path, kind: modal });
        setFiles((current) => [...current, created].sort((a, b) => a.path.localeCompare(b.path)));
        if (created.kind === "file") {
          setActive(created);
          setDraft(created.content);
        setMobileSection("editor");
        }
      }
      setModal(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się wykonać operacji na pliku.");
    } finally {
      setPathSaving(false);
    }
  };

  const confirmDelete = (file: ProjectFile) => Alert.alert(
    file.kind === "folder" ? "Usunąć folder?" : "Usunąć plik?",
    file.kind === "folder" ? `Folder „${file.path}” i jego zawartość zostaną trwale usunięte.` : `Plik „${file.path}” zostanie trwale usunięty.`,
    [
      { text: "Anuluj", style: "cancel" },
      {
        text: "Usuń",
        style: "destructive",
        onPress: () => {
          void deleteFile(project.id, file.id)
            .then(() => {
              if (active?.id === file.id || (file.kind === "folder" && active?.path.startsWith(`${file.path}/`))) {
                setActive(null);
                setDraft("");
              }
              void loadFiles(false);
            })
            .catch((cause) => setError(cause instanceof Error ? cause.message : "Nie udało się usunąć elementu."));
        },
      },
    ],
  );

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => {
          if (isDirty) {
            Alert.alert("Niezapisane zmiany", "Czy na pewno wrócić bez zapisywania?", [
              { text: "Zostań", style: "cancel" },
              { text: "Wróć", style: "destructive", onPress: onBack },
            ]);
          } else onBack();
        }} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Wróć do projektów" testID="native-workspace-back">
          <Feather name="arrow-left" size={19} color={colors.foreground} />
        </Pressable>
        <View style={styles.headerTitleWrap}>
          <Text numberOfLines={1} style={[styles.brand, { color: colors.foreground }]}>{project.name}</Text>
          <Text style={[styles.headerCaption, { color: colors.mutedForeground }]}>Przestrzeń projektu</Text>
        </View>
        <Pressable
          onPress={() => void saveFile()}
          disabled={!isDirty || saving}
          style={[styles.saveButton, { backgroundColor: isDirty ? colors.primary : colors.muted, opacity: saving ? 0.7 : 1 }]}
          accessibilityRole="button"
          accessibilityLabel="Zapisz plik"
          testID="native-save-file"
        >
          {saving ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Feather name="save" size={15} color={isDirty ? colors.primaryForeground : colors.mutedForeground} />}
          <Text style={[styles.saveText, { color: isDirty ? colors.primaryForeground : colors.mutedForeground }]}>Zapisz</Text>
        </Pressable>
      </View>

      <View style={[styles.toolbar, { borderBottomColor: colors.border }]}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={14} color={colors.mutedForeground} />
          <TextInput accessibilityLabel="Szukaj plików" value={search} onChangeText={setSearch} placeholder="Szukaj pliku" placeholderTextColor={colors.mutedForeground} style={[styles.searchInput, { color: colors.foreground }]} testID="native-file-search" />
        </View>
        <Pressable onPress={() => openCreate("file")} style={styles.toolButton} accessibilityRole="button" accessibilityLabel="Utwórz plik" testID="native-create-file"><Feather name="file-plus" size={17} color={colors.foreground} /></Pressable>
        <Pressable onPress={() => openCreate("folder")} style={styles.toolButton} accessibilityRole="button" accessibilityLabel="Utwórz folder" testID="native-create-folder"><Feather name="folder-plus" size={17} color={colors.foreground} /></Pressable>
        <Pressable onPress={() => void loadFiles()} style={styles.toolButton} accessibilityRole="button" accessibilityLabel="Odśwież pliki" testID="native-refresh-files"><Feather name="refresh-cw" size={16} color={colors.foreground} /></Pressable>
      </View>

      {!wideLayout ? (
        <View style={[styles.mobileSwitch, { borderBottomColor: colors.border, backgroundColor: colors.background }]}>
          <Pressable onPress={() => setMobileSection("files")} accessibilityRole="button" accessibilityLabel="Pokaż listę plików" testID="native-pane-files" style={[styles.mobileSwitchButton, { borderColor: mobileSection === "files" ? colors.primary : colors.border, backgroundColor: mobileSection === "files" ? colors.accent : colors.card }]}>
            <Feather name="folder" size={14} color={mobileSection === "files" ? colors.primary : colors.mutedForeground} />
            <Text style={[styles.mobileSwitchText, { color: mobileSection === "files" ? colors.foreground : colors.mutedForeground }]}>Pliki</Text>
          </Pressable>
          <Pressable onPress={() => setMobileSection("editor")} accessibilityRole="button" accessibilityLabel="Pokaż edytor" testID="native-pane-editor" style={[styles.mobileSwitchButton, { borderColor: mobileSection === "editor" ? colors.primary : colors.border, backgroundColor: mobileSection === "editor" ? colors.accent : colors.card }]}>
            <Feather name="code" size={14} color={mobileSection === "editor" ? colors.primary : colors.mutedForeground} />
            <Text style={[styles.mobileSwitchText, { color: mobileSection === "editor" ? colors.foreground : colors.mutedForeground }]}>Edytor{isDirty ? " ·" : ""}</Text>
          </Pressable>
          {active ? <Text numberOfLines={1} style={[styles.currentPath, { color: colors.mutedForeground }]}>{active.path}</Text> : null}
        </View>
      ) : null}

      {error ? <View style={[styles.errorBanner, { borderBottomColor: colors.border }]}><Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text><Pressable onPress={() => setError("")}><Feather name="x" size={16} color={colors.mutedForeground} /></Pressable></View> : null}

      <View style={[styles.body, !wideLayout && styles.bodyStacked]}>
        {(wideLayout || mobileSection === "files") ? <View style={[styles.filePane, wideLayout ? { borderRightColor: colors.border, width: Math.min(300, Math.max(230, width * 0.27)) } : styles.filePaneMobile, !wideLayout && { borderBottomColor: colors.border }]}>
          <View style={styles.paneHeading}>
            <Text style={[styles.paneLabel, { color: colors.mutedForeground }]}>PLIKI</Text>
            <Text style={[styles.fileCount, { color: colors.mutedForeground }]}>{files.length}</Text>
          </View>
          {loading ? <View style={styles.loadingState}><View style={[styles.skeletonRow, { backgroundColor: colors.muted }]} /><View style={[styles.skeletonRow, styles.skeletonShort, { backgroundColor: colors.muted }]} /><View style={[styles.skeletonRow, { backgroundColor: colors.muted }]} /></View> : error && files.length === 0 ? (
            <View style={styles.fileError}>
              <Feather name="alert-circle" size={20} color={colors.destructive} />
              <Text style={[styles.noFiles, { color: colors.mutedForeground }]}>{error}</Text>
              <Pressable onPress={() => void loadFiles(false)} accessibilityRole="button" accessibilityLabel="Ponów pobieranie plików" testID="native-retry-files" style={[styles.retryButton, { borderColor: colors.border }]}>
                <Feather name="refresh-cw" size={14} color={colors.primary} /><Text style={[styles.retryLabel, { color: colors.foreground }]}>Spróbuj ponownie</Text>
              </Pressable>
            </View>
          ) : (
            <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.fileListContent}>
              {shownFiles.map((file) => {
                const depth = Math.max(0, file.path.split("/").length - 1);
                const isActive = active?.id === file.id;
                const isFolderCollapsed = collapsed.has(file.path);
                return (
                  <View key={file.id} style={[styles.fileRow, isActive && { backgroundColor: colors.accent, borderColor: colors.primary + "66" }, { borderColor: colors.border }]}>
                    <Pressable onPress={() => selectFile(file)} style={styles.fileSelect} accessibilityRole="button" accessibilityLabel={`${file.kind === "folder" ? (isFolderCollapsed ? "Rozwiń folder" : "Zwiń folder") : "Otwórz plik"} ${file.path}`} testID={`native-file-${file.id}`}>
                      <View style={{ width: Math.min(depth * 10, 40) }} />
                      <Feather
                        name={file.kind === "folder" ? "folder" : iconForPath(file.path)}
                        size={14}
                        color={isActive ? colors.primary : colors.mutedForeground}
                      />
                      <View style={styles.fileNameWrap}>
                        <Text style={[styles.fileName, { color: isActive ? colors.foreground : colors.mutedForeground }]}>{file.path.split("/").pop()}</Text>
                        {depth > 0 ? <Text selectable style={[styles.filePathHint, { color: colors.mutedForeground }]}>{file.path}</Text> : null}
                      </View>
                    </Pressable>
                    <Pressable onPress={() => {
                      setPathInput(file.path);
                      setModal("rename");
                    }} accessibilityRole="button" accessibilityLabel={`Zmień ścieżkę ${file.path}`} style={styles.fileAction} testID={`native-rename-file-${file.id}`}><Feather name="edit-2" size={13} color={colors.mutedForeground} /></Pressable>
                    <Pressable onPress={() => confirmDelete(file)} accessibilityRole="button" accessibilityLabel={`Usuń ${file.path}`} style={styles.fileAction} testID={`native-delete-file-${file.id}`}><Feather name="trash-2" size={13} color={colors.destructive} /></Pressable>
                  </View>
                );
              })}
              {!loading && shownFiles.length === 0 ? <Text style={[styles.noFiles, { color: colors.mutedForeground }]}>{search ? "Brak wyników." : "Brak plików."}</Text> : null}
            </ScrollView>
          )}
        </View> : null}

        {(wideLayout || mobileSection === "editor") ? <View style={[styles.editorPane, !wideLayout && styles.editorPaneMobile]}>
          {active ? (
            <>
              <View style={[styles.editorHeader, { borderBottomColor: colors.border }]}>
                <Feather name={iconForPath(active.path)} size={14} color={colors.primary} />
                <Text selectable style={[styles.editorFileName, { color: colors.foreground }]}>{active.path}</Text>
                {isDirty ? <View style={[styles.dirtyDot, { backgroundColor: colors.primary }]} /> : null}
                <Pressable onPress={() => { setPathInput(active.path); setModal("rename"); }} style={styles.toolButton} accessibilityLabel="Zmień nazwę pliku"><Feather name="edit-2" size={14} color={colors.mutedForeground} /></Pressable>
              </View>
              <View style={styles.codeArea}>
                <ScrollView style={[styles.gutter, { backgroundColor: colors.background }]} scrollEnabled={false}>
                  <Text style={[styles.lineNumbers, { color: colors.mutedForeground }]}>{Array.from({ length: Math.max(draft.split("\n").length, 1) }, (_, i) => i + 1).join("\n")}</Text>
                </ScrollView>
                <TextInput
                  value={draft}
                  onChangeText={setDraft}
                  multiline
                  autoCapitalize="none"
                  autoCorrect={false}
                  spellCheck={false}
                  textAlignVertical="top"
                  style={[styles.codeInput, { color: colors.foreground }]}
                  placeholder="Wpisz kod…"
                  placeholderTextColor={colors.mutedForeground}
                  testID="native-code-editor"
                  accessibilityLabel={`Kod pliku ${active.path}`}
                />
              </View>
              <View style={[styles.statusBar, { borderTopColor: colors.border }]}>
                <Text style={[styles.statusText, { color: colors.mutedForeground }]}>{isDirty ? "Niezapisane zmiany" : `v${active.version} · Zapisano`}</Text>
                <Text style={[styles.statusText, { color: colors.mutedForeground }]}>{draft.split("\n").length} linii</Text>
              </View>
            </>
          ) : (
            <View style={styles.editorEmpty}>
              <Feather name="file-text" size={25} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Otwórz plik</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Wybierz plik z listy albo utwórz nowy.</Text>
            </View>
          )}
        </View> : null}
      </View>

      <Modal transparent animationType="fade" visible={modal !== null} onRequestClose={() => setModal(null)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>{modal === "rename" ? "Zmień ścieżkę" : modal === "folder" ? "Nowy folder" : "Nowy plik"}</Text>
            <Text style={[styles.modalHint, { color: colors.mutedForeground }]}>Ścieżka w projekcie, np. src/app.ts</Text>
            <TextInput
              autoFocus
              value={pathInput}
              onChangeText={setPathInput}
              autoCapitalize="none"
              autoCorrect={false}
              placeholder="folder/nazwa.ext"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.modalInput, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
              testID="native-file-path"
            />
            {error ? <Text style={[styles.modalError, { color: colors.destructive }]}>{error}</Text> : null}
            <View style={styles.modalActions}>
              <Pressable onPress={() => { setModal(null); setError(""); }} style={[styles.cancelButton, { borderColor: colors.border }]} accessibilityRole="button" testID="native-cancel-file-action"><Text style={[styles.cancelText, { color: colors.foreground }]}>Anuluj</Text></Pressable>
              <Pressable disabled={pathSaving || !pathInput.trim()} onPress={() => void submitPath()} style={[styles.confirmButton, { backgroundColor: colors.primary, opacity: pathSaving || !pathInput.trim() ? 0.55 : 1 }]} accessibilityRole="button" testID="native-confirm-file-action">
                {pathSaving ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Text style={[styles.confirmText, { color: colors.primaryForeground }]}>{modal === "rename" ? "Zapisz" : "Utwórz"}</Text>}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function iconForPath(path: string) {
  const extension = path.split(".").pop()?.toLowerCase();
  if (extension === "json") return "settings";
  if (extension === "md") return "book-open";
  if (["png", "jpg", "svg"].includes(extension ?? "")) return "image";
  return "file-text";
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { minHeight: 58, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", paddingHorizontal: 8, gap: 5 },
  headerIcon: { width: 42, height: 42, alignItems: "center", justifyContent: "center" },
  headerTitleWrap: { flex: 1 },
  brand: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  headerCaption: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 2 },
  saveButton: { minWidth: 76, height: 36, borderRadius: 11, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 9 },
  saveText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  toolbar: { minHeight: 52, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8 },
  searchBox: { flex: 1, minWidth: 0, height: 38, borderWidth: 1, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 9 },
  searchInput: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 11, paddingVertical: 0 },
  toolButton: { width: 38, height: 40, alignItems: "center", justifyContent: "center" },
  errorBanner: { minHeight: 40, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 12, gap: 8 },
  errorText: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 16 },
  mobileSwitch: { minHeight: 52, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 7, gap: 7 },
  mobileSwitchButton: { minHeight: 36, minWidth: 86, borderWidth: 1, borderRadius: 10, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 11 },
  mobileSwitchText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  currentPath: { flex: 1, minWidth: 0, fontFamily: "monospace", fontSize: 9, textAlign: "right" },
  body: { flex: 1, minHeight: 0, flexDirection: "row" },
  bodyStacked: { flexDirection: "column" },
  filePane: { minWidth: 0, borderRightWidth: StyleSheet.hairlineWidth, paddingTop: 10 },
  filePaneMobile: { flex: 1, borderRightWidth: 0, paddingTop: 10 },
  paneHeading: { minHeight: 28, flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", paddingHorizontal: 12 },
  paneLabel: { fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 1.1 },
  fileCount: { fontFamily: "monospace", fontSize: 10 },
  loader: { marginTop: 20 },
  loadingState: { paddingHorizontal: 12, gap: 10, paddingTop: 8 },
  skeletonRow: { height: 18, borderRadius: 5, opacity: 0.75 },
  skeletonShort: { width: "68%" },
  fileError: { alignItems: "center", gap: 9, padding: 18 },
  retryButton: { minHeight: 38, borderWidth: 1, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 12 },
  retryLabel: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  fileListContent: { paddingBottom: 20 },
  fileRow: { minHeight: 48, flexDirection: "row", alignItems: "center", paddingRight: 4, borderTopWidth: StyleSheet.hairlineWidth },
  fileSelect: { flex: 1, minWidth: 0, flexDirection: "row", alignItems: "center", gap: 7, paddingLeft: 7, minHeight: 46, paddingVertical: 5 },
  fileNameWrap: { flex: 1, minWidth: 0, gap: 2 },
  fileName: { fontFamily: "Inter_500Medium", fontSize: 12, lineHeight: 16 },
  filePathHint: { fontFamily: "monospace", fontSize: 9, lineHeight: 12 },
  fileAction: { width: 34, height: 40, alignItems: "center", justifyContent: "center" },
  noFiles: { fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 17, textAlign: "center", padding: 18 },
  editorPane: { flex: 1, minWidth: 0, minHeight: 0 },
  editorPaneMobile: { flex: 1 },
  editorHeader: { minHeight: 46, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", gap: 8, paddingLeft: 11, paddingRight: 4, paddingVertical: 6 },
  editorFileName: { flex: 1, minWidth: 0, fontFamily: "Inter_500Medium", fontSize: 11, lineHeight: 16 },
  dirtyDot: { width: 6, height: 6, borderRadius: 3 },
  codeArea: { flex: 1, minHeight: 0, flexDirection: "row" },
  gutter: { width: 38, paddingTop: 12 },
  lineNumbers: { fontFamily: "monospace", fontSize: 11, lineHeight: 19, textAlign: "right", paddingRight: 8 },
  codeInput: { flex: 1, minWidth: 0, fontFamily: "monospace", fontSize: 12, lineHeight: 19, paddingHorizontal: 10, paddingTop: 12, paddingBottom: 18, includeFontPadding: false },
  statusBar: { minHeight: 32, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 10, gap: 8 },
  statusText: { fontFamily: "Inter_400Regular", fontSize: 10 },
  editorEmpty: { flex: 1, alignItems: "center", justifyContent: "center", gap: 8, padding: 18 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 18, textAlign: "center" },
  modalBackdrop: { flex: 1, backgroundColor: "#0009", justifyContent: "center", padding: 20 },
  modalCard: { borderWidth: 1, borderRadius: 18, padding: 18 },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 17 },
  modalHint: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 6, marginBottom: 12 },
  modalInput: { borderWidth: 1, borderRadius: 10, minHeight: 45, paddingHorizontal: 11, fontFamily: "monospace", fontSize: 12 },
  modalError: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 8 },
  modalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 8, marginTop: 15 },
  cancelButton: { minWidth: 80, height: 40, borderWidth: 1, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  cancelText: { fontFamily: "Inter_500Medium", fontSize: 11 },
  confirmButton: { minWidth: 90, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  confirmText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
});
