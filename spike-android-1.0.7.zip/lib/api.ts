export function getServerOrigin(): string | null {
  const value = process.env.EXPO_PUBLIC_DOMAIN?.trim();
  if (!value) return null;
  try {
    const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
    if (url.protocol !== "https:" || url.username || url.password) return null;
    return url.origin;
  } catch {
    return null;
  }
}

export const SERVER_ORIGIN = getServerOrigin();

export type TokenGetter = () => Promise<string | null>;
export type Identity = { id: string; email: string; role: "owner" | "admin" | "member"; displayName: string };
export type Project = {
  id: string;
  name: string;
  description: string;
  template: string;
  status: string;
  createdAt: string;
  updatedAt: string;
};
export type ProjectInputTemplate = "blank" | "web" | "typescript";
export type ProjectFile = {
  id: string;
  projectId: string;
  path: string;
  kind: "file" | "folder";
  content: string;
  version: number;
  updatedAt: string;
};
export type FileInput = { path: string; kind: "file" | "folder"; content?: string };
export type FileUpdate = { path?: string; content?: string; version: number };
export type SpikeActivity = { id: string; action: string; path: string | null; createdAt: string };
export type SpikeChange = { id: string; fileId: string; action: string; path: string; beforePath?: string | null; afterPath?: string | null; createdAt?: string };
export type ChatMessage = { id: string; role: "user" | "assistant"; content: string; status: "pending" | "complete" | "failed"; createdAt: string; changes?: SpikeChange[] };
export type Capabilities = { execution: boolean; executionReason: string; ai: boolean; aiModel: string; aiTokensUsedThisMonth: number; aiMonthlyTokenLimit: number | null };
export type Attachment = { id: string; name: string; contentType: string; sizeBytes: number; createdAt: string };
export type AccessUser = { id: string; email: string; role: "owner" | "admin" | "member"; active: boolean; bound: boolean; createdAt: string; monthlyTokenLimit: number | null; aiTokensUsedThisMonth: number };
export type InstanceSettings = { welcomeMessage: string };
export type AgentJob = { id: string; target: "test" | string };
export type AgentJobResult = { exitCode: number; output: string; durationMs: number };

let nativeTokenGetter: TokenGetter | null = null;

export function setNativeAuthTokenGetter(getToken: TokenGetter | null) {
  nativeTokenGetter = getToken;
}
export const getNativeBearerToken = async () => nativeTokenGetter ? nativeTokenGetter() : null;

export async function apiRequest<T>(
  path: string,
  init: RequestInit = {},
): Promise<T> {
  if (!SERVER_ORIGIN) throw new Error("Brak adresu serwera Spike.");
  const getToken = nativeTokenGetter;
  if (!getToken) {
    throw Object.assign(new Error("Sesja logowania nie jest jeszcze gotowa. Spróbuj ponownie."), { status: 401 });
  }
  const token = await getToken();
  if (!token) {
    throw Object.assign(new Error("Nie udało się pobrać sesji logowania. Zaloguj się ponownie."), { status: 401 });
  }
  const headers = new Headers(init.headers);
  headers.set("Accept", "application/json");
  headers.set("Authorization", `Bearer ${token}`);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");

  const response = await fetch(`${SERVER_ORIGIN}${path}`, { ...init, headers });
  const text = await response.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }
  if (!response.ok) {
    const message =
      data && typeof data === "object" && "error" in data && typeof data.error === "string"
        ? data.error
        : `Błąd serwera (${response.status}).`;
    throw Object.assign(new Error(message), { status: response.status });
  }
  return data as T;
}

export const getMe = (init?: RequestInit) => apiRequest<Identity>("/api/me", init);
export const listProjects = () => apiRequest<Project[]>("/api/projects");
export const createProject = (input: { name: string; description?: string; template: ProjectInputTemplate }) =>
  apiRequest<Project>("/api/projects", { method: "POST", body: JSON.stringify(input) });
export const renameProject = (id: string, input: { name: string }) =>
  apiRequest<Project>(`/api/projects/${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify(input) });
export const deleteProject = (id: string) =>
  apiRequest<void>(`/api/projects/${encodeURIComponent(id)}`, { method: "DELETE" });
export const listFiles = (projectId: string) =>
  apiRequest<ProjectFile[]>(`/api/projects/${encodeURIComponent(projectId)}/files`);
export const createFile = (projectId: string, input: FileInput) =>
  apiRequest<ProjectFile>(`/api/projects/${encodeURIComponent(projectId)}/files`, { method: "POST", body: JSON.stringify(input) });
export const updateFile = (projectId: string, fileId: string, input: FileUpdate) =>
  apiRequest<ProjectFile>(`/api/projects/${encodeURIComponent(projectId)}/files/${encodeURIComponent(fileId)}`, { method: "PATCH", body: JSON.stringify(input) });
export const deleteFile = (projectId: string, fileId: string) =>
  apiRequest<void>(`/api/projects/${encodeURIComponent(projectId)}/files/${encodeURIComponent(fileId)}`, { method: "DELETE" });
export const getProject = (id: string) => apiRequest<Project>(`/api/projects/${encodeURIComponent(id)}`);
export const listActivity = (id: string) => apiRequest<SpikeActivity[]>(`/api/projects/${encodeURIComponent(id)}/activity`);
export const getCapabilities = () => apiRequest<Capabilities>("/api/capabilities");
export const listChat = (id: string) => apiRequest<ChatMessage[]>(`/api/projects/${encodeURIComponent(id)}/chat`);
export const sendChat = (id: string, input: { content: string; fileId?: string; attachmentIds?: string[]; protectedFileIds?: string[] }) =>
  apiRequest<ChatMessage>(`/api/projects/${encodeURIComponent(id)}/chat`, { method: "POST", body: JSON.stringify(input) });
export const listAttachments = (id: string) => apiRequest<Attachment[]>(`/api/projects/${encodeURIComponent(id)}/attachments`);
export const requestAttachmentUpload = (projectId: string, input: { name: string; sizeBytes: number; contentType: string }) =>
  apiRequest<{ id: string; uploadUrl: string }>(`/api/projects/${encodeURIComponent(projectId)}/attachments/request`, { method: "POST", body: JSON.stringify(input) });
export const completeAttachmentUpload = (projectId: string, attachmentId: string) =>
  apiRequest<Attachment>(`/api/projects/${encodeURIComponent(projectId)}/attachments/${encodeURIComponent(attachmentId)}/complete`, { method: "POST", body: "{}" });
export const deleteAttachment = (projectId: string, attachmentId: string) =>
  apiRequest<void>(`/api/projects/${encodeURIComponent(projectId)}/attachments/${encodeURIComponent(attachmentId)}`, { method: "DELETE" });
export const importZipAttachment = (projectId: string, attachmentId: string) =>
  apiRequest<{ importedFiles: number; skippedFiles: number; importedPaths?: string[]; warnings?: string[] }>(`/api/projects/${encodeURIComponent(projectId)}/attachments/${encodeURIComponent(attachmentId)}/import-zip`, { method: "POST", body: "{}" });
export const listAdminUsers = () => apiRequest<AccessUser[]>("/api/admin/users");
export const addAdminUser = (email: string) => apiRequest<AccessUser>("/api/admin/users", { method: "POST", body: JSON.stringify({ email }) });
export const updateAdminUser = (id: string, data: { role?: "admin" | "member"; active?: boolean; monthlyTokenLimit?: number | null }) =>
  apiRequest<AccessUser>(`/api/admin/users/${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify(data) });
export const deleteAdminUser = (id: string) => apiRequest<void>(`/api/admin/users/${encodeURIComponent(id)}`, { method: "DELETE" });
export const getInstanceSettings = () => apiRequest<InstanceSettings>("/api/admin/settings");
export const updateInstanceSettings = (data: InstanceSettings) => apiRequest<InstanceSettings>("/api/admin/settings", { method: "PATCH", body: JSON.stringify(data) });
export const claimAgentJob = (projectId: string) => apiRequest<AgentJob | null>(`/api/projects/${encodeURIComponent(projectId)}/agent-jobs/claim`);
export const finishAgentJob = (projectId: string, jobId: string, result: AgentJobResult) =>
  apiRequest<{ id: string; target: string }>(`/api/projects/${encodeURIComponent(projectId)}/agent-jobs/${encodeURIComponent(jobId)}/finish`, { method: "POST", body: JSON.stringify(result) });
