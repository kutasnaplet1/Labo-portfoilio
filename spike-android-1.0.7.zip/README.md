# Spike na Androida

Spike Android jest aplikacją Expo z natywnymi ekranami logowania, projektów,
plików i edycji kodu. Nie osadza strony Spike ani nie używa WebView. Projekty i
pliki są pobierane i zapisywane przez zabezpieczone API Spike.

## Logowanie

Logowanie odbywa się bezpośrednio na natywnym ekranie Spike przez e-mail i hasło.
Rejestracja potwierdza własność skrzynki kodem e-mail. Ekran zawiera też zmianę
zapomnianego hasła kodem wysłanym na e-mail. Po zalogowaniu serwer sprawdza
zweryfikowany adres oraz uprawnienia Spike; samo utworzenie konta nie nadaje dostępu.

APK pobiera publiczny klucz Clerk z endpointu serwera. Nie umieszczaj sekretów
Clerk w repozytorium GitHub ani w APK. Endpoint `/api/auth/public-config`
zwraca klucz publishable i, w produkcji, adres proxy Clerk pod tą samą domeną.
Opublikuj zaktualizowany serwer przed budową APK, inaczej logowanie może nie
zakończyć inicjalizacji.

## Funkcje natywne

- logowanie e-mail/hasło i rejestracja z kodem potwierdzającym e-mail przez Clerk,
- akceptacja regulaminu z osobnym potwierdzeniem i informacja o prywatności,
- wyszukiwanie, sortowanie, tworzenie, zmiana nazwy i usuwanie projektów,
- import projektu z ZIP-a (limit serwera: 100 MB),
- zmiana nazwy i usuwanie projektu z potwierdzeniem,
- przełączanie projektów, eksport plików projektu do ZIP-a i udostępnianie archiwum,
- wyszukiwalny eksplorator, tworzenie/zmiana/usuwanie plików i folderów,
- wielokartowy edytor z numerami linii, kolorowaniem składni, lokalnymi szkicami, autozapisem i obsługą konfliktów wersji,
- rozmowy AI zapisane na serwerze, stan pracy, pokazanie zmienionych plików oraz przesyłanie, wybór, pobieranie, import ZIP-a i usuwanie załączników,
- natywne ustawienia profilu i edytora,
- panel administracyjny do dostępu, ról, limitów tokenów AI i komunikatu instancji,
- osobne panele mobilne; na szerokich ekranach jednoczesny eksplorator, edytor, panel dolny i panel AI/podglądu.

Natywne ekrany nie używają WebView i korzystają z zabezpieczonego API Spike.
Podgląd projektu, terminal i uruchamianie testów pozostają wyłączone w Expo:
strona uruchamia je w przeglądarkowym WebContainer, którego nie można bezpiecznie
przenieść do aplikacji natywnej bez osobnego runnera. Aplikacja pokazuje jawny
komunikat zamiast fałszywego wyniku. Hosting beta jest wyłącznie informacyjny.

## Budowanie APK przez GitHub Actions

1. Wypakuj zawartość ZIP-a do głównego katalogu repozytorium GitHub.
2. Wypchnij pliki na gałąź `main`.
3. Otwórz **Actions → Build APK → Run workflow**.
4. Pobierz artefakt `spike-android-apk`, który zawiera `spike-android.apk`.

Workflow ustawia domenę serwera jako `EXPO_PUBLIC_DOMAIN`. Jeśli domena Spike
się zmieni, zaktualizuj tę wartość w `.github/workflows/build-apk.yml`.

## Podpis i aktualizacje

Do kolejnych aktualizacji użyj dokładnie tego samego klucza podpisu. Możesz
przechowywać go jako sekrety GitHub Actions:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Jeśli obecna instalacja jest podpisana kluczem debug, kolejny build również
musi użyć tego samego klucza debug. Zmiana klucza podpisu wymaga odinstalowania
starej aplikacji i powoduje utratę jej lokalnych danych.

Identyfikator aplikacji pozostaje `com.labo17dev.spike`. Dla tej wersji
`VERSION` to `1.0.7`, a `VERSION_CODE` to `8`. Przy następnym APK zwiększ
`VERSION_CODE`, zachowaj identyfikator aplikacji i ten sam klucz podpisu.
Android zainstaluje taki APK jako aktualizację bez usuwania danych.

Play Protect może ostrzegać o aplikacjach instalowanych spoza Google Play.
Nie da się bezpiecznie wyłączyć tego ostrzeżenia kodem aplikacji.
