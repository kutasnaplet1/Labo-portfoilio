const spikePalette = {
  text: "#e9e9e2",
  tint: "#aad643",
  background: "#121217",
  foreground: "#e9e9e2",
  card: "#18191f",
  cardForeground: "#e9e9e2",
  primary: "#aad643",
  primaryForeground: "#101119",
  secondary: "#22232a",
  secondaryForeground: "#e9e9e2",
  muted: "#1e1f25",
  mutedForeground: "#92949f",
  accent: "#24262d",
  accentForeground: "#e9e9e2",
  destructive: "#df514b",
  destructiveForeground: "#f8f7f3",
  border: "#25262d",
  input: "#303139",
};

const colors = {
  light: spikePalette,
  dark: spikePalette,
  radius: 8,
};

export default colors;
