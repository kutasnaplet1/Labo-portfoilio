import { Feather } from "@expo/vector-icons";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Alert, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { addAdminUser, deleteAdminUser, getInstanceSettings, listAdminUsers, updateAdminUser, updateInstanceSettings, type AccessUser, type Identity, type InstanceSettings } from "../lib/api";
import { useColors } from "../hooks/useColors";

type Props = { identity: Identity; onBack: () => void };
export default function NativeAdminScreen({ identity, onBack }: Props) {
  const colors = useColors();
  const authorizedInUi = identity.role === "owner" || identity.role === "admin";
  const [users, setUsers] = useState<AccessUser[]>([]);
  const [settings, setSettings] = useState<InstanceSettings | null>(null);
  const [message, setMessage] = useState("");
  const [query, setQuery] = useState("");
  const [email, setEmail] = useState("");
  const [quotaTarget, setQuotaTarget] = useState<AccessUser | null>(null);
  const [quota, setQuota] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [u, s] = await Promise.all([listAdminUsers(), getInstanceSettings()]);
      setUsers(u); setSettings(s); setMessage(s.welcomeMessage);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Nie udało się pobrać ustawień administracyjnych."); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { if (authorizedInUi) void refresh(); else setLoading(false); }, [authorizedInUi, refresh]);
  const filtered = useMemo(() => {
    const order = { owner: 0, admin: 1, member: 2 };
    return users.filter((u) => u.email.toLowerCase().includes(query.trim().toLowerCase())).sort((a, b) => order[a.role] - order[b.role] || a.email.localeCompare(b.email));
  }, [users, query]);
  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true); setError("");
    try { await fn(); await refresh(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Operacja nie powiodła się."); }
    finally { setBusy(false); }
  };
  const self = (user: AccessUser) => user.id === identity.id || user.email.toLowerCase() === identity.email.toLowerCase();
  if (!authorizedInUi) return <View style={[styles.screen, styles.denied, { backgroundColor: colors.background }]}><Feather name="shield" size={28} color={colors.mutedForeground} /><Text style={[styles.heading, { color: colors.foreground }]}>Panel administracyjny niedostępny</Text><Text style={[styles.sub, { color: colors.mutedForeground }]}>Ta sekcja jest dostępna wyłącznie dla właściciela i administratorów.</Text><Pressable onPress={onBack} style={[styles.primaryButton, { backgroundColor: colors.primary }]}><Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Wróć</Text></Pressable></View>;
  const add = () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) { setError("Podaj prawidłowy adres e-mail."); return; }
    void run(async () => { await addAdminUser(email.trim().toLowerCase()); setEmail(""); });
  };
  const saveQuota = () => {
    if (!quotaTarget || (quota !== "" && (!/^\d+$/.test(quota) || Number(quota) > 1_000_000_000))) return;
    void run(() => updateAdminUser(quotaTarget.id, { monthlyTokenLimit: quota === "" ? null : Number(quota) }).then(() => setQuotaTarget(null)));
  };
  const saveSettings = () => {
    if (!settings || message.length > 240) return;
    void run(() => updateInstanceSettings({ welcomeMessage: message.trim() }).then(setSettings));
  };
  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}><Pressable onPress={onBack} accessibilityRole="button" accessibilityLabel="Wróć"><Feather name="arrow-left" size={20} color={colors.foreground} /></Pressable><Text style={[styles.headerTitle, { color: colors.foreground }]}>Administracja</Text><Pressable onPress={() => void refresh()} accessibilityRole="button" accessibilityLabel="Odśwież"><Feather name="refresh-cw" size={17} color={colors.mutedForeground} /></Pressable></View>
      <ScrollView contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={loading} onRefresh={() => void refresh()} tintColor={colors.primary} />}>
        <Text style={[styles.heading, { color: colors.foreground }]}>Dostęp i ustawienia</Text>
        <Text style={[styles.sub, { color: colors.mutedForeground }]}>Uprawnienie e-mail pozwala się zarejestrować. Powiązanie następuje przy pierwszym zweryfikowanym logowaniu.</Text>
        {error ? <View style={[styles.errorBox, { borderColor: colors.destructive }]}><Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text><Pressable onPress={() => setError("")}><Feather name="x" size={16} color={colors.destructive} /></Pressable></View> : null}
        <Text style={[styles.sectionLabel, { color: colors.primary }]}>DOSTĘP DO SPIKE · {users.length}</Text>
        <View style={[styles.addBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TextInput value={email} onChangeText={setEmail} placeholder="adres@firma.pl" placeholderTextColor={colors.mutedForeground} keyboardType="email-address" autoCapitalize="none" style={[styles.input, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]} accessibilityLabel="Nowy dopuszczony e-mail" />
          <Pressable disabled={busy || !email.trim()} onPress={add} style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: busy || !email.trim() ? 0.55 : 1 }]} accessibilityRole="button"><Feather name="user-plus" size={15} color={colors.primaryForeground} /><Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Dopuść adres</Text></Pressable>
        </View>
        <TextInput value={query} onChangeText={setQuery} placeholder="Filtruj po e-mailu" placeholderTextColor={colors.mutedForeground} autoCapitalize="none" style={[styles.input, styles.search, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.card }]} accessibilityLabel="Filtruj użytkowników" />
        {loading && users.length === 0 ? <ActivityIndicator color={colors.primary} style={{ margin: 24 }} /> : filtered.length === 0 ? <View style={[styles.empty, { borderColor: colors.border }]}><Text style={[styles.sub, { color: colors.mutedForeground }]}>{query ? "Brak pasujących adresów." : "Brak uprawnień. Dodaj pierwszy adres powyżej."}</Text></View> :
          filtered.map((user) => {
            const locked = user.role === "owner" || self(user);
            return <View key={user.id} style={[styles.userCard, { backgroundColor: colors.card, borderColor: colors.border, opacity: user.active ? 1 : 0.65 }]}>
              <View style={styles.userTop}><View style={{ flex: 1 }}><Text style={[styles.userEmail, { color: colors.foreground }]}>{user.email}{self(user) ? " · Ty" : ""}</Text><Text style={[styles.userMeta, { color: colors.mutedForeground }]}>{user.bound ? "Tożsamość powiązana" : "Oczekuje na pierwsze logowanie"}{user.active ? "" : " · Dostęp cofnięty"}</Text></View><Text style={[styles.role, { color: user.role === "admin" || user.role === "owner" ? colors.primary : colors.mutedForeground }]}>{user.role === "owner" ? "WŁAŚCICIEL" : user.role === "admin" ? "ADMIN" : "CZŁONEK"}</Text></View>
              <Text style={[styles.userMeta, { color: colors.mutedForeground }]}>Dodano {new Date(user.createdAt).toLocaleDateString("pl-PL")} · AI {user.aiTokensUsedThisMonth.toLocaleString("pl-PL")} / {user.monthlyTokenLimit === null ? "bez limitu" : user.monthlyTokenLimit.toLocaleString("pl-PL")} tokenów w tym miesiącu</Text>
              {!locked ? <View style={[styles.actionRow, { borderTopColor: colors.border }]}>
                <Pressable onPress={() => { setQuotaTarget(user); setQuota(user.monthlyTokenLimit === null ? "" : String(user.monthlyTokenLimit)); }} style={styles.action}><Feather name="bar-chart-2" size={14} color={colors.primary} /><Text style={[styles.actionLabel, { color: colors.foreground }]}>Limit AI</Text></Pressable>
                <Pressable onPress={() => Alert.alert("Zmienić rolę?", `Zaktualizować uprawnienia dla ${user.email}?`, [{ text: "Anuluj", style: "cancel" }, { text: "Potwierdź", onPress: () => void run(() => updateAdminUser(user.id, { role: user.role === "admin" ? "member" : "admin" })) }])} style={styles.action}><Feather name="shield" size={14} color={colors.primary} /><Text style={[styles.actionLabel, { color: colors.foreground }]}>{user.role === "admin" ? "Odbierz admina" : "Nadaj admina"}</Text></Pressable>
                <Pressable onPress={() => Alert.alert(user.active ? "Cofnąć dostęp?" : "Przywrócić dostęp?", user.email, [{ text: "Anuluj", style: "cancel" }, { text: "Potwierdź", onPress: () => void run(() => updateAdminUser(user.id, { active: !user.active })) }])} style={styles.action}><Feather name={user.active ? "slash" : "rotate-ccw"} size={14} color={colors.mutedForeground} /><Text style={[styles.actionLabel, { color: colors.foreground }]}>{user.active ? "Cofnij" : "Przywróć"}</Text></Pressable>
                <Pressable onPress={() => Alert.alert("Usunąć dostęp?", `${user.email} utraci dostęp. Konto logowania i zapisane projekty nie zostaną skasowane.`, [{ text: "Anuluj", style: "cancel" }, { text: "Usuń", style: "destructive", onPress: () => void run(() => deleteAdminUser(user.id)) }])} style={styles.action}><Feather name="trash-2" size={14} color={colors.destructive} /><Text style={[styles.actionLabel, { color: colors.destructive }]}>Usuń</Text></Pressable>
              </View> : <Text style={[styles.locked, { color: colors.mutedForeground }]}><Feather name="lock" size={12} color={colors.mutedForeground} /> {user.role === "owner" ? "Właściciel jest niezmienny" : "Nie możesz edytować własnego dostępu"}</Text>}
            </View>;
          })}
        <Text style={[styles.sectionLabel, { color: colors.primary, marginTop: 28 }]}>USTAWIENIA INSTANCJI</Text>
        <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.label, { color: colors.foreground }]}>Komunikat powitalny</Text>
          <Text style={[styles.userMeta, { color: colors.mutedForeground, marginTop: 4 }]}>Wyświetlany nad listą projektów wszystkim członkom.</Text>
          <TextInput value={message} onChangeText={setMessage} maxLength={240} multiline placeholder="Komunikat dla zespołu" placeholderTextColor={colors.mutedForeground} style={[styles.multiline, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]} />
          <View style={styles.settingsFooter}><Text style={[styles.userMeta, { color: colors.mutedForeground }]}>{message.length}/240</Text><Pressable disabled={!settings || message === settings.welcomeMessage || busy} onPress={saveSettings} style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: !settings || message === settings.welcomeMessage || busy ? 0.45 : 1 }]}><Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Zapisz</Text></Pressable></View>
        </View>
      </ScrollView>
      {quotaTarget ? <View style={styles.modalBackdrop}><View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.modalTitle, { color: colors.foreground }]}>Miesięczny limit AI</Text><Text style={[styles.userMeta, { color: colors.mutedForeground }]}>{quotaTarget.email} · użyto {quotaTarget.aiTokensUsedThisMonth.toLocaleString("pl-PL")}</Text><TextInput value={quota} onChangeText={setQuota} keyboardType="number-pad" placeholder="Puste pole = bez limitu" placeholderTextColor={colors.mutedForeground} style={[styles.input, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background, marginTop: 14 }]} /><Text style={[styles.userMeta, { color: colors.mutedForeground, marginTop: 8 }]}>Serwer sprawdza limit przed każdym wywołaniem AI.</Text><View style={styles.settingsFooter}><Pressable onPress={() => setQuotaTarget(null)} style={styles.action}><Text style={[styles.actionLabel, { color: colors.mutedForeground }]}>Anuluj</Text></Pressable><Pressable disabled={busy || (quota !== "" && (!/^\d+$/.test(quota) || Number(quota) > 1_000_000_000))} onPress={saveQuota} style={[styles.primaryButton, { backgroundColor: colors.primary }]}><Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Zapisz limit</Text></Pressable></View></View></View> : null}
    </View>
  );
}
const styles = StyleSheet.create({
  screen: { flex: 1 }, header: { height: 56, paddingHorizontal: 17, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, headerTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  content: { padding: 17, paddingBottom: 40, width: "100%", maxWidth: 900, alignSelf: "center" }, heading: { fontFamily: "Inter_700Bold", fontSize: 23 }, sub: { fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 18, marginTop: 6, marginBottom: 18 },
  denied: { justifyContent: "center", alignItems: "center", padding: 25 }, sectionLabel: { fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 1.1, marginBottom: 9 },
  addBox: { borderWidth: 1, borderRadius: 13, padding: 10, gap: 9 }, input: { minHeight: 43, borderWidth: 1, borderRadius: 10, paddingHorizontal: 11, fontFamily: "Inter_400Regular", fontSize: 12 }, search: { marginTop: 10, marginBottom: 10 },
  primaryButton: { minHeight: 41, borderRadius: 10, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 }, primaryText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  userCard: { borderWidth: 1, borderRadius: 13, paddingHorizontal: 12, paddingTop: 12, marginBottom: 8 }, userTop: { flexDirection: "row", alignItems: "center", gap: 8 }, userEmail: { fontFamily: "Inter_500Medium", fontSize: 12 }, userMeta: { fontFamily: "Inter_400Regular", fontSize: 10, lineHeight: 15, marginTop: 4 }, role: { fontFamily: "Inter_600SemiBold", fontSize: 9, letterSpacing: 0.4 },
  actionRow: { minHeight: 42, marginTop: 10, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: "row", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: 7 }, action: { flexDirection: "row", alignItems: "center", gap: 5, paddingVertical: 8 }, actionLabel: { fontFamily: "Inter_500Medium", fontSize: 10 }, locked: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 10, marginBottom: 10 },
  empty: { borderWidth: 1, borderRadius: 12, padding: 15 }, settingsCard: { borderWidth: 1, borderRadius: 13, padding: 13 }, label: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  multiline: { minHeight: 90, borderWidth: 1, borderRadius: 10, marginTop: 11, padding: 10, textAlignVertical: "top", fontFamily: "Inter_400Regular", fontSize: 12 }, settingsFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 10 },
  errorBox: { borderWidth: 1, borderRadius: 10, padding: 10, flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }, errorText: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 11 }, modalBackdrop: { ...StyleSheet.absoluteFill, backgroundColor: "#0009", justifyContent: "center", padding: 20 }, modalCard: { borderWidth: 1, borderRadius: 16, padding: 16 }, modalTitle: { fontFamily: "Inter_700Bold", fontSize: 17, marginBottom: 7 },
});
