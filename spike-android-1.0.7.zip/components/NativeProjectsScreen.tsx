import { Feather } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import { File, UploadType } from "expo-file-system";
import {
  createProject,
  completeAttachmentUpload,
  deleteProject,
  listProjects,
  renameProject,
  requestAttachmentUpload,
  importZipAttachment,
  type Project,
  type ProjectInputTemplate,
} from "../lib/api";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";
import { useColors } from "../hooks/useColors";

type Props = {
  displayName: string;
  email: string;
  onOpen: (project: Project) => void;
  onSignOut: () => void;
  onSettings: () => void;
  onAdmin: () => void;
  isAdmin: boolean;
};

const TEMPLATES: { id: ProjectInputTemplate; label: string; detail: string }[] = [
  { id: "blank", label: "Pusty", detail: "README.md" },
  { id: "web", label: "Web", detail: "HTML, CSS i JavaScript" },
  { id: "typescript", label: "TypeScript", detail: "Projekt TypeScript" },
];

export default function NativeProjectsScreen({ displayName, email, onOpen, onSignOut, onSettings, onAdmin, isAdmin }: Props) {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<"updated" | "created" | "name">("updated");
  const [modal, setModal] = useState<"create" | "rename" | null>(null);
  const [editing, setEditing] = useState<Project | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [template, setTemplate] = useState<ProjectInputTemplate>("blank");
  const [saving, setSaving] = useState(false);
  const [importing, setImporting] = useState(false);

  const load = useCallback(async (quiet = false) => {
    if (quiet) setRefreshing(true);
    else setLoading(true);
    setError("");
    try {
      setProjects(await listProjects());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się pobrać projektów.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const visibleProjects = useMemo(() => {
    const needle = search.trim().toLocaleLowerCase();
    return projects
      .filter((project) => !needle || `${project.name} ${project.description}`.toLocaleLowerCase().includes(needle))
      .sort((a, b) => sort === "name" ? a.name.localeCompare(b.name, "pl") : sort === "created" ? b.createdAt.localeCompare(a.createdAt) : b.updatedAt.localeCompare(a.updatedAt));
  }, [projects, search, sort]);

  const openCreate = () => {
    setEditing(null);
    setName("");
    setDescription("");
    setTemplate("blank");
    setModal("create");
  };

  const openRename = (project: Project) => {
    setEditing(project);
    setName(project.name);
    setModal("rename");
  };

  const submit = async () => {
    const cleanName = name.trim();
    if (!cleanName) return;
    setSaving(true);
    setError("");
    try {
      if (modal === "create") {
        const project = await createProject({ name: cleanName, description: description.trim(), template });
        setProjects((current) => [project, ...current]);
        setModal(null);
        onOpen(project);
      } else if (modal === "rename" && editing) {
        const updated = await renameProject(editing.id, { name: cleanName });
        setProjects((current) => current.map((project) => project.id === updated.id ? updated : project));
        setModal(null);
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się zapisać projektu.");
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = (project: Project) => Alert.alert(
    "Usunąć projekt?",
    `Projekt „${project.name}” i jego pliki zostaną trwale usunięte.`,
    [
      { text: "Anuluj", style: "cancel" },
      {
        text: "Usuń",
        style: "destructive",
        onPress: () => {
          void deleteProject(project.id)
            .then(() => setProjects((current) => current.filter((item) => item.id !== project.id)))
            .catch((cause) => setError(cause instanceof Error ? cause.message : "Nie udało się usunąć projektu."));
        },
      },
    ],
  );
  const importZip = async () => {
    let picked: DocumentPicker.DocumentPickerResult;
    try { picked = await DocumentPicker.getDocumentAsync({ type: ["application/zip", "application/x-zip-compressed"], copyToCacheDirectory: true }); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Nie udało się otworzyć wyboru pliku."); return; }
    if (picked.canceled || !picked.assets?.[0]) return;
    const asset = picked.assets[0];
    const size = asset.size || new File(asset.uri).info().size;
    if (!asset.name.toLowerCase().endsWith(".zip")) { setError("Wybierz archiwum ZIP."); return; }
    if (!size || size > 100 * 1024 * 1024) { setError("Archiwum musi mieć rozmiar od 1 B do 100 MB."); return; }
    setImporting(true); setError("");
    let created: Project | null = null;
    try {
      created = await createProject({ name: asset.name.replace(/\.zip$/i, "").trim().slice(0, 80) || "Projekt z ZIP", description: "Utworzono z archiwum ZIP", template: "blank" });
      const upload = await requestAttachmentUpload(created.id, { name: asset.name, sizeBytes: size, contentType: "application/zip" });
      const transfer = await new File(asset.uri).upload(upload.uploadUrl, { httpMethod: "PUT", uploadType: UploadType.BINARY_CONTENT, mimeType: "application/zip", headers: { "Content-Type": "application/zip" } });
      if (transfer.status < 200 || transfer.status >= 300) throw new Error(`Magazyn odrzucił ZIP (HTTP ${transfer.status}).`);
      await completeAttachmentUpload(created.id, upload.id);
      const result = await importZipAttachment(created.id, upload.id);
      setProjects(await listProjects());
      Alert.alert("Projekt zaimportowany", `${result.importedFiles} plików dodano; pominięto ${result.skippedFiles}.`);
      onOpen(created);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Nie udało się zaimportować projektu.";
      setError(message);
      if (created) {
        setProjects(await listProjects().catch(() => projects));
        Alert.alert("Import nie został ukończony", `${message} Projekt został utworzony; możesz dokończyć pracę w jego przestrzeni.`);
        onOpen(created);
      }
    } finally { setImporting(false); }
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <View style={styles.brandRow}>
          <Image source={require("../assets/images/icon.png")} style={styles.brandIcon} resizeMode="contain" accessibilityLabel="Spike" />
          <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
          <View style={[styles.onlineDot, { backgroundColor: colors.primary }]} />
        </View>
        <View style={styles.headerActions}>
          {isAdmin ? <Pressable onPress={onAdmin} accessibilityRole="button" accessibilityLabel="Administracja" style={styles.profileButton}><Feather name="shield" size={17} color={colors.mutedForeground} /></Pressable> : null}
          <Pressable onPress={onSettings} accessibilityRole="button" accessibilityLabel="Ustawienia profilu" style={styles.profileButton}><Feather name="user" size={17} color={colors.mutedForeground} /></Pressable>
          <Pressable onPress={onSignOut} accessibilityRole="button" accessibilityLabel={`Wyloguj ${email}`} style={styles.profileButton} testID="native-signout"><Feather name="log-out" size={17} color={colors.mutedForeground} /></Pressable>
        </View>
      </View>
      <ScrollView
        contentContainerStyle={[styles.content, width >= 900 && styles.contentWide]}
        keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(true)} tintColor={colors.primary} />}
      >
        <Text style={[styles.eyebrow, { color: colors.primary }]}>PRZESTRZEŃ ROBOCZA</Text>
        <Text style={[styles.heading, { color: colors.foreground }]}>Cześć, {displayName}</Text>
        <Text style={[styles.subheading, { color: colors.mutedForeground }]}>Twoje projekty, zapisane na serwerze Spike.</Text>

        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            accessibilityLabel="Szukaj projektów"
            value={search}
            onChangeText={setSearch}
            placeholder="Szukaj projektów"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.searchInput, { color: colors.foreground }]}
            testID="native-project-search"
          />
          {search ? <Pressable onPress={() => setSearch("")} accessibilityRole="button" accessibilityLabel="Wyczyść wyszukiwanie" testID="native-clear-project-search"><Feather name="x" size={16} color={colors.mutedForeground} /></Pressable> : null}
        </View>

        <View style={styles.projectActions}>
          <Pressable
            accessibilityRole="button"
            onPress={openCreate}
            style={({ pressed }) => [styles.createButton, { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 }]}
            testID="native-create-project"
          >
            <Feather name="plus" size={18} color={colors.primaryForeground} />
            <Text style={[styles.createLabel, { color: colors.primaryForeground }]}>Nowy projekt</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            onPress={() => setSort((current) => current === "updated" ? "created" : current === "created" ? "name" : "updated")}
            style={[styles.utilityButton, { borderColor: colors.border, backgroundColor: colors.card }]}
            accessibilityLabel="Zmień sortowanie projektów"
            testID="native-project-sort"
          >
            <Feather name="filter" size={15} color={colors.primary} />
            <Text style={[styles.utilityLabel, { color: colors.foreground }]}>{sort === "updated" ? "Ostatnio zmienione" : sort === "created" ? "Najnowsze" : "Nazwa A–Z"}</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            onPress={() => void importZip()}
            disabled={importing}
            style={[styles.utilityButton, { borderColor: colors.border, backgroundColor: colors.card, opacity: importing ? 0.55 : 1 }]}
            accessibilityLabel="Importuj projekt z ZIP"
            testID="native-import-project-zip"
          >
            {importing ? <ActivityIndicator size="small" color={colors.primary} /> : <Feather name="archive" size={15} color={colors.mutedForeground} />}
            <Text style={[styles.utilityLabel, { color: colors.mutedForeground }]}>{importing ? "Import…" : "Z ZIP"}</Text>
          </Pressable>
        </View>

        <View style={styles.sectionHeading}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Projekty</Text>
          <Text style={[styles.count, { color: colors.mutedForeground }]}>{visibleProjects.length}</Text>
        </View>

        {loading ? (
            <View style={[styles.loadingCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {[0, 1, 2].map((item) => <View key={item} style={styles.loadingRow}><View style={[styles.loadingIcon, { backgroundColor: colors.muted }]} /><View style={styles.loadingLines}><View style={[styles.loadingLine, { backgroundColor: colors.muted }]} /><View style={[styles.loadingLine, styles.loadingLineShort, { backgroundColor: colors.muted }]} /></View></View>)}
            </View>
        ) : error ? (
          <View style={[styles.stateBox, styles.errorState, { borderColor: colors.destructive }]}>
              <Feather name="alert-circle" size={20} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
              <Pressable onPress={() => void load()} accessibilityRole="button" testID="native-retry-projects" style={[styles.retryButton, { borderColor: colors.border }]}><Feather name="refresh-cw" size={13} color={colors.primary} /><Text style={[styles.retryText, { color: colors.foreground }]}>Spróbuj ponownie</Text></Pressable>
          </View>
        ) : visibleProjects.length === 0 ? (
          <View style={[styles.stateBox, styles.emptyBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name={search ? "search" : "folder"} size={23} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{search ? "Brak wyników" : "Nie masz jeszcze projektów"}</Text>
            <Text style={[styles.stateText, { color: colors.mutedForeground }]}>{search ? "Zmień wyszukiwaną frazę." : "Utwórz projekt, aby zacząć."}</Text>
            {!search ? <Pressable onPress={openCreate} accessibilityRole="button" style={[styles.emptyAction, { backgroundColor: colors.primary }]} testID="native-create-first-project"><Feather name="plus" size={15} color={colors.primaryForeground} /><Text style={[styles.emptyActionText, { color: colors.primaryForeground }]}>Utwórz projekt</Text></Pressable> : null}
          </View>
        ) : (
          <View style={styles.projectList}>
            {visibleProjects.map((project) => (
              <View key={project.id} style={[styles.projectCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Pressable onPress={() => onOpen(project)} accessibilityRole="button" accessibilityLabel={`Otwórz projekt ${project.name}`} style={({ pressed }) => [styles.projectMain, { opacity: pressed ? 0.72 : 1 }]} testID={`native-project-${project.id}`}>
                  <View style={[styles.projectIcon, { backgroundColor: colors.muted }]}>
                    <Feather name={project.template === "web" ? "globe" : "code"} size={17} color={colors.primary} />
                  </View>
                  <View style={styles.projectInfo}>
                    <Text numberOfLines={1} style={[styles.projectName, { color: colors.foreground }]}>{project.name}</Text>
                    <Text numberOfLines={1} style={[styles.projectDescription, { color: colors.mutedForeground }]}>{project.description || project.template}</Text>
                    <Text style={[styles.projectDate, { color: colors.mutedForeground }]}>{formatDate(project.updatedAt)}</Text>
                  </View>
                  <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
                </Pressable>
                <View style={[styles.cardActions, { borderTopColor: colors.border }]}>
                  <Pressable onPress={() => openRename(project)} style={styles.actionButton} accessibilityRole="button" accessibilityLabel={`Zmień nazwę ${project.name}`} testID={`native-rename-project-${project.id}`}>
                    <Feather name="edit-2" size={14} color={colors.mutedForeground} /><Text style={[styles.actionLabel, { color: colors.mutedForeground }]}>Zmień nazwę</Text>
                  </Pressable>
                  <Pressable onPress={() => confirmDelete(project)} style={styles.actionButton} accessibilityRole="button" accessibilityLabel={`Usuń ${project.name}`} testID={`native-delete-project-${project.id}`}>
                    <Feather name="trash-2" size={14} color={colors.destructive} /><Text style={[styles.actionLabel, { color: colors.destructive }]}>Usuń</Text>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      <Modal transparent animationType="fade" visible={modal !== null} onRequestClose={() => setModal(null)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>{modal === "create" ? "Nowy projekt" : "Zmień nazwę"}</Text>
            <TextInput
              autoFocus
              accessibilityLabel={modal === "create" ? "Nazwa projektu" : "Nowa nazwa projektu"}
              value={name}
              onChangeText={setName}
              maxLength={80}
              placeholder="Nazwa projektu"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.modalInput, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]}
              testID="native-project-name"
            />
            {modal === "create" ? (
              <>
                <TextInput
                  value={description}
                  onChangeText={setDescription}
                  accessibilityLabel="Opis projektu"
                  maxLength={500}
                  placeholder="Opis (opcjonalnie)"
                  placeholderTextColor={colors.mutedForeground}
                  style={[styles.modalInput, styles.descriptionInput, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]}
                />
                <Text style={[styles.templateLabel, { color: colors.mutedForeground }]}>SZABLON</Text>
                <View style={styles.templateRow}>
                  {TEMPLATES.map((item) => (
                    <Pressable
                      key={item.id}
                      onPress={() => setTemplate(item.id)}
                      accessibilityRole="button"
                      accessibilityLabel={`Szablon ${item.label}`}
                      testID={`native-project-template-${item.id}`}
                      style={[styles.templateChip, { borderColor: template === item.id ? colors.primary : colors.border, backgroundColor: template === item.id ? colors.primary + "18" : colors.background }]}
                    >
                      <Text style={[styles.templateName, { color: template === item.id ? colors.primary : colors.foreground }]}>{item.label}</Text>
                      <Text numberOfLines={1} style={[styles.templateDetail, { color: colors.mutedForeground }]}>{item.detail}</Text>
                    </Pressable>
                  ))}
                </View>
              </>
            ) : null}
            {error ? <Text style={[styles.modalError, { color: colors.destructive }]}>{error}</Text> : null}
            <View style={styles.modalActions}>
              <Pressable onPress={() => setModal(null)} accessibilityRole="button" style={[styles.cancelButton, { borderColor: colors.border }]} testID="native-project-cancel"><Text style={[styles.cancelLabel, { color: colors.foreground }]}>Anuluj</Text></Pressable>
              <Pressable disabled={saving || !name.trim()} onPress={() => void submit()} accessibilityRole="button" style={[styles.confirmButton, { backgroundColor: colors.primary, opacity: saving || !name.trim() ? 0.5 : 1 }]} testID="native-project-submit">
                {saving ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Text style={[styles.confirmLabel, { color: colors.primaryForeground }]}>{modal === "create" ? "Utwórz" : "Zapisz"}</Text>}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function formatDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Data niedostępna" : `Zmieniono ${date.toLocaleDateString("pl-PL")}`;
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { minHeight: 58, borderBottomWidth: StyleSheet.hairlineWidth, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 2 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  brandIcon: { width: 30, height: 30, borderRadius: 8 },
  brand: { fontFamily: "Inter_700Bold", fontSize: 18 },
  onlineDot: { width: 7, height: 7, borderRadius: 4 },
  profileButton: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  content: { padding: 18, paddingBottom: 36 },
  contentWide: { width: "100%", maxWidth: 960, alignSelf: "center", paddingHorizontal: 30 },
  eyebrow: { fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 1.2, marginTop: 8 },
  heading: { fontFamily: "Inter_700Bold", fontSize: 25, marginTop: 8 },
  subheading: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 19, marginTop: 5, marginBottom: 20 },
  searchBox: { height: 46, borderWidth: 1, borderRadius: 13, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 13 },
  searchInput: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 13, paddingVertical: 0 },
  createButton: { minHeight: 48, borderRadius: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, marginTop: 12 },
  projectActions: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 7 },
  utilityButton: { minHeight: 42, borderWidth: 1, borderRadius: 11, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 10, marginTop: 12 },
  utilityLabel: { fontFamily: "Inter_500Medium", fontSize: 10 },
  createLabel: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  sectionHeading: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 26, marginBottom: 12 },
  sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16 },
  count: { fontFamily: "Inter_500Medium", fontSize: 12 },
  projectList: { gap: 10 },
  projectCard: { borderWidth: 1, borderRadius: 16, overflow: "hidden" },
  projectMain: { minHeight: 76, flexDirection: "row", alignItems: "center", paddingHorizontal: 13, paddingVertical: 12, gap: 12 },
  projectIcon: { width: 39, height: 39, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  projectInfo: { flex: 1, gap: 3 },
  projectName: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  projectDescription: { fontFamily: "Inter_400Regular", fontSize: 11 },
  projectDate: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 1 },
  cardActions: { minHeight: 38, flexDirection: "row", borderTopWidth: StyleSheet.hairlineWidth, paddingHorizontal: 12, gap: 18 },
  actionButton: { flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 8 },
  actionLabel: { fontFamily: "Inter_500Medium", fontSize: 11 },
  stateBox: { minHeight: 120, alignItems: "center", justifyContent: "center", gap: 10, padding: 18 },
  loadingCard: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 4 },
  loadingRow: { minHeight: 70, flexDirection: "row", alignItems: "center", gap: 13, borderBottomWidth: StyleSheet.hairlineWidth },
  loadingIcon: { width: 38, height: 38, borderRadius: 11 },
  loadingLines: { flex: 1, gap: 8 },
  loadingLine: { height: 10, width: "54%", borderRadius: 5 },
  loadingLineShort: { width: "34%", height: 7 },
  stateText: { fontFamily: "Inter_400Regular", fontSize: 12, textAlign: "center" },
  errorState: { borderWidth: 1, borderRadius: 14, gap: 9 },
  errorText: { fontFamily: "Inter_400Regular", fontSize: 12, textAlign: "center" },
  retryText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  retryButton: { minHeight: 38, borderWidth: 1, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 12 },
  emptyBox: { borderWidth: 1, borderRadius: 16 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  emptyAction: { minHeight: 40, borderRadius: 11, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 4 },
  emptyActionText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  modalBackdrop: { flex: 1, backgroundColor: "#0009", justifyContent: "center", padding: 20 },
  modalCard: { borderWidth: 1, borderRadius: 20, padding: 19 },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 18, marginBottom: 15 },
  modalInput: { borderWidth: 1, borderRadius: 11, minHeight: 46, paddingHorizontal: 12, fontFamily: "Inter_400Regular", fontSize: 13, marginBottom: 10 },
  descriptionInput: { minHeight: 42 },
  templateLabel: { fontFamily: "Inter_600SemiBold", fontSize: 9, letterSpacing: 1, marginTop: 2, marginBottom: 7 },
  templateRow: { flexDirection: "row", gap: 7 },
  templateChip: { flex: 1, borderWidth: 1, borderRadius: 10, padding: 9 },
  templateName: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  templateDetail: { fontFamily: "Inter_400Regular", fontSize: 8, marginTop: 3 },
  modalError: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 10 },
  modalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 9, marginTop: 16 },
  cancelButton: { minWidth: 86, minHeight: 42, borderWidth: 1, borderRadius: 11, justifyContent: "center", alignItems: "center" },
  cancelLabel: { fontFamily: "Inter_500Medium", fontSize: 12 },
  confirmButton: { minWidth: 100, minHeight: 42, borderRadius: 11, justifyContent: "center", alignItems: "center" },
  confirmLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
});
