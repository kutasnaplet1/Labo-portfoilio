import { Feather } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useEffect, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { useClerk } from "@clerk/expo";
import { useColors } from "../hooks/useColors";
import type { Identity } from "../lib/api";

type Props = { identity: Identity; onBack: () => void; onPrivacy: () => void };
type Preferences = { fontSize: number; tabSize: number; wordWrap: boolean; autosave: boolean; autosaveDelay: number };
const DEFAULTS: Preferences = { fontSize: 13, tabSize: 2, wordWrap: false, autosave: false, autosaveDelay: 1500 };
const KEY = "spike.native.editor-preferences.v1";

export default function NativeSettingsScreen({ identity, onBack, onPrivacy }: Props) {
  const colors = useColors();
  const { signOut } = useClerk();
  const [prefs, setPrefs] = useState<Preferences>(DEFAULTS);
  useEffect(() => { void AsyncStorage.getItem(KEY).then((raw) => { if (raw) { try { setPrefs({ ...DEFAULTS, ...JSON.parse(raw) }); } catch { /* keep defaults */ } } }); }, []);
  const update = (patch: Partial<Preferences>) => {
    setPrefs((current) => {
      const next = { ...current, ...patch };
      void AsyncStorage.setItem(KEY, JSON.stringify(next));
      return next;
    });
  };
  const role = identity.role === "owner" ? "Właściciel" : identity.role === "admin" ? "Administrator" : "Członek";
  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={onBack} accessibilityRole="button" accessibilityLabel="Wróć"><Feather name="arrow-left" size={20} color={colors.foreground} /></Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Ustawienia</Text>
        <View style={{ width: 24 }} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>KONTO</Text>
        <View style={[styles.profile, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.avatar, { backgroundColor: colors.accent }]}><Text style={[styles.avatarText, { color: colors.primary }]}>{(identity.displayName || identity.email).slice(0, 1).toUpperCase()}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.name, { color: colors.foreground }]}>{identity.displayName || identity.email}</Text>
            <Text style={[styles.email, { color: colors.mutedForeground }]}>{identity.email}</Text>
          </View>
        </View>
        <View style={[styles.row, { borderColor: colors.border }]}><Text style={[styles.label, { color: colors.mutedForeground }]}>Rola</Text><Text style={[styles.value, { color: colors.foreground }]}>{role}</Text></View>
        <Text style={[styles.note, { color: colors.mutedForeground }]}>Rolę nadaje administrator instancji. Nie można jej zmienić samodzielnie.</Text>
        <Pressable onPress={() => Alert.alert("Wylogować się?", "Zakończ tę sesję Spike.", [{ text: "Anuluj", style: "cancel" }, { text: "Wyloguj", style: "destructive", onPress: () => void signOut() }])} style={[styles.signOut, { borderColor: colors.border }]} accessibilityRole="button" testID="native-settings-signout">
          <Feather name="log-out" size={16} color={colors.destructive} /><Text style={[styles.signOutText, { color: colors.destructive }]}>Wyloguj się</Text>
        </Pressable>

        <Text style={[styles.eyebrow, { color: colors.primary, marginTop: 28 }]}>EDYTOR</Text>
        <View style={[styles.group, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <PreferenceRow label="Rozmiar czcionki" value={`${prefs.fontSize} px`} onPress={() => update({ fontSize: prefs.fontSize >= 18 ? 11 : prefs.fontSize + 1 })} colors={colors} />
          <PreferenceRow label="Szerokość tabulacji" value={`${prefs.tabSize} spacje`} onPress={() => update({ tabSize: prefs.tabSize === 2 ? 4 : prefs.tabSize === 4 ? 8 : 2 })} colors={colors} />
          <SwitchRow label="Zawijanie wierszy" value={prefs.wordWrap} onChange={(wordWrap) => update({ wordWrap })} colors={colors} />
          <SwitchRow label="Autozapis" hint="Konflikty wersji nigdy nie są nadpisywane automatycznie." value={prefs.autosave} onChange={(autosave) => update({ autosave })} colors={colors} />
          <PreferenceRow label="Opóźnienie autozapisu" value={`${prefs.autosaveDelay / 1000} s`} disabled={!prefs.autosave} onPress={() => update({ autosaveDelay: prefs.autosaveDelay === 800 ? 1500 : prefs.autosaveDelay === 1500 ? 3000 : prefs.autosaveDelay === 3000 ? 5000 : 800 })} colors={colors} />
        </View>
        <Pressable onPress={() => update(DEFAULTS)} style={styles.resetButton} accessibilityRole="button" testID="native-reset-editor-settings"><Text style={[styles.resetText, { color: colors.mutedForeground }]}>Przywróć domyślne</Text></Pressable>
        <Text style={[styles.footnote, { color: colors.mutedForeground }]}>Preferencje edytora są przechowywane lokalnie na tym urządzeniu.</Text>
        <Pressable onPress={onPrivacy} style={[styles.privacy, { borderColor: colors.border }]} accessibilityRole="button" testID="native-open-privacy">
          <Feather name="shield" size={15} color={colors.mutedForeground} />
          <Text style={[styles.label, { color: colors.foreground, flex: 1 }]}>Informacja o prywatności</Text>
          <Feather name="chevron-right" size={15} color={colors.mutedForeground} />
        </Pressable>
      </ScrollView>
    </View>
  );
}

function PreferenceRow({ label, value, onPress, disabled, colors }: { label: string; value: string; onPress: () => void; disabled?: boolean; colors: ReturnType<typeof useColors> }) {
  return <Pressable disabled={disabled} onPress={onPress} style={[styles.prefRow, { borderBottomColor: colors.border, opacity: disabled ? 0.45 : 1 }]}><Text style={[styles.label, { color: colors.foreground }]}>{label}</Text><View style={styles.valueWrap}><Text style={[styles.value, { color: colors.primary }]}>{value}</Text><Feather name="chevron-right" size={15} color={colors.mutedForeground} /></View></Pressable>;
}
function SwitchRow({ label, hint, value, onChange, colors }: { label: string; hint?: string; value: boolean; onChange: (value: boolean) => void; colors: ReturnType<typeof useColors> }) {
  return <View style={[styles.prefRow, { borderBottomColor: colors.border }]}><View style={{ flex: 1, paddingRight: 12 }}><Text style={[styles.label, { color: colors.foreground }]}>{label}</Text>{hint ? <Text style={[styles.hint, { color: colors.mutedForeground }]}>{hint}</Text> : null}</View><Switch value={value} onValueChange={onChange} trackColor={{ false: colors.muted, true: colors.primary }} thumbColor={colors.foreground} /></View>;
}
const styles = StyleSheet.create({
  screen: { flex: 1 }, header: { height: 56, borderBottomWidth: StyleSheet.hairlineWidth, paddingHorizontal: 17, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  headerTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15 }, content: { padding: 18, paddingBottom: 40, width: "100%", maxWidth: 760, alignSelf: "center" },
  eyebrow: { fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 1.25, marginBottom: 10 }, profile: { borderWidth: 1, borderRadius: 14, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  avatar: { width: 42, height: 42, borderRadius: 13, alignItems: "center", justifyContent: "center" }, avatarText: { fontFamily: "Inter_700Bold", fontSize: 17 },
  name: { fontFamily: "Inter_600SemiBold", fontSize: 13 }, email: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 3 },
  row: { minHeight: 48, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 3 },
  label: { fontFamily: "Inter_500Medium", fontSize: 12 }, value: { fontFamily: "Inter_500Medium", fontSize: 12 }, note: { fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 17, marginTop: 8 },
  signOut: { marginTop: 15, minHeight: 44, borderWidth: 1, borderRadius: 11, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }, signOutText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  group: { borderWidth: 1, borderRadius: 13, overflow: "hidden" }, prefRow: { minHeight: 51, borderBottomWidth: StyleSheet.hairlineWidth, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  valueWrap: { flexDirection: "row", alignItems: "center", gap: 5 }, hint: { fontFamily: "Inter_400Regular", fontSize: 10, lineHeight: 15, marginTop: 3 }, footnote: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 9 },
  resetButton: { minHeight: 38, alignItems: "flex-end", justifyContent: "center", paddingHorizontal: 3 }, resetText: { fontFamily: "Inter_500Medium", fontSize: 10 },
  privacy: { minHeight: 47, borderWidth: 1, borderRadius: 11, marginTop: 14, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 9 },
});
