import { Feather } from "@expo/vector-icons";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "../hooks/useColors";

const sections = [
  {
    title: "Jakie dane przetwarza Spike",
    body: "Dane konta i zweryfikowana tożsamość przekazywane przez Clerk, status dostępu i akceptacji regulaminu, metadane projektów, zapisane pliki, historia rozmów z agentem, załączniki oraz techniczne informacje o użyciu funkcji. Miesięczny limit AI jest liczony na podstawie tokenów wejściowych i wyjściowych zwróconych przez model.",
  },
  {
    title: "Po co i gdzie",
    body: "Dane są używane do logowania, egzekwowania uprawnień, obsługi projektów, plików i historii, ochrony aplikacji oraz rozliczania limitu AI. Projekty i historia są przechowywane w bazie Spike, a wysłane załączniki w prywatnym magazynie plików. Kod projektu nie jest uruchamiany na serwerze Spike.",
  },
  {
    title: "Asystent AI i przesyłane pliki",
    body: "Treść wiadomości oraz wybrane pliki tekstowe lub zawartość ZIP są przekazywane przez Replit AI Integrations do Claude, aby wygenerować odpowiedź. Nie wysyłaj haseł, kluczy ani informacji, których nie chcesz przekazywać dostawcy modelu. Pozostałe typy plików mogą być przechowywane w projekcie, ale nie są odczytywane przez model.",
  },
  {
    title: "Okres przechowywania i usuwanie",
    body: "Projekty, rozmowy i ich pliki pozostają zapisane do czasu usunięcia projektu lub danych przez administratora. Załączniki można usunąć z poziomu panelu AI; usunięcie projektu usuwa jego dane. Cofnięcie dostępu blokuje dalsze korzystanie, ale samo nie usuwa danych.",
  },
  {
    title: "Twoje prawa i kontakt",
    body: "W sprawie dostępu, poprawienia lub usunięcia danych skontaktuj się z administratorem Spike. Ta informacja opisuje bieżącą wersję beta; formalne dane administratora danych, podstawa prawna i procedura wniosków wymagają uzupełnienia przed publicznym udostępnieniem aplikacji.",
  },
];

export default function NativePrivacyScreen({ onBack }: { onBack: () => void }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={onBack} accessibilityRole="button" accessibilityLabel="Wróć" style={styles.back}>
          <Feather name="arrow-left" size={19} color={colors.foreground} />
        </Pressable>
        <View style={styles.headerCopy}>
          <Text style={[styles.brand, { color: colors.primary }]}>SPIKE · WERSJA BETA</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Informacja o prywatności</Text>
        </View>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={[styles.notice, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="shield" size={16} color={colors.primary} />
          <Text style={[styles.noticeText, { color: colors.mutedForeground }]}>Robocza informacja dla prywatnej wersji beta, nie porada prawna. Przed publicznym uruchomieniem należy uzupełnić dane administratora i podstawę prawną przetwarzania.</Text>
        </View>
        {sections.map((section) => (
          <View key={section.title} style={[styles.section, { borderBottomColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{section.title}</Text>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>{section.body}</Text>
          </View>
        ))}
        <Text style={[styles.updated, { color: colors.mutedForeground }]}>Ostatnia aktualizacja: 9 listopada 2026 r.</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { minHeight: 61, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", paddingHorizontal: 10, gap: 8 },
  back: { width: 40, height: 44, alignItems: "center", justifyContent: "center" },
  headerCopy: { flex: 1, paddingVertical: 9 },
  brand: { fontFamily: "Inter_600SemiBold", fontSize: 9, letterSpacing: 1 },
  title: { fontFamily: "Inter_600SemiBold", fontSize: 14, marginTop: 3 },
  content: { padding: 16, paddingBottom: 30, width: "100%", maxWidth: 760, alignSelf: "center" },
  notice: { borderWidth: 1, borderRadius: 12, padding: 12, flexDirection: "row", alignItems: "flex-start", gap: 9, marginBottom: 8 },
  noticeText: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 17 },
  section: { paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 13, marginBottom: 6 },
  body: { fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 18 },
  updated: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 15 },
});
