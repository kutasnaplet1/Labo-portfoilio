import React, { useMemo } from "react";
import { Text } from "react-native";

type Token = { value: string; color: string; italic?: boolean; weight?: "600" };

const keywords = new Set([
  "as", "async", "await", "break", "case", "catch", "class", "const", "continue", "default", "delete",
  "do", "else", "export", "extends", "false", "finally", "for", "from", "function", "if", "implements",
  "import", "in", "instanceof", "interface", "let", "new", "null", "of", "private", "protected", "public",
  "return", "static", "super", "switch", "this", "throw", "true", "try", "type", "typeof", "undefined",
  "var", "void", "while", "yield", "def", "elif", "except", "lambda", "pass", "raise", "with", "and", "or",
]);

function languageFor(path: string) {
  const ext = path.split(".").pop()?.toLowerCase();
  if (ext === "json") return "json";
  if (["html", "htm", "xml", "svg"].includes(ext || "")) return "markup";
  if (["css", "scss"].includes(ext || "")) return "css";
  if (ext === "md" || ext === "mdx") return "markdown";
  return "code";
}

function tokenize(source: string, language: string, palette: Record<string, string>): Token[] {
  const tokens: Token[] = [];
  const pattern = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/|#[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|<\/?[A-Za-z][^>]*?>|\b\d+(?:\.\d+)?\b|\b[A-Za-z_$][\w$]*\b|[{}()[\].,;:<>!=+\-*/%&|?]+)/g;
  let cursor = 0;
  for (const match of source.matchAll(pattern)) {
    const value = match[0];
    const start = match.index ?? 0;
    if (start > cursor) tokens.push({ value: source.slice(cursor, start), color: palette.foreground });
    let color = palette.foreground;
    let italic = false;
    let weight: Token["weight"];
    if (/^(\/\/|\/\*|#)/.test(value) && language !== "markup") {
      color = palette.comment;
      italic = true;
    } else if (/^(["'`])/.test(value)) {
      color = palette.string;
    } else if (/^<\/?[A-Za-z]/.test(value)) {
      color = palette.tag;
    } else if (/^\d/.test(value)) {
      color = palette.number;
    } else if (keywords.has(value)) {
      color = palette.keyword;
    } else if (language === "markdown" && /^#{1,6}$/.test(value)) {
      color = palette.keyword;
      weight = "600";
    } else if (/^[{}()[\].,;:<>!=+\-*/%&|?]+$/.test(value)) {
      color = palette.punctuation;
    }
    tokens.push({ value, color, italic, weight });
    cursor = start + value.length;
  }
  if (cursor < source.length) tokens.push({ value: source.slice(cursor), color: palette.foreground });
  return tokens;
}

export function NativeCodeHighlight({
  value,
  path,
  fontSize,
  lineHeight,
  colors,
}: {
  value: string;
  path: string;
  fontSize: number;
  lineHeight: number;
  colors: { foreground: string; primary: string; mutedForeground: string; card: string };
}) {
  const language = languageFor(path);
  const palette = useMemo(() => ({
    foreground: colors.foreground,
    keyword: "#e58ab4",
    string: colors.primary,
    number: "#ef927e",
    comment: colors.mutedForeground,
    tag: "#f07d73",
    punctuation: "#92949f",
  }), [colors.foreground, colors.mutedForeground, colors.primary]);
  const tokens = useMemo(() => tokenize(value, language, palette), [value, language, palette]);
  return (
    <Text
      accessible={false}
      allowFontScaling={false}
      style={{ fontFamily: "monospace", fontSize, lineHeight, color: colors.foreground }}
    >
      {tokens.map((token, index) => (
        <Text key={index} style={{ color: token.color, fontStyle: token.italic ? "italic" : "normal", fontWeight: token.weight }}>
          {token.value}
        </Text>
      ))}
    </Text>
  );
}
