import { useAuth, useClerk, useUser } from "@clerk/expo";
import { Feather } from "@expo/vector-icons";
import { reloadAppAsync } from "expo";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import NativeProjectsScreen from "./NativeProjectsScreen";
import NativeSignInScreen from "./NativeSignInScreen";
import NativeWorkspaceScreen from "./NativeWorkspaceScreen";
import NativeAdminScreen from "./NativeAdminScreen";
import NativeSettingsScreen from "./NativeSettingsScreen";
import NativePrivacyScreen from "./NativePrivacyScreen";
import { apiRequest, getMe, setNativeAuthTokenGetter, type Identity, type Project, type TokenGetter } from "../lib/api";
import { useColors } from "../hooks/useColors";

type TermsDocument = {
  title: string;
  version: string;
  accepted: boolean;
  sections: { heading: string; body: string }[];
};

function LoadingScreen({ label }: { label: string }) {
  const colors = useColors();
  return <View style={[styles.center, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /><Text style={[styles.loadingText, { color: colors.mutedForeground }]}>{label}</Text></View>;
}

export default function NativeSpikeApp() {
  const { isLoaded, isSignedIn, getToken } = useAuth();
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [terms, setTerms] = useState<TermsDocument | null>(null);
  const [authError, setAuthError] = useState("");
  const [authTimedOut, setAuthTimedOut] = useState(false);
  const [loading, setLoading] = useState(false);
  const [project, setProject] = useState<Project | null>(null);
  const [screen, setScreen] = useState<"projects" | "settings" | "admin" | "privacy">("projects");
  const { signOut } = useClerk();
  const { user } = useUser();
  const colors = useColors();

  const getTokenRef = useRef(getToken);
  getTokenRef.current = getToken;
  const tokenGetter: TokenGetter = useCallback(() => getTokenRef.current(), []);
  const identityRequestRef = useRef(0);

  useEffect(() => {
    setNativeAuthTokenGetter(tokenGetter);
    return () => setNativeAuthTokenGetter(null);
  }, [tokenGetter]);

  useEffect(() => {
    if (isLoaded) {
      setAuthTimedOut(false);
      return;
    }
    const timeout = setTimeout(() => setAuthTimedOut(true), 25000);
    return () => clearTimeout(timeout);
  }, [isLoaded]);

  const loadIdentity = useCallback(async () => {
    const requestId = ++identityRequestRef.current;
    if (!isSignedIn) {
      setIdentity(null);
      setTerms(null);
      setAuthError("");
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    setLoading(true);
    setAuthError("");
    try {
      const [current, currentTerms] = await Promise.all([
        getMe({ signal: controller.signal }),
        apiRequest<TermsDocument>("/api/terms", { signal: controller.signal }),
      ]);
      if (identityRequestRef.current !== requestId) return;
      setIdentity(current);
      setTerms(currentTerms);
    } catch (cause) {
      if (identityRequestRef.current !== requestId) return;
      const status = cause && typeof cause === "object" && "status" in cause ? Number(cause.status) : 0;
      setIdentity(null);
      setTerms(null);
      const aborted = cause && typeof cause === "object" && "name" in cause && cause.name === "AbortError";
      setAuthError(aborted
        ? "Serwer Spike nie odpowiedział przez 15 sekund. Sprawdź połączenie i spróbuj ponownie."
        : status === 403
          ? "To konto nie ma dostępu do Spike. Administrator musi dopuścić dokładnie ten zweryfikowany adres e-mail."
          : cause instanceof Error ? cause.message : "Nie udało się zweryfikować konta.");
    } finally {
      clearTimeout(timeout);
      if (identityRequestRef.current === requestId) setLoading(false);
    }
  }, [isSignedIn]);

  useEffect(() => {
    if (isLoaded) void loadIdentity();
  }, [isLoaded, isSignedIn, loadIdentity]);

  if (!isLoaded) {
    if (!authTimedOut) return <LoadingScreen label="Przygotowywanie logowania…" />;
    return (
      <View style={[styles.center, styles.errorScreen, { backgroundColor: colors.background }]}>
        <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
        <Text style={[styles.errorText, { color: colors.mutedForeground }]}>
          Logowanie nie odpowiedziało. Sprawdź połączenie internetowe i uruchom Spike ponownie.
        </Text>
        <Pressable
          accessibilityRole="button"
          testID="retry-auth-startup"
          onPress={() => void reloadAppAsync()}
          style={[styles.action, { backgroundColor: colors.primary }]}
        >
          <Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>Uruchom ponownie Spike</Text>
        </Pressable>
      </View>
    );
  }
  if (!isSignedIn) return <NativeSignInScreen />;
  if (loading) return <LoadingScreen label="Sprawdzanie dostępu…" />;
  if (authError) {
    return (
      <View style={[styles.center, styles.errorScreen, { backgroundColor: colors.background }]}>
        <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
        <Text style={[styles.errorText, { color: colors.mutedForeground }]}>{authError}</Text>
        <Pressable onPress={() => void signOut()} style={[styles.action, { backgroundColor: colors.primary }]}><Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>Wyloguj</Text></Pressable>
        <Pressable onPress={() => void loadIdentity()}><Text style={[styles.retry, { color: colors.primary }]}>Sprawdź ponownie</Text></Pressable>
      </View>
    );
  }
  if (!identity || !terms) return <LoadingScreen label="Wczytywanie konta…" />;
  if (!terms.accepted) {
    return <TermsScreen terms={terms} onAccepted={() => void loadIdentity()} onSignOut={() => void signOut()} />;
  }
  if (screen === "privacy") return <NativePrivacyScreen onBack={() => setScreen("settings")} />;
  if (screen === "settings") return <NativeSettingsScreen identity={identity} onBack={() => setScreen("projects")} onPrivacy={() => setScreen("privacy")} />;
  if (screen === "admin") return <NativeAdminScreen identity={identity} onBack={() => setScreen("projects")} />;
  if (project) return <NativeWorkspaceScreen
    project={project}
    onBack={() => { setProject(null); setScreen("projects"); }}
    onOpenProject={setProject}
    onSettings={() => setScreen("settings")}
    isAdmin={identity.role === "owner" || identity.role === "admin"}
    onAdmin={() => setScreen("admin")}
  />;
  return (
    <NativeProjectsScreen
      displayName={identity.displayName || user?.firstName || identity.email}
      email={identity.email}
      onOpen={setProject}
      onSignOut={() => void signOut()}
      onSettings={() => setScreen("settings")}
      isAdmin={identity.role === "owner" || identity.role === "admin"}
      onAdmin={() => setScreen("admin")}
    />
  );
}

function TermsScreen({ terms, onAccepted, onSignOut }: { terms: TermsDocument; onAccepted: () => void; onSignOut: () => void }) {
  const colors = useColors();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const accept = async () => {
    setBusy(true);
    setError("");
    try {
      await apiRequest("/api/terms/accept", { method: "POST", body: JSON.stringify({ version: terms.version }) });
      onAccepted();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się zapisać akceptacji.");
    } finally {
      setBusy(false);
    }
  };
  if (showPrivacy) return <NativePrivacyScreen onBack={() => setShowPrivacy(false)} />;
  return (
    <View style={[styles.termsScreen, { backgroundColor: colors.background }]}>
      <View style={[styles.termsHeader, { borderBottomColor: colors.border }]}>
        <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
        <Pressable onPress={onSignOut}><Text style={[styles.retry, { color: colors.mutedForeground }]}>Wyloguj</Text></Pressable>
      </View>
      <ScrollView contentContainerStyle={styles.termsContent}>
        <Text style={[styles.termsTitle, { color: colors.foreground }]}>{terms.title}</Text>
        <Text style={[styles.termsIntro, { color: colors.mutedForeground }]}>Przeczytaj i zaakceptuj, aby kontynuować.</Text>
        {terms.sections.map((section) => (
          <View key={section.heading} style={styles.termsSection}>
            <Text style={[styles.termsHeading, { color: colors.foreground }]}>{section.heading}</Text>
            <Text style={[styles.termsBody, { color: colors.mutedForeground }]}>{section.body}</Text>
          </View>
        ))}
        {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
        <Pressable
          accessibilityRole="checkbox"
          accessibilityState={{ checked: confirmed }}
          onPress={() => setConfirmed((value) => !value)}
          style={styles.termsCheck}
          testID="native-terms-confirm"
        >
          <View style={[styles.checkbox, { borderColor: confirmed ? colors.primary : colors.border, backgroundColor: confirmed ? colors.primary : "transparent" }]}>
            {confirmed ? <Feather name="check" size={13} color={colors.primaryForeground} /> : null}
          </View>
          <Text style={[styles.termsBody, { color: colors.foreground }]}>Potwierdzam, że zapoznałem(-am) się z regulaminem i akceptuję jego warunki.</Text>
        </Pressable>
        <Pressable disabled={busy || !confirmed} onPress={() => void accept()} style={[styles.action, { backgroundColor: colors.primary, opacity: busy || !confirmed ? 0.45 : 1 }]}>
          {busy ? <ActivityIndicator color={colors.primaryForeground} /> : <Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>Akceptuję regulamin</Text>}
        </Pressable>
        <Pressable onPress={() => setShowPrivacy(true)} accessibilityRole="button" style={styles.privacyLink}>
          <Text style={[styles.retry, { color: colors.mutedForeground }]}>Informacja o prywatności</Text>
          <Feather name="arrow-up-right" size={13} color={colors.mutedForeground} />
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24 },
  loadingText: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 12 },
  errorScreen: { gap: 12 },
  brand: { fontFamily: "Inter_700Bold", fontSize: 22 },
  errorText: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 20, textAlign: "center" },
  action: { minHeight: 46, borderRadius: 13, alignItems: "center", justifyContent: "center", paddingHorizontal: 16, marginTop: 8 },
  actionLabel: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  retry: { fontFamily: "Inter_500Medium", fontSize: 12, marginTop: 4 },
  termsScreen: { flex: 1 },
  termsHeader: { minHeight: 56, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18 },
  termsContent: { padding: 20, paddingBottom: 40 },
  termsTitle: { fontFamily: "Inter_700Bold", fontSize: 21 },
  termsIntro: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 6, marginBottom: 18 },
  termsSection: { marginBottom: 16 },
  termsHeading: { fontFamily: "Inter_600SemiBold", fontSize: 13, marginBottom: 5 },
  termsBody: { fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 18 },
  termsCheck: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginTop: 8 },
  checkbox: { width: 20, height: 20, borderWidth: 1.5, borderRadius: 5, alignItems: "center", justifyContent: "center", marginTop: 1 },
  privacyLink: { alignSelf: "center", flexDirection: "row", alignItems: "center", gap: 4, marginTop: 14 },
});
