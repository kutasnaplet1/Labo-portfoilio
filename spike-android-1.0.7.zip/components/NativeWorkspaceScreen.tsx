import { Feather } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import { File, Paths, UploadType } from "expo-file-system";
import { strToU8, zipSync } from "fflate";
import * as Sharing from "expo-sharing";
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator, Alert, Image, Modal, Platform, Pressable, RefreshControl,
  ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "../hooks/useColors";
import { NativeCodeHighlight } from "./NativeCodeHighlight";
import {
  Attachment, Capabilities, ChatMessage, Project, ProjectFile, SpikeActivity, claimAgentJob, completeAttachmentUpload,
  createFile, deleteAttachment, deleteFile, deleteProject, getCapabilities, listActivity, listAttachments,
  finishAgentJob, importZipAttachment, listChat, listFiles, listProjects, requestAttachmentUpload, renameProject, sendChat, updateFile,
  getNativeBearerToken, SERVER_ORIGIN,
} from "../lib/api";

type Props = { project: Project; onBack: () => void; onOpenProject: (project: Project) => void; onSettings: () => void; onAdmin?: () => void; isAdmin?: boolean };
type BufferState = { content: string; baseContent: string; version: number; status: "idle" | "saving" | "conflict" | "error"; error?: string };
type Pane = "files" | "editor" | "agent" | "activity" | "preview" | "terminal" | "problems" | "logs" | "results";
type Log = { at: string; level: "info" | "warn" | "error"; message: string };
type StoredDraft = { content: string; version: number };
type NativeEditorPreferences = { fontSize: number; autosave: boolean; autosaveDelay: number; tabSize: number; wordWrap: boolean };
const DEFAULT_EDITOR_PREFERENCES: NativeEditorPreferences = { fontSize: 13, autosave: false, autosaveDelay: 1500, tabSize: 2, wordWrap: false };

export default function NativeWorkspaceScreen({ project, onBack, onOpenProject, onSettings, onAdmin, isAdmin }: Props) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const wide = width >= 900;
  const desktop = width >= 1200;
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [buffers, setBuffers] = useState<Record<string, BufferState>>({});
  const [tabs, setTabs] = useState<string[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [pane, setPane] = useState<Pane>("files");
  const [desktopRightPane, setDesktopRightPane] = useState<"agent" | "preview">("agent");
  const [desktopBottomPane, setDesktopBottomPane] = useState<"terminal" | "problems" | "logs" | "results">("terminal");
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [dialog, setDialog] = useState<"file" | "folder" | "rename-file" | "rename-project" | "switch" | null>(null);
  const [pathText, setPathText] = useState("");
  const [projectName, setProjectName] = useState(project.name);
  const [busy, setBusy] = useState(false);
  const [conflictFile, setConflictFile] = useState<string | null>(null);
  const [activity, setActivity] = useState<SpikeActivity[]>([]);
  const [chat, setChat] = useState<ChatMessage[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [caps, setCaps] = useState<Capabilities | null>(null);
  const [chatText, setChatText] = useState("");
  const [sending, setSending] = useState(false);
  const [selectedAttachments, setSelectedAttachments] = useState<string[]>([]);
  const [logs, setLogs] = useState<Log[]>([]);
  const [hostingVisible, setHostingVisible] = useState(false);
  const [chatError, setChatError] = useState("");
  const [editorPreferences, setEditorPreferences] = useState<NativeEditorPreferences>(DEFAULT_EDITOR_PREFERENCES);
  const [toolsVisible, setToolsVisible] = useState(false);
  const [zipBusy, setZipBusy] = useState(false);
  const buffersRef = useRef(buffers);
  buffersRef.current = buffers;
  const autoOpenedProjectRef = useRef("");
  const fileMap = useMemo(() => new Map(files.map((f) => [f.id, f])), [files]);
  const active = activeId ? buffers[activeId] : undefined;
  const activeMeta = activeId ? fileMap.get(activeId) : undefined;
  const dirtyIds = useMemo(() => Object.entries(buffers).filter(([, b]) => b.content !== b.baseContent).map(([id]) => id), [buffers]);
  const dirty = (id: string) => {
    const b = buffers[id];
    return !!b && b.content !== b.baseContent;
  };
  const log = useCallback((level: Log["level"], message: string) => setLogs((current) => [{ at: new Date().toISOString(), level, message }, ...current].slice(0, 120)), []);

  const refreshFiles = useCallback(async (keepDrafts = true) => {
    try {
      const latest = await listFiles(project.id);
      setFiles(latest);
      if (keepDrafts) {
        setBuffers((old) => {
          const next = { ...old };
          for (const f of latest) {
            if (f.kind !== "file") continue;
            const b = next[f.id];
            if (!b) continue;
            if (b.content === b.baseContent) next[f.id] = { content: f.content, baseContent: f.content, version: f.version, status: "idle" };
            else if (f.version !== b.version) next[f.id] = { ...b, status: "conflict", error: `Serwer ma nowszą wersję v${f.version}.` };
          }
          return next;
        });
      }
      return latest;
    } catch (cause) { throw cause; }
  }, [project.id]);

  const loadWorkspace = useCallback(async (quiet = false) => {
    if (quiet) setRefreshing(true); else setLoading(true);
    setError("");
    try {
      const [f, p, c, a, m, at, rawDrafts] = await Promise.all([
        listFiles(project.id), listProjects(), getCapabilities(), listActivity(project.id), listChat(project.id), listAttachments(project.id),
        AsyncStorage.getItem(`spike.native.drafts:${project.id}`),
      ]);
      let storedDrafts: Record<string, StoredDraft> = {};
      if (rawDrafts) { try { storedDrafts = JSON.parse(rawDrafts) as Record<string, StoredDraft>; } catch { storedDrafts = {}; } }
      setFiles(f); setProjects(p); setCaps(c); setActivity(a); setChat(m); setAttachments(at);
      setBuffers((old) => {
        const next = { ...old };
        for (const file of f) {
          if (file.kind !== "file") continue;
          const stored = storedDrafts[file.id];
          const prior = next[file.id] ?? (stored && stored.content !== file.content ? { content: stored.content, baseContent: file.content, version: stored.version, status: stored.version === file.version ? "idle" as const : "conflict" as const, error: stored.version === file.version ? undefined : `Serwer ma nowszą wersję v${file.version}.` } : undefined);
          if (!prior) next[file.id] = { content: file.content, baseContent: file.content, version: file.version, status: "idle" };
          else if (prior.content === prior.baseContent) next[file.id] = { content: file.content, baseContent: file.content, version: file.version, status: "idle" };
          else if (prior.version !== file.version) next[file.id] = { ...prior, status: "conflict", error: `Serwer ma nowszą wersję v${file.version}.` };
          else next[file.id] = prior;
        }
        return next;
      });
      if (autoOpenedProjectRef.current !== project.id) {
        autoOpenedProjectRef.current = project.id;
        const first = f.find((file) => file.kind === "file" && /(^|\/)(index\.(html|ts|js)|README\.md)$/i.test(file.path)) ?? f.find((file) => file.kind === "file");
        if (first) { setTabs([first.id]); setActiveId(first.id); setPane("editor"); }
      }
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Nie udało się wczytać projektu."); }
    finally { setLoading(false); setRefreshing(false); }
  }, [project.id]);
  useEffect(() => { setBuffers({}); setTabs([]); setActiveId(null); setPane("files"); void loadWorkspace(); }, [project.id, loadWorkspace]);
  useEffect(() => { setProjectName(project.name); }, [project.name]);
  useEffect(() => {
    let mounted = true;
    void AsyncStorage.getItem("spike.native.editor-preferences.v1").then((raw) => {
      if (!mounted || !raw) return;
      try { setEditorPreferences({ ...DEFAULT_EDITOR_PREFERENCES, ...JSON.parse(raw) }); } catch { /* use defaults */ }
    });
    return () => { mounted = false; };
  }, []);
  useEffect(() => {
    if (loading) return;
    const drafts: Record<string, StoredDraft> = {};
    Object.entries(buffers).forEach(([id, buffer]) => {
      if (buffer.content !== buffer.baseContent) drafts[id] = { content: buffer.content, version: buffer.version };
    });
    void AsyncStorage.setItem(`spike.native.drafts:${project.id}`, JSON.stringify(drafts));
  }, [buffers, loading, project.id]);
  useEffect(() => {
    const pending = sending || chat.some((message) => message.role === "user" && message.status === "pending");
    if (!pending) return;
    const timer = setInterval(() => {
      void Promise.all([listChat(project.id).then(setChat), listActivity(project.id).then(setActivity), listFiles(project.id).then(setFiles)]);
    }, 2200);
    return () => clearInterval(timer);
  }, [sending, chat, project.id]);

  const openFile = (file: ProjectFile) => {
    if (file.kind === "folder") {
      setCollapsed((old) => { const next = new Set(old); next.has(file.path) ? next.delete(file.path) : next.add(file.path); return next; });
      return;
    }
    if (activeId && dirty(activeId) && activeId !== file.id) {
      Alert.alert("Niezapisane zmiany", "Wybierz, co zrobić przed otwarciem innego pliku.", [
        { text: "Anuluj", style: "cancel" },
        { text: "Odrzuć szkic", style: "destructive", onPress: () => { setBuffers((old) => ({ ...old, [activeId]: { content: fileMap.get(activeId)?.content ?? "", baseContent: fileMap.get(activeId)?.content ?? "", version: fileMap.get(activeId)?.version ?? 0, status: "idle" } })); activate(file); } },
      ]);
      return;
    }
    activate(file);
  };
  const activate = (file: ProjectFile) => {
    setBuffers((old) => old[file.id] ? old : { ...old, [file.id]: { content: file.content, baseContent: file.content, version: file.version, status: "idle" } });
    setTabs((old) => old.includes(file.id) ? old : [...old, file.id]);
    setActiveId(file.id); setPane("editor");
  };
  const closeTab = (id: string) => {
    if (dirty(id)) {
      Alert.alert("Zamknąć niezapisany plik?", "Lokalny szkic zostanie utracony.", [
        { text: "Anuluj", style: "cancel" }, { text: "Zamknij", style: "destructive", onPress: () => finishClose(id) },
      ]);
    } else finishClose(id);
  };
  const finishClose = (id: string) => {
    const next = tabs.filter((item) => item !== id);
    setTabs(next); setBuffers((old) => { const copy = { ...old }; delete copy[id]; return copy; });
    if (activeId === id) setActiveId(next[next.length - 1] ?? null);
  };
  const saveFile = async (id: string, versionOverride?: number) => {
    const b = buffers[id];
    const f = fileMap.get(id);
    if (!b || !f || b.status === "saving") return false;
    if (b.content === b.baseContent) return true;
    setBuffers((old) => ({ ...old, [id]: { ...old[id], status: "saving", error: undefined } }));
    try {
      const sentContent = b.content;
      const updated = await updateFile(project.id, id, { content: sentContent, version: versionOverride ?? b.version });
      setFiles((old) => old.map((item) => item.id === updated.id ? updated : item));
      setBuffers((old) => {
        const current = buffersRef.current[id] ?? old[id];
        return { ...old, [id]: { content: current.content, baseContent: updated.content, version: updated.version, status: "idle" } };
      });
      setActivity(await listActivity(project.id));
      log("info", `Zapisano ${updated.path} → v${updated.version}`);
      return true;
    } catch (cause) {
      const status = cause && typeof cause === "object" && "status" in cause ? Number(cause.status) : 0;
      const msg = cause instanceof Error ? cause.message : "Nie udało się zapisać pliku.";
      const nextStatus = status === 409 ? "conflict" : "error";
      setBuffers((old) => ({ ...old, [id]: { ...old[id], status: nextStatus, error: msg } }));
      setError(msg); log(status === 409 ? "warn" : "error", `${status === 409 ? "Konflikt" : "Błąd zapisu"}: ${f.path}`);
      if (status === 409) setConflictFile(id);
      return false;
    }
  };
  const saveAll = async () => {
    for (const id of dirtyIds) if (!(await saveFile(id))) return false;
    return true;
  };
  useEffect(() => {
    if (!editorPreferences.autosave || !activeId || !active || active.content === active.baseContent || active.status === "conflict" || active.status === "saving") return;
    const timer = setTimeout(() => void saveFile(activeId), editorPreferences.autosaveDelay);
    return () => clearTimeout(timer);
  }, [editorPreferences.autosave, editorPreferences.autosaveDelay, activeId, active?.content, active?.baseContent, active?.status]);
  const resolveConflict = async (mode: "reload" | "overwrite") => {
    if (!conflictFile) return;
    try {
      const latest = await listFiles(project.id);
      setFiles(latest);
      const f = latest.find((item) => item.id === conflictFile);
      const b = buffers[conflictFile];
      if (!f || !b) throw new Error("Plik nie istnieje już na serwerze.");
      if (mode === "reload") {
        setBuffers((old) => ({ ...old, [f.id]: { content: f.content, baseContent: f.content, version: f.version, status: "idle" } }));
        log("warn", `Wczytano serwerową wersję v${f.version}: ${f.path}`);
      } else {
        setBuffers((old) => ({ ...old, [f.id]: { ...b, version: f.version, status: "idle" } }));
        setTimeout(() => void saveFile(f.id, f.version), 0);
      }
      setConflictFile(null); setError("");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Nie udało się rozwiązać konfliktu."); }
  };

  const normalizePath = (raw: string) => raw.trim().replace(/^\/+|\/+$/g, "");
  const submitPath = async () => {
    const path = normalizePath(pathText);
    if (!path || path.split("/").some((p) => !p || p === "." || p === "..")) { setError("Podaj prawidłową ścieżkę bez segmentów „.” ani „..”."); return; }
    setBusy(true); setError("");
    try {
      if (dialog === "rename-file" && activeId) {
        const f = fileMap.get(activeId);
        const b = buffers[activeId];
        if (!f) throw new Error("Plik już nie istnieje.");
        const updated = await updateFile(project.id, activeId, { path, version: b?.version ?? f.version });
        setFiles((old) => old.map((item) => item.id === updated.id ? updated : item));
        setActivity(await listActivity(project.id));
        log("info", `Zmieniono ścieżkę na ${updated.path}`);
      } else if (dialog === "file" || dialog === "folder") {
        const kind = dialog;
        const parts = path.split("/");
        const folders = new Set(files.filter((f) => f.kind === "folder").map((f) => f.path));
        for (let index = 1; index < parts.length; index++) {
          const dir = parts.slice(0, index).join("/");
          if (!folders.has(dir)) { await createFile(project.id, { path: dir, kind: "folder" }); folders.add(dir); }
        }
        const created = await createFile(project.id, { path, kind });
        const updated = await refreshFiles();
        setActivity(await listActivity(project.id));
        log("info", `Utworzono ${kind === "file" ? "plik" : "folder"} ${created.path}`);
        if (created.kind === "file") { setBuffers((old) => ({ ...old, [created.id]: { content: created.content, baseContent: created.content, version: created.version, status: "idle" } })); setTabs((old) => [...old, created.id]); setActiveId(created.id); setPane("editor"); }
        else setFiles(updated);
      }
      setDialog(null); setPathText("");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Operacja na ścieżce nie powiodła się."); }
    finally { setBusy(false); }
  };
  const removeFile = (file: ProjectFile) => Alert.alert(file.kind === "folder" ? "Usunąć folder?" : "Usunąć plik?", `„${file.path}” i zawartość zostaną trwale usunięte.`, [
    { text: "Anuluj", style: "cancel" },
    { text: "Usuń", style: "destructive", onPress: () => void (async () => {
      try {
        await deleteFile(project.id, file.id);
        const affected = files.filter((f) => f.id === file.id || (file.kind === "folder" && f.path.startsWith(`${file.path}/`))).map((f) => f.id);
        setTabs((old) => old.filter((id) => !affected.includes(id)));
        setBuffers((old) => { const n = { ...old }; affected.forEach((id) => delete n[id]); return n; });
        if (activeId && affected.includes(activeId)) setActiveId(null);
        await refreshFiles(false); setActivity(await listActivity(project.id)); log("warn", `Usunięto ${file.path}`);
      } catch (cause) { setError(cause instanceof Error ? cause.message : "Nie udało się usunąć elementu."); }
    })() },
  ]);
  const doRenameProject = async () => {
    if (!projectName.trim()) return;
    setBusy(true);
    try { const changed = await renameProject(project.id, { name: projectName.trim() }); setProjects((old) => old.map((p) => p.id === changed.id ? changed : p)); onOpenProject(changed); setActivity(await listActivity(project.id)); setDialog(null); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Nie udało się zmienić nazwy."); }
    finally { setBusy(false); }
  };
  const doDeleteProject = () => Alert.alert("Usunąć projekt?", `„${project.name}” oraz jego pliki, historię i rozmowy zostaną trwale usunięte.`, [
    { text: "Anuluj", style: "cancel" }, { text: "Usuń trwale", style: "destructive", onPress: () => void deleteProject(project.id).then(onBack).catch((cause) => setError(cause instanceof Error ? cause.message : "Nie udało się usunąć projektu.")) },
  ]);

  const exportProjectZip = async () => {
    if (zipBusy) return;
    setZipBusy(true);
    setError("");
    try {
      if (!(await saveAll())) throw new Error("Zapisz lub rozwiąż konflikty przed eksportem ZIP.");
      const latest = await listFiles(project.id);
      const entries = Object.fromEntries(
        latest.filter((item) => item.kind === "file").map((item) => [item.path, strToU8(item.content)]),
      );
      if (!Object.keys(entries).length) throw new Error("Projekt nie zawiera plików do spakowania.");
      const archive = zipSync(entries, { level: 6 });
      const safeName = `${project.name.replace(/[\\/:*?"<>|]/g, "-") || "Spike-projekt"}.zip`;
      const output = new File(Paths.cache, safeName);
      await output.write(archive);
      if (!(await Sharing.isAvailableAsync())) throw new Error("Udostępnianie plików nie jest dostępne na tym urządzeniu.");
      await Sharing.shareAsync(output.uri, { mimeType: "application/zip", dialogTitle: `Zapisz ${safeName}` });
      log("info", `Przygotowano eksport ZIP: ${safeName}`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się przygotować archiwum ZIP.");
    } finally {
      setZipBusy(false);
    }
  };

  const uploadAttachments = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: "*/*", multiple: true, copyToCacheDirectory: true });
      if (result.canceled) return;
      setSending(true); setChatError("Wysyłanie załączników…");
      let availableSlots = Math.max(0, 5 - selectedAttachments.length);
      for (const asset of result.assets) {
        const uriFile = new File(asset.uri);
        const sizeBytes = asset.size || uriFile.info().size;
        if (!sizeBytes || sizeBytes > 100 * 1024 * 1024) { setChatError(`${asset.name}: limit pliku wynosi 100 MB.`); continue; }
        let uploadId: string | null = null;
        try {
          const contentType = asset.mimeType || "application/octet-stream";
          const upload = await requestAttachmentUpload(project.id, { name: asset.name, sizeBytes, contentType });
          uploadId = upload.id;
          const transfer = await uriFile.upload(upload.uploadUrl, { httpMethod: "PUT", uploadType: UploadType.BINARY_CONTENT, mimeType: contentType, headers: { "Content-Type": contentType } });
          if (transfer.status < 200 || transfer.status >= 300) throw new Error(`Magazyn odrzucił plik (HTTP ${transfer.status}).`);
          await completeAttachmentUpload(project.id, upload.id);
          if (canAttachToAI(asset.name, sizeBytes) && availableSlots > 0) { setSelectedAttachments((old) => old.includes(upload.id) ? old : [...old, upload.id]); availableSlots--; }
        } catch (cause) {
          if (uploadId) void deleteAttachment(project.id, uploadId).catch(() => undefined);
          throw cause;
        }
      }
      setAttachments(await listAttachments(project.id));
      setChatError("Przesyłanie zakończone. Do AI można dołączyć maksymalnie 5 plików tekstowych do 1 MB lub ZIP do 5 MB.");
    } catch (cause) { setChatError(cause instanceof Error ? cause.message : "Nie udało się wysłać załącznika."); }
    finally { setSending(false); }
  };
  const submitChat = async () => {
    const content = chatText.trim();
    if (!content || sending) return;
    setSending(true); setChatError(""); setChatText("");
    let requestFinished = false;
    const pollNativeJobs = async () => {
      while (!requestFinished) {
        try {
          const job = await claimAgentJob(project.id);
          if (job) {
            const explanation = "TEST NOT RUN: Expo Native ne ma izolowanego WebContainer runnera. Nie uruchomiono kodu projektu.";
            await finishAgentJob(project.id, job.id, { exitCode: 2, output: explanation, durationMs: 0 });
            log("warn", "Agent poprosił o testy; natywny runner niedostępny, kodu nie uruchomiono.");
          }
        } catch { /* authorization, timeout, and ended-job errors are reported by the chat request itself */ }
        await new Promise((resolve) => setTimeout(resolve, 900));
      }
    };
    void pollNativeJobs();
    try {
      const message = await sendChat(project.id, { content, ...(selectedAttachments.length ? { attachmentIds: selectedAttachments } : {}), ...(dirtyIds.length ? { protectedFileIds: dirtyIds } : {}) });
      setChat((old) => [...old, message]);
      await Promise.all([refreshFiles(), listChat(project.id).then(setChat), listActivity(project.id).then(setActivity), listAttachments(project.id).then(setAttachments), getCapabilities().then(setCaps)]);
      log("info", "Wiadomość agenta zakończona; projekt odświeżono z serwera.");
    } catch (cause) {
      setChatText(content); setChatError(cause instanceof Error ? cause.message : "Agent nie zakończył zadania. Sprawdź aktywność przed ponowieniem.");
      try { setChat(await listChat(project.id)); setFiles(await listFiles(project.id)); setActivity(await listActivity(project.id)); } catch { /* keep the original failure visible */ }
    } finally { setSending(false); }
    requestFinished = true;
  };
  const downloadAttachment = async (item: Attachment) => {
    try {
      const token = await getNativeBearerToken();
      if (!token || !SERVER_ORIGIN) throw new Error("Sesja logowania lub adres serwera nie jest dostępny.");
      const safeName = item.name.replace(/[\\/:*?"<>|]/g, "-");
      const uri = `${SERVER_ORIGIN}/api/projects/${encodeURIComponent(project.id)}/attachments/${encodeURIComponent(item.id)}/download`;
      const file = await File.downloadFileAsync(uri, new File(Paths.cache, safeName), { headers: { Authorization: `Bearer ${token}` }, idempotent: true });
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: item.contentType, dialogTitle: `Zapisz ${item.name}` });
      else await file.preview();
    } catch (cause) { setChatError(cause instanceof Error ? cause.message : "Nie udało się pobrać załącznika."); }
  };
  const removeAttachment = (item: Attachment) => Alert.alert("Usunąć załącznik?", item.name, [
    { text: "Anuluj", style: "cancel" },
    { text: "Usuń", style: "destructive", onPress: () => void deleteAttachment(project.id, item.id).then(async () => { setSelectedAttachments((old) => old.filter((id) => id !== item.id)); setAttachments(await listAttachments(project.id)); }).catch((cause) => setChatError(cause instanceof Error ? cause.message : "Nie udało się usunąć załącznika.")) },
  ]);
  const importZipFromAttachment = async (item: Attachment) => {
    setSending(true);
    try {
      const result = await importZipAttachment(project.id, item.id);
      await Promise.all([refreshFiles(), listActivity(project.id).then(setActivity)]);
      Alert.alert("Import ZIP zakończony", `Zaimportowano ${result.importedFiles} plików; pominięto ${result.skippedFiles}.`);
    } catch (cause) { setChatError(cause instanceof Error ? cause.message : "Nie udało się zaimportować ZIP."); }
    finally { setSending(false); }
  };

  const visibleFiles = useMemo(() => files.filter((file) => {
    const needle = query.trim().toLowerCase();
    if (needle) return file.path.toLowerCase().includes(needle);
    const parts = file.path.split("/");
    return !parts.slice(0, -1).some((_, index) => collapsed.has(parts.slice(0, index + 1).join("/")));
  }), [files, query, collapsed]);
  const problems = Object.entries(buffers).filter(([, b]) => b.status === "conflict" || b.status === "error");
  const goBack = () => {
    if (!dirtyIds.length) { onBack(); return; }
    Alert.alert("Niezapisane zmiany", `${dirtyIds.length} plików ma niezapisane szkice.`, [
      { text: "Zostań", style: "cancel" }, { text: "Odrzuć i wróć", style: "destructive", onPress: onBack }, { text: "Zapisz wszystko", onPress: () => void saveAll().then((saved) => { if (saved) onBack(); }) },
    ]);
  };
  const panelItems: { id: Pane; title: string; icon: React.ComponentProps<typeof Feather>["name"] }[] = [
    { id: "agent", title: "Agent", icon: "cpu" }, { id: "activity", title: "Aktywność", icon: "clock" },
    { id: "preview", title: "Preview", icon: "eye" }, { id: "terminal", title: "Terminal", icon: "terminal" },
    { id: "problems", title: `Problemy${problems.length ? ` · ${problems.length}` : ""}`, icon: "alert-triangle" },
    { id: "logs", title: "Logs", icon: "align-left" }, { id: "results", title: "Run results", icon: "play-circle" },
  ];
  const workspacePanelProps = {
    project, files, activity, chat, attachments, caps,
    problems: problems.map(([id, b]) => ({ id, status: b.status, error: b.error || "", path: fileMap.get(id)?.path || id })),
    chatText, setChatText, sending, chatError, selectedAttachments, setSelectedAttachments,
    onSend: submitChat, onPickImage: uploadAttachments, onDeleteAttachment: removeAttachment,
    onDownloadAttachment: downloadAttachment, onImportZip: importZipFromAttachment,
    onRefresh: () => void loadWorkspace(true),
    onOpenFile: (id: string) => { const f = fileMap.get(id); if (f) openFile(f); },
    logs,
    onResolveProblem: (id: string) => { setConflictFile(id); setDesktopBottomPane("problems"); setPane("problems"); },
    colors,
  };
  const editor = <Editor active={active} activeFile={activeMeta} fontSize={editorPreferences.fontSize} onChange={(content) => activeId && setBuffers((old) => ({ ...old, [activeId]: { ...old[activeId], content } }))} onSave={() => activeId && void saveFile(activeId)} colors={colors} />;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: Platform.OS === "web" ? 67 : insets.top }]}>
      <View style={[styles.header, { borderBottomColor: colors.border, backgroundColor: colors.card }]}>
        <Pressable onPress={goBack} accessibilityRole="button" accessibilityLabel="Wróć do projektów" style={styles.headerIcon}><Feather name="arrow-left" size={18} color={colors.foreground} /></Pressable>
        <Image source={require("../assets/images/icon.png")} style={styles.workspaceBrandIcon} resizeMode="contain" accessibilityLabel="Spike" />
        <Pressable onPress={() => { setDialog("switch"); void listProjects().then(setProjects).catch((cause) => setError(cause instanceof Error ? cause.message : "Nie udało się pobrać projektów.")); }} style={styles.projectSelect} accessibilityRole="button" accessibilityLabel="Przełącz projekt">
          <Text numberOfLines={1} style={[styles.projectTitle, { color: colors.foreground }]}>{project.name}</Text><Feather name="chevron-down" size={14} color={colors.mutedForeground} />
        </Pressable>
        <Pressable onPress={() => setDialog("rename-project")} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Zmień nazwę projektu"><Feather name="edit-2" size={15} color={colors.mutedForeground} /></Pressable>
        <Pressable onPress={() => void saveAll()} disabled={!dirtyIds.length || busy} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Zapisz wszystkie pliki"><Feather name="save" size={17} color={dirtyIds.length ? colors.primary : colors.mutedForeground} /></Pressable>
        <Pressable onPress={() => void exportProjectZip()} disabled={zipBusy} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Eksport projektu ZIP">{zipBusy ? <ActivityIndicator size="small" color={colors.primary} /> : <Feather name="archive" size={16} color={colors.mutedForeground} />}</Pressable>
        <Pressable onPress={onSettings} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Ustawienia"><Feather name="user" size={16} color={colors.mutedForeground} /></Pressable>
        {isAdmin && onAdmin ? <Pressable onPress={onAdmin} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Administracja"><Feather name="shield" size={16} color={colors.mutedForeground} /></Pressable> : null}
        <Pressable onPress={() => setHostingVisible(true)} style={[styles.betaPill, { borderColor: colors.border }]}><Text style={[styles.betaText, { color: colors.mutedForeground }]}>Hosting beta</Text></Pressable>
        <Pressable onPress={doDeleteProject} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Usuń projekt"><Feather name="trash-2" size={16} color={colors.destructive} /></Pressable>
      </View>
      <View style={[styles.toolbar, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => setPane("files")} style={[styles.navItem, pane === "files" || pane === "editor" ? { backgroundColor: colors.accent } : null]}><Feather name="folder" size={14} color={colors.primary} /><Text style={[styles.navText, { color: colors.foreground }]}>Pliki</Text></Pressable>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabs}>
          {tabs.map((id) => {
            const f = fileMap.get(id); if (!f) return null;
            return <View key={id} style={[styles.tab, { borderColor: colors.border, backgroundColor: activeId === id ? colors.card : "transparent" }]}>
              <Pressable onPress={() => { setActiveId(id); setPane("editor"); }} style={styles.tabMain}><Feather name={fileIcon(f.path)} size={12} color={colors.primary} /><Text numberOfLines={1} style={[styles.tabTitle, { color: colors.foreground }]}>{f.path.split("/").pop()}</Text>{dirty(id) ? <View style={[styles.dirtyDot, { backgroundColor: colors.primary }]} /> : null}</Pressable>
              <Pressable onPress={() => closeTab(id)} accessibilityRole="button" accessibilityLabel={`Zamknij ${f.path}`} style={styles.tabClose}><Feather name="x" size={13} color={colors.mutedForeground} /></Pressable>
            </View>;
          })}
        </ScrollView>
        <Pressable onPress={() => desktop ? setDesktopRightPane("agent") : setPane("agent")} style={[styles.navItem, pane === "agent" ? { backgroundColor: colors.accent } : null]}><Feather name="cpu" size={14} color={colors.primary} /><Text style={[styles.navText, { color: colors.foreground }]}>AI</Text></Pressable>
      </View>
      {error ? <View style={[styles.errorBanner, { borderBottomColor: colors.border }]}><Text numberOfLines={2} style={[styles.errorText, { color: colors.destructive }]}>{error}</Text><Pressable onPress={() => setError("")}><Feather name="x" size={15} color={colors.mutedForeground} /></Pressable></View> : null}

      {desktop ? <View style={[styles.wideBody, styles.desktopBody]}>
        <View style={[styles.filePane, { borderRightColor: colors.border, backgroundColor: colors.card }]}>
          <Explorer files={visibleFiles} allFiles={files} query={query} setQuery={setQuery} loading={loading} onRefresh={() => void loadWorkspace(true)} onCreate={(kind) => { setPathText(""); setDialog(kind); }} onOpen={openFile} onRename={(file) => { setActiveId(file.id); setPathText(file.path); setDialog("rename-file"); }} onDelete={removeFile} activeId={activeId} collapsed={collapsed} colors={colors} />
        </View>
        <View style={[styles.centerPane, styles.desktopCenter]}>
          <View style={styles.desktopEditor}>{editor}</View>
          <View style={[styles.desktopBottom, { borderTopColor: colors.border }]}>
            <View style={[styles.desktopTabs, { borderBottomColor: colors.border }]}>
              {(["terminal", "problems", "logs", "results"] as const).map((tab) => (
                <Pressable key={tab} onPress={() => setDesktopBottomPane(tab)} style={[styles.desktopTab, desktopBottomPane === tab && { borderBottomColor: colors.primary }]}>
                  <Text style={[styles.desktopTabText, { color: desktopBottomPane === tab ? colors.foreground : colors.mutedForeground }]}>{tab === "terminal" ? "Terminal" : tab === "problems" ? `Problemy${problems.length ? ` · ${problems.length}` : ""}` : tab === "logs" ? "Dziennik" : "Wyniki uruchomienia"}</Text>
                </Pressable>
              ))}
            </View>
            <WorkspacePanel pane={desktopBottomPane} {...workspacePanelProps} />
          </View>
        </View>
        <View style={[styles.desktopRight, { borderLeftColor: colors.border, backgroundColor: colors.card }]}>
          <View style={[styles.desktopTabs, { borderBottomColor: colors.border }]}>
            {(["agent", "preview"] as const).map((tab) => (
              <Pressable key={tab} onPress={() => setDesktopRightPane(tab)} style={[styles.desktopTab, desktopRightPane === tab && { borderBottomColor: colors.primary }]}>
                <Feather name={tab === "agent" ? "cpu" : "eye"} size={13} color={desktopRightPane === tab ? colors.primary : colors.mutedForeground} />
                <Text style={[styles.desktopTabText, { color: desktopRightPane === tab ? colors.foreground : colors.mutedForeground }]}>{tab === "agent" ? "AI" : "Podgląd"}</Text>
              </Pressable>
            ))}
          </View>
          <WorkspacePanel pane={desktopRightPane} {...workspacePanelProps} />
        </View>
      </View> : wide ? <><ScrollView horizontal showsHorizontalScrollIndicator={false} style={[styles.widePanelNav, { borderBottomColor: colors.border }]} contentContainerStyle={styles.widePanelNavContent}>{panelItems.map((item) => <Pressable key={item.id} onPress={() => setPane(item.id)} style={[styles.widePanelLink, pane === item.id ? { backgroundColor: colors.accent } : null]}><Feather name={item.icon} size={13} color={pane === item.id ? colors.primary : colors.mutedForeground} /><Text style={[styles.widePanelText, { color: pane === item.id ? colors.foreground : colors.mutedForeground }]}>{item.title}</Text></Pressable>)}</ScrollView><View style={styles.wideBody}>
        <View style={[styles.filePane, { borderRightColor: colors.border, backgroundColor: colors.card }]}>
          <Explorer files={visibleFiles} allFiles={files} query={query} setQuery={setQuery} loading={loading} onRefresh={() => void loadWorkspace(true)} onCreate={(kind) => { setPathText(""); setDialog(kind); }} onOpen={openFile} onRename={(file) => { setActiveId(file.id); setPathText(file.path); setDialog("rename-file"); }} onDelete={removeFile} activeId={activeId} collapsed={collapsed} colors={colors} />
        </View>
        <View style={styles.centerPane}>
          {pane === "editor" || pane === "files" ? editor : null}
          {!["editor", "files"].includes(pane) ? <WorkspacePanel pane={pane} {...workspacePanelProps} /> : null}
        </View>
      </View></> : pane === "files" ? <View style={styles.mobileBody}><Explorer files={visibleFiles} allFiles={files} query={query} setQuery={setQuery} loading={loading} onRefresh={() => void loadWorkspace(true)} onCreate={(kind) => { setPathText(""); setDialog(kind); }} onOpen={(file) => { openFile(file); if (file.kind === "file") setPane("editor"); }} onRename={(file) => { setActiveId(file.id); setPathText(file.path); setDialog("rename-file"); }} onDelete={removeFile} activeId={activeId} collapsed={collapsed} colors={colors} /></View>
       : pane === "editor" ? <View style={styles.mobileBody}>{editor}</View>
       : <View style={styles.mobileBody}><WorkspacePanel pane={pane} {...workspacePanelProps} onOpenFile={(id) => { const f = fileMap.get(id); if (f) { openFile(f); setPane("editor"); } }} /></View>}

      {!wide ? <View style={[styles.bottomNav, { borderTopColor: colors.border, backgroundColor: colors.card, paddingBottom: Math.max(insets.bottom, 8) }]}>
        {[{ id: "files" as Pane, title: "Files", icon: "folder" as const }, { id: "editor" as Pane, title: "Editor", icon: "code" as const }, { id: "agent" as Pane, title: "Agent", icon: "cpu" as const }, { id: "activity" as Pane, title: "History", icon: "clock" as const }, { id: "preview" as Pane, title: "Preview", icon: "eye" as const }].map((item) => <Pressable key={item.id} onPress={() => setPane(item.id)} style={styles.bottomItem} accessibilityRole="button" accessibilityLabel={`Pokaż ${item.title}`}><Feather name={item.icon} size={17} color={pane === item.id ? colors.primary : colors.mutedForeground} /><Text style={[styles.bottomText, { color: pane === item.id ? colors.primary : colors.mutedForeground }]}>{item.title}</Text></Pressable>)}
        <Pressable onPress={() => setToolsVisible(true)} style={styles.bottomItem} accessibilityRole="button" accessibilityLabel="Więcej narzędzi"><Feather name="more-horizontal" size={18} color={colors.mutedForeground} /><Text style={[styles.bottomText, { color: colors.mutedForeground }]}>More</Text></Pressable>
      </View> : null}
      <Modal transparent animationType="fade" visible={toolsVisible} onRequestClose={() => setToolsVisible(false)}><View style={styles.modalBackdrop}><View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.modalTitle, { color: colors.foreground }]}>Narzędzia projektu</Text>{panelItems.filter((item) => ["terminal", "problems", "logs", "results"].includes(item.id)).map((item) => <Pressable key={item.id} onPress={() => { setToolsVisible(false); setPane(item.id); }} style={[styles.toolOption, { borderBottomColor: colors.border }]}><Feather name={item.icon} size={16} color={colors.primary} /><Text style={[styles.projectOptionTitle, { color: colors.foreground }]}>{item.title}</Text><Feather name="chevron-right" size={14} color={colors.mutedForeground} /></Pressable>)}</View></View></Modal>
      {conflictFile ? <View style={styles.modalBackdrop}><View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.modalTitle, { color: colors.foreground }]}>Konflikt wersji</Text><Text style={[styles.modalHint, { color: colors.mutedForeground }]}>{buffers[conflictFile]?.error || "Plik zmienił się na serwerze."} Szkic jest nadal zachowany.</Text><View style={styles.modalActions}><Pressable onPress={() => void resolveConflict("reload")} style={[styles.secondaryButton, { borderColor: colors.border }]}><Text style={[styles.actionText, { color: colors.foreground }]}>Wczytaj serwer</Text></Pressable><Pressable onPress={() => void resolveConflict("overwrite")} style={[styles.primaryButton, { backgroundColor: colors.primary }]}><Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Nadpisz wersję</Text></Pressable></View><Pressable onPress={() => setConflictFile(null)} style={{ alignSelf: "flex-end", marginTop: 10 }}><Text style={[styles.actionText, { color: colors.mutedForeground }]}>Później</Text></Pressable></View></View> : null}
      <Modal transparent animationType="fade" visible={dialog !== null} onRequestClose={() => setDialog(null)}>
        <View style={styles.modalBackdrop}><View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {dialog === "switch" ? <>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Przełącz projekt</Text>
            <ScrollView style={{ maxHeight: 400 }}>{projects.map((p) => <Pressable key={p.id} onPress={() => { setDialog(null); if (p.id !== project.id) { if (dirtyIds.length) Alert.alert("Niezapisane szkice", "Szkice znikną z bieżącego ekranu. Wybierz zapis przed przełączeniem.", [{ text: "Anuluj", style: "cancel" }, { text: "Przełącz", onPress: () => onOpenProject(p) }]); else onOpenProject(p); } }} style={[styles.projectOption, { borderBottomColor: colors.border }]}><Text style={[styles.projectOptionTitle, { color: p.id === project.id ? colors.primary : colors.foreground }]}>{p.name}</Text><Text style={[styles.modalHint, { color: colors.mutedForeground }]}>{p.description || p.template}</Text></Pressable>)}</ScrollView>
            <Pressable onPress={() => { setDialog(null); onBack(); }} style={styles.modalLink}><Text style={[styles.actionText, { color: colors.primary }]}>Wszystkie progetti</Text></Pressable>
          </> : <>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>{dialog === "rename-project" ? "Zmień nazwę projektu" : dialog === "rename-file" ? "Zmień ścieżkę pliku" : dialog === "folder" ? "Nowy folder" : "Nowy plik"}</Text>
            {dialog === "rename-project" ? <TextInput value={projectName} onChangeText={setProjectName} maxLength={80} style={[styles.modalInput, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]} placeholder="Nazwa projektu" placeholderTextColor={colors.mutedForeground} /> : <><Text style={[styles.modalHint, { color: colors.mutedForeground }]}>Ścieżka względna projektu</Text><TextInput value={pathText} onChangeText={setPathText} autoCapitalize="none" autoCorrect={false} style={[styles.modalInput, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]} placeholder="src/app.ts" placeholderTextColor={colors.mutedForeground} /></>}
            {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
            <View style={styles.modalActions}><Pressable onPress={() => { setDialog(null); setError(""); }} style={[styles.secondaryButton, { borderColor: colors.border }]}><Text style={[styles.actionText, { color: colors.foreground }]}>Anuluj</Text></Pressable><Pressable disabled={busy} onPress={() => void (dialog === "rename-project" ? doRenameProject() : submitPath())} style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: busy ? 0.6 : 1 }]}>{busy ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Text style={[styles.primaryText, { color: colors.primaryForeground }]}>{dialog === "rename-project" || dialog === "rename-file" ? "Zapisz" : "Utwórz"}</Text>}</Pressable></View>
          </>}
        </View></View>
      </Modal>
      {hostingVisible ? <Modal transparent animationType="fade" visible onRequestClose={() => setHostingVisible(false)}><View style={styles.modalBackdrop}><View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.modalTitle, { color: colors.foreground }]}>Hosting beta · informacyjnie</Text><Text style={[styles.modalHint, { color: colors.mutedForeground, lineHeight: 19 }]}>Hosting nie jest aktywny. Ta karta nie tworzy procesu, publicznego adresu ani usługi w tle. W Expo Native nie działa przeglądarkowy WebContainer runner.</Text><Pressable onPress={() => setHostingVisible(false)} style={[styles.primaryButton, { backgroundColor: colors.primary, marginTop: 15 }]}><Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Rozumiem</Text></Pressable></View></View></Modal> : null}
    </View>
  );
}

function Explorer({ files, allFiles, query, setQuery, loading, onRefresh, onCreate, onOpen, onRename, onDelete, activeId, collapsed, colors }: {
  files: ProjectFile[]; allFiles: ProjectFile[]; query: string; setQuery: (v: string) => void; loading: boolean; onRefresh: () => void; onCreate: (kind: "file" | "folder") => void;
  onOpen: (file: ProjectFile) => void; onRename: (file: ProjectFile) => void; onDelete: (file: ProjectFile) => void; activeId: string | null; collapsed: Set<string>; colors: ReturnType<typeof useColors>;
}) {
  return <View style={{ flex: 1 }}>
    <View style={[styles.explorerTop, { borderBottomColor: colors.border }]}><Text style={[styles.explorerLabel, { color: colors.mutedForeground }]}>EXPLORER <Text style={{ color: colors.primary }}>{allFiles.length}</Text></Text><View style={styles.explorerActions}><Pressable onPress={() => onCreate("file")} accessibilityLabel="Nowy plik"><Feather name="file-plus" size={15} color={colors.mutedForeground} /></Pressable><Pressable onPress={() => onCreate("folder")} accessibilityLabel="Nowy folder"><Feather name="folder-plus" size={15} color={colors.mutedForeground} /></Pressable><Pressable onPress={onRefresh} accessibilityLabel="Odśwież pliki"><Feather name="refresh-cw" size={14} color={colors.mutedForeground} /></Pressable></View></View>
    <View style={[styles.searchBox, { backgroundColor: colors.background, borderColor: colors.border }]}><Feather name="search" size={13} color={colors.mutedForeground} /><TextInput value={query} onChangeText={setQuery} placeholder="Szukaj plików" placeholderTextColor={colors.mutedForeground} style={[styles.searchInput, { color: colors.foreground }]} accessibilityLabel="Szukaj plików" /></View>
    {loading && allFiles.length === 0 ? <View style={{ padding: 12, gap: 9 }}>{[0, 1, 2].map((i) => <View key={i} style={[styles.skeleton, { backgroundColor: colors.muted, width: i === 1 ? "68%" : "90%" }]} />)}</View> :
      <ScrollView refreshControl={<RefreshControl refreshing={loading} onRefresh={onRefresh} tintColor={colors.primary} />} contentContainerStyle={{ paddingVertical: 6 }}>
        {files.map((file) => {
          const depth = file.path.split("/").length - 1;
          return <View key={file.id} style={[styles.fileRow, { backgroundColor: activeId === file.id ? colors.accent : "transparent" }]}>
            <Pressable onPress={() => onOpen(file)} style={styles.filePress} accessibilityRole="button" accessibilityLabel={`${file.kind === "folder" ? "Folder" : "Otwórz"} ${file.path}`}>
              <View style={{ width: Math.min(depth * 13, 48) }} />
              <Feather name={file.kind === "folder" ? collapsed.has(file.path) ? "folder" : "folder" : fileIcon(file.path)} size={14} color={activeId === file.id ? colors.primary : colors.mutedForeground} />
              <Text numberOfLines={1} style={[styles.fileName, { color: activeId === file.id ? colors.foreground : colors.mutedForeground }]}>{file.path.split("/").pop()}</Text>
              {file.kind === "folder" ? <Feather name={collapsed.has(file.path) ? "chevron-right" : "chevron-down"} size={12} color={colors.mutedForeground} /> : null}
            </Pressable>
            <Pressable onPress={() => onRename(file)} style={styles.fileAction} accessibilityLabel={`Zmień nazwę ${file.path}`}><Feather name="edit-2" size={12} color={colors.mutedForeground} /></Pressable>
            <Pressable onPress={() => onDelete(file)} style={styles.fileAction} accessibilityLabel={`Usuń ${file.path}`}><Feather name="trash-2" size={12} color={colors.destructive} /></Pressable>
          </View>;
        })}
        {!files.length ? <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{query ? "Brak pasujących plików." : "W projekcie nie ma plików."}</Text> : null}
      </ScrollView>}
  </View>;
}

function Editor({ active, activeFile, fontSize, onChange, onSave, colors }: { active?: BufferState; activeFile?: ProjectFile; fontSize: number; onChange: (v: string) => void; onSave: () => void; colors: ReturnType<typeof useColors> }) {
  const [scrollOffset, setScrollOffset] = useState({ x: 0, y: 0 });
  if (!active || !activeFile) return <View style={styles.editorEmpty}><Feather name="code" size={25} color={colors.mutedForeground} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Otwórz plik</Text><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Wybierz plik z eksploratora.</Text></View>;
  const lineCount = Math.max(1, active.content.split("\n").length);
  return <View style={styles.editor}>
    <View style={[styles.editorHeader, { borderBottomColor: colors.border, backgroundColor: colors.card }]}><Feather name={fileIcon(activeFile.path)} size={14} color={colors.primary} /><Text numberOfLines={1} style={[styles.editorPath, { color: colors.foreground }]}>{activeFile.path}</Text><Text style={[styles.lang, { color: colors.mutedForeground }]}>{language(activeFile.path)}</Text><Pressable onPress={onSave} accessibilityRole="button" accessibilityLabel="Zapisz aktywny plik"><Feather name="save" size={16} color={active.content !== active.baseContent ? colors.primary : colors.mutedForeground} /></Pressable></View>
    <View style={styles.codeArea}>
      <ScrollView style={[styles.gutter, { backgroundColor: colors.background, transform: [{ translateY: -scrollOffset.y }] }]} scrollEnabled={false}><Text style={[styles.lineNumbers, { color: colors.mutedForeground }]}>{Array.from({ length: lineCount }, (_, i) => i + 1).join("\n")}</Text></ScrollView>
       <View pointerEvents="none" style={[styles.highlightLayer, { transform: [{ translateX: -scrollOffset.x }, { translateY: -scrollOffset.y }] }]}>
         <NativeCodeHighlight value={active.content} path={activeFile.path} fontSize={fontSize} lineHeight={fontSize + 7} colors={colors} />
       </View>
       <TextInput value={active.content} onChangeText={onChange} multiline autoCapitalize="none" autoCorrect={false} spellCheck={false} textAlignVertical="top" selectionColor={colors.primary} onScroll={(event) => setScrollOffset(event.nativeEvent.contentOffset)} style={[styles.codeInput, { color: "transparent", fontSize, lineHeight: fontSize + 7 }]} accessibilityLabel={`Edytor kodu ${activeFile.path}`} testID="native-code-editor" />
    </View>
    <View style={[styles.statusBar, { borderTopColor: colors.border, backgroundColor: colors.card }]}><Text style={[styles.statusText, { color: active.status === "conflict" || active.status === "error" ? colors.destructive : active.content !== active.baseContent ? colors.primary : colors.mutedForeground }]}>{active.status === "saving" ? "Zapisywanie…" : active.status === "conflict" ? "Konflikt wersji" : active.status === "error" ? "Błąd zapisu" : active.content !== active.baseContent ? "Niezapisane zmiany" : `Zapisano · v${active.version}`}</Text><Text style={[styles.statusText, { color: colors.mutedForeground }]}>{language(activeFile.path)} · {lineCount} linii</Text></View>
  </View>;
}

function WorkspacePanel({ pane, project, files, activity, chat, attachments, caps, problems, chatText, setChatText, sending, chatError, selectedAttachments, setSelectedAttachments, onSend, onPickImage, onDeleteAttachment, onDownloadAttachment, onImportZip, onRefresh, onOpenFile, logs, onResolveProblem, colors }: {
  pane: Pane; project: Project; files: ProjectFile[]; activity: SpikeActivity[]; chat: ChatMessage[]; attachments: Attachment[]; caps: Capabilities | null; problems: { id: string; path: string; status: string; error: string }[]; chatText: string; setChatText: (v: string) => void; sending: boolean; chatError: string;
  selectedAttachments: string[]; setSelectedAttachments: React.Dispatch<React.SetStateAction<string[]>>; onSend: () => void; onPickImage: () => void; onDeleteAttachment: (item: Attachment) => void; onDownloadAttachment: (item: Attachment) => void; onImportZip: (item: Attachment) => void; onRefresh: () => void; onOpenFile: (id: string) => void; logs: Log[]; onResolveProblem: (id: string) => void; colors: ReturnType<typeof useColors>;
}) {
  const insets = useSafeAreaInsets();
  const [attachmentOpen, setAttachmentOpen] = useState(false);
  const [subTab, setSubTab] = useState<"chat" | "activity">("chat");
  const unreadableReason = caps?.ai === false ? "AI jest niedostępne dla tej instancji." : caps?.aiMonthlyTokenLimit !== null && caps?.aiMonthlyTokenLimit !== undefined && caps.aiTokensUsedThisMonth >= caps.aiMonthlyTokenLimit ? "Osiągnięto miesięczny limit AI." : "";
  if (pane === "agent") return <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={0}>
    <View style={[styles.panelHeader, { borderBottomColor: colors.border }]}>{(["chat", "activity"] as const).map((tab) => <Pressable key={tab} onPress={() => setSubTab(tab)} style={[styles.panelTab, subTab === tab && { borderBottomColor: colors.primary }]}><Text style={[styles.panelTabText, { color: subTab === tab ? colors.foreground : colors.mutedForeground }]}>{tab === "chat" ? "Agent" : "Aktywność"}</Text></Pressable>)}<View style={{ flex: 1 }} /><Text style={[styles.aiState, { color: caps?.ai ? colors.primary : colors.mutedForeground }]}>{caps?.ai ? caps.aiModel || "AI dostępne" : "AI niedostępne"}</Text></View>
    {subTab === "activity" ? <ActivityView activity={activity} loading={false} colors={colors} onRefresh={onRefresh} /> : <>
      <View style={[styles.attachHeader, { borderBottomColor: colors.border }]}><Pressable onPress={() => setAttachmentOpen((v) => !v)} style={styles.attachToggle}><Feather name="paperclip" size={13} color={colors.mutedForeground} /><Text style={[styles.attachTitle, { color: colors.mutedForeground }]}>Pliki projektu · {attachments.length}{selectedAttachments.length ? ` · ${selectedAttachments.length} wybrane` : ""}</Text></Pressable><Pressable onPress={onPickImage} accessibilityRole="button" accessibilityLabel="Dodaj załącznik"><Feather name="upload" size={15} color={colors.primary} /></Pressable></View>
      {attachmentOpen ? <View style={[styles.attachmentList, { borderBottomColor: colors.border }]}><ScrollView style={{ maxHeight: 120 }}>{attachments.map((item) => {
        const aiReadable = canAttachToAI(item.name, item.sizeBytes);
        const chosen = selectedAttachments.includes(item.id);
         return <View key={item.id} style={styles.attachmentRow}><Pressable disabled={!aiReadable || (!chosen && selectedAttachments.length >= 5)} onPress={() => setSelectedAttachments((old) => old.includes(item.id) ? old.filter((id) => id !== item.id) : old.length < 5 ? [...old, item.id] : old)} style={styles.attachmentName} accessibilityRole="button" accessibilityLabel={aiReadable ? `Dołącz ${item.name} do AI` : `${item.name} nie może być wysłany do AI`}><Feather name={chosen ? "check-square" : "square"} size={14} color={chosen ? colors.primary : aiReadable ? colors.mutedForeground : colors.border} /><Text numberOfLines={1} style={[styles.attachText, { color: colors.foreground }]}>{item.name}</Text></Pressable><Text style={[styles.attachSize, { color: colors.mutedForeground }]}>{(item.sizeBytes / 1024).toFixed(0)} KB</Text>{item.name.toLowerCase().endsWith(".zip") ? <Pressable onPress={() => onImportZip(item)} accessibilityLabel={`Importuj ${item.name} do projektu`}><Feather name="archive" size={13} color={colors.primary} /></Pressable> : null}<Pressable onPress={() => onDownloadAttachment(item)} accessibilityLabel={`Pobierz ${item.name}`}><Feather name="download" size={13} color={colors.mutedForeground} /></Pressable><Pressable onPress={() => onDeleteAttachment(item)} accessibilityLabel={`Usuń ${item.name}`}><Feather name="trash-2" size={13} color={colors.destructive} /></Pressable></View>;
      })}
        {!attachments.length ? <Text style={[styles.panelHint, { color: colors.mutedForeground }]}>Brak załączników. Możesz dodać obraz z biblioteki urządzenia.</Text> : null}</ScrollView>
      <Text style={[styles.panelHint, { color: colors.mutedForeground }]}>Załączniki można przechowywać, pobrać lub usunąć. AI czyta tekst do 1 MB i ZIP do 5 MB; sekrety, pliki binarne i inne typy nie są dołączane do kontekstu.</Text></View> : null}
      {unreadableReason ? <Text style={[styles.warningText, { color: colors.destructive }]}>{unreadableReason}</Text> : null}
      <ScrollView style={styles.chatMessages} contentContainerStyle={styles.chatContent} keyboardShouldPersistTaps="handled" keyboardDismissMode="interactive">
        {!chat.length ? <View style={styles.chatEmpty}><Feather name="cpu" size={23} color={colors.primary} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Zleć zadanie agentowi</Text><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Wiadomości i rzeczywiste zmiany są pobierane z serwera.</Text></View> : chat.map((message) => <View key={message.id} style={[styles.messageCard, { backgroundColor: message.role === "user" ? colors.accent : colors.card, borderColor: colors.border }]}><View style={styles.messageMeta}><Text style={[styles.messageRole, { color: message.role === "assistant" ? colors.primary : colors.mutedForeground }]}>{message.role === "assistant" ? "SPIKE AI" : "TY"}</Text><Text style={[styles.messageRole, { color: message.status === "failed" ? colors.destructive : colors.mutedForeground }]}>{message.status === "failed" ? "NIEPOWODZENIE" : ""}</Text></View><Text selectable style={[styles.messageText, { color: colors.foreground }]}>{message.content}</Text>
          {message.changes?.length ? <View style={{ marginTop: 10, gap: 5 }}><Text style={[styles.messageRole, { color: colors.mutedForeground }]}>ZMIENIONE PLIKI · {message.changes.length}</Text>{message.changes.map((change) => <Pressable key={change.id} onPress={() => onOpenFile(change.fileId)} style={[styles.changeRow, { borderColor: colors.border }]}><Feather name="file-text" size={13} color={colors.primary} /><Text numberOfLines={1} style={[styles.changeText, { color: colors.foreground }]}>{change.path} · {change.action}</Text></Pressable>)}</View> : null}
        </View>)}
        {sending ? <View style={[styles.messageCard, { backgroundColor: colors.card, borderColor: colors.border }]}><ActivityIndicator color={colors.primary} /><Text style={[styles.panelHint, { color: colors.mutedForeground, marginTop: 8 }]}>Agent pracuje. Nie zgłaszamy zmian, dopóki API ich nie potwierdzi.</Text></View> : null}
      </ScrollView>
      {chatError ? <Text style={[styles.warningText, { color: colors.destructive }]}>{chatError}</Text> : null}
      <View style={[styles.composer, { borderTopColor: colors.border, paddingBottom: Math.max(insets.bottom, 8) }]}><TextInput value={chatText} onChangeText={setChatText} multiline placeholder={unreadableReason || "Opisz zadanie agentowi…"} placeholderTextColor={colors.mutedForeground} editable={!sending && !unreadableReason} style={[styles.chatInput, { borderColor: colors.border, backgroundColor: colors.card, color: colors.foreground }]} accessibilityLabel="Wiadomość do agenta" /><Pressable disabled={!chatText.trim() || sending || !!unreadableReason} onPress={onSend} style={[styles.sendButton, { backgroundColor: colors.primary, opacity: !chatText.trim() || sending || !!unreadableReason ? 0.45 : 1 }]} accessibilityRole="button" accessibilityLabel="Wyślij wiadomość"><Feather name="arrow-up" size={17} color={colors.primaryForeground} /></Pressable></View>
    </>}
  </KeyboardAvoidingView>;
  if (pane === "activity") return <ActivityView activity={activity} loading={false} colors={colors} onRefresh={onRefresh} />;
  if (pane === "preview") return <NativeUnavailable title="Preview" icon="eye" body={`Podgląd wymaga przeglądarkowego WebContainer runner. Expo Native nie uruchamia projektu ani nie osadza strony. ${caps?.executionReason || ""}`} colors={colors} />;
  if (pane === "terminal") return <NativeUnavailable title="Terminal" icon="terminal" body={`Terminal działa w przeglądarkowym WebContainer. Nie uruchomiono poleceń na urządzeniu. ${caps?.executionReason || ""}`} colors={colors} />;
  if (pane === "results") return <NativeUnavailable title="Run results" icon="play-circle" body="Nie ma natywnego runnera/test harness. Wyniki pozostają puste; testy agentowe zostaną uczciwie oznaczone jako niewykonane." colors={colors} />;
  if (pane === "problems") return <ScrollView style={styles.panel}><Text style={[styles.panelTitle, { color: colors.foreground }]}>Problemy · {problems.length}</Text><Text style={[styles.panelHint, { color: colors.mutedForeground }]}>Konflikty wersji i błędy zapisu edytora.</Text>{problems.length ? problems.map((problem) => <Pressable key={problem.id} onPress={() => { onOpenFile(problem.id); if (problem.status === "conflict") onResolveProblem(problem.id); }} style={[styles.problemRow, { borderColor: colors.border }]}><Feather name="alert-triangle" size={15} color={problem.status === "conflict" ? colors.primary : colors.destructive} /><View style={{ flex: 1 }}><Text style={[styles.changeText, { color: colors.foreground }]}>{problem.path}</Text><Text style={[styles.panelHint, { color: colors.mutedForeground }]}>{problem.error}</Text></View></Pressable>) : <Text style={[styles.emptyText, { color: colors.mutedForeground, marginTop: 15 }]}>Brak problemów. Tutaj pojawią się konflikty wersji i błędy zapisu.</Text>}</ScrollView>;
  if (pane === "logs") return <ScrollView style={styles.panel}>{logs.length ? logs.map((item, index) => <View key={`${item.at}-${index}`} style={styles.logRow}><Text style={[styles.logTime, { color: colors.mutedForeground }]}>{new Date(item.at).toLocaleTimeString("pl-PL")}</Text><Text style={[styles.logLevel, { color: item.level === "error" ? colors.destructive : item.level === "warn" ? colors.primary : colors.mutedForeground }]}>{item.level}</Text><Text style={[styles.logMessage, { color: colors.foreground }]}>{item.message}</Text></View>) : <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Dziennik pusty. Zdarzenia zapisu i operacji na plikach pojawią się tutaj.</Text>}</ScrollView>;
  return <View style={[styles.panel, { backgroundColor: colors.background }]}><Text style={[styles.panelTitle, { color: colors.foreground }]}>{project.name}</Text><Text style={[styles.panelHint, { color: colors.mutedForeground }]}>{files.length} elementów · edytuj i zapisz pliki ręcznie</Text></View>;
}

function ActivityView({ activity, loading, colors, onRefresh }: { activity: SpikeActivity[]; loading: boolean; colors: ReturnType<typeof useColors>; onRefresh: () => void }) {
  return <ScrollView refreshControl={<RefreshControl refreshing={loading} onRefresh={onRefresh} tintColor={colors.primary} />} contentContainerStyle={{ padding: 13 }}><Text style={[styles.panelTitle, { color: colors.foreground }]}>Aktywność projektu</Text>{activity.length ? activity.map((item) => <View key={item.id} style={[styles.activityRow, { borderBottomColor: colors.border }]}><View style={[styles.activityDot, { backgroundColor: colors.primary }]} /><View style={{ flex: 1 }}><Text style={[styles.activityAction, { color: colors.foreground }]}>{item.action}</Text>{item.path ? <Text style={[styles.panelHint, { color: colors.mutedForeground }]}>{item.path}</Text> : null}</View><Text style={[styles.activityTime, { color: colors.mutedForeground }]}>{new Date(item.createdAt).toLocaleString("pl-PL", { dateStyle: "short", timeStyle: "short" })}</Text></View>) : <Text style={[styles.emptyText, { color: colors.mutedForeground, marginTop: 12 }]}>Brak aktywności.</Text>}</ScrollView>;
}
function NativeUnavailable({ title, icon, body, colors }: { title: string; icon: React.ComponentProps<typeof Feather>["name"]; body: string; colors: ReturnType<typeof useColors> }) {
  return <View style={styles.unavailable}><View style={[styles.unavailableIcon, { backgroundColor: colors.card, borderColor: colors.border }]}><Feather name={icon} size={21} color={colors.primary} /></View><Text style={[styles.panelTitle, { color: colors.foreground }]}>{title}</Text><Text style={[styles.unavailableBody, { color: colors.mutedForeground }]}>{body}</Text></View>;
}
function fileIcon(path: string): React.ComponentProps<typeof Feather>["name"] { const ext = path.split(".").pop()?.toLowerCase(); if (ext === "json") return "settings"; if (ext === "md") return "book-open"; if (["png", "jpg", "svg"].includes(ext ?? "")) return "image"; if (["ts", "tsx", "js", "jsx"].includes(ext ?? "")) return "code"; return "file-text"; }
function language(path: string) { const ext = path.split(".").pop()?.toLowerCase(); return ({ ts: "TypeScript", tsx: "TypeScript JSX", js: "JavaScript", jsx: "JavaScript JSX", html: "HTML", css: "CSS", json: "JSON", md: "Markdown", py: "Python" } as Record<string, string>)[ext ?? ""] || (ext || "Plain text").toUpperCase(); }
function canAttachToAI(name: string, sizeBytes: number) {
  const lower = name.toLowerCase();
  if (lower.endsWith(".zip")) return sizeBytes <= 5 * 1024 * 1024;
  if (/^\.env(?:$|\.(?!example$|template$))/i.test(lower) || /\.(pem|key)$/i.test(lower) || sizeBytes > 1024 * 1024) return false;
  return new Set(["txt", "md", "mdx", "json", "jsonl", "csv", "xml", "html", "htm", "css", "js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "go", "rs", "java", "c", "h", "cpp", "hpp", "yml", "yaml", "toml", "ini", "sql", "sh", "log", "svg"]).has(lower.split(".").pop() || "");
}

const styles = StyleSheet.create({
  screen: { flex: 1 }, header: { minHeight: 51, paddingHorizontal: 5, flexDirection: "row", alignItems: "center", borderBottomWidth: StyleSheet.hairlineWidth, gap: 2 },
  workspaceBrandIcon: { width: 24, height: 24, borderRadius: 6 },
  headerIcon: { width: 37, height: 40, alignItems: "center", justifyContent: "center" }, projectSelect: { flexDirection: "row", alignItems: "center", gap: 4, maxWidth: "36%", flex: 1, height: 40, paddingHorizontal: 4 },
  projectTitle: { fontFamily: "Inter_600SemiBold", fontSize: 12, flexShrink: 1 }, betaPill: { borderWidth: 1, borderRadius: 7, paddingHorizontal: 6, paddingVertical: 4 }, betaText: { fontFamily: "Inter_500Medium", fontSize: 8 },
  toolbar: { minHeight: 43, flexDirection: "row", alignItems: "center", borderBottomWidth: StyleSheet.hairlineWidth, paddingHorizontal: 7, gap: 5 },
  navItem: { minHeight: 30, flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 8, borderRadius: 7 }, navText: { fontFamily: "Inter_500Medium", fontSize: 10 },
  tabs: { alignItems: "center", gap: 4, paddingHorizontal: 2 }, tab: { height: 31, minWidth: 80, maxWidth: 170, borderWidth: 1, borderRadius: 7, flexDirection: "row", alignItems: "center" }, tabMain: { minWidth: 0, flex: 1, flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 7 }, tabTitle: { flexShrink: 1, fontFamily: "Inter_400Regular", fontSize: 9 }, tabClose: { width: 25, height: 28, alignItems: "center", justifyContent: "center" }, dirtyDot: { width: 5, height: 5, borderRadius: 3 },
  errorBanner: { minHeight: 32, paddingHorizontal: 12, paddingVertical: 5, flexDirection: "row", alignItems: "center", gap: 10, borderBottomWidth: StyleSheet.hairlineWidth }, errorText: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 10 },
  wideBody: { flex: 1, flexDirection: "row" }, desktopBody: { minHeight: 0 }, mobileBody: { flex: 1 }, filePane: { width: 260, borderRightWidth: StyleSheet.hairlineWidth }, centerPane: { flex: 1, minWidth: 0 }, desktopCenter: { minHeight: 0 }, desktopEditor: { flex: 1, minHeight: 0 }, desktopBottom: { height: 245, minHeight: 190, borderTopWidth: StyleSheet.hairlineWidth }, desktopRight: { width: 330, minWidth: 300, borderLeftWidth: StyleSheet.hairlineWidth }, desktopTabs: { minHeight: 35, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "stretch", paddingHorizontal: 7, gap: 4 }, desktopTab: { minHeight: 34, borderBottomWidth: 2, borderBottomColor: "transparent", paddingHorizontal: 9, flexDirection: "row", alignItems: "center", gap: 6 }, desktopTabText: { fontFamily: "Inter_500Medium", fontSize: 10 }, explorerTop: { height: 40, borderBottomWidth: StyleSheet.hairlineWidth, paddingHorizontal: 11, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  widePanelNav: { maxHeight: 36, borderBottomWidth: StyleSheet.hairlineWidth }, widePanelNavContent: { alignItems: "center", paddingHorizontal: 8, gap: 4 }, widePanelLink: { height: 27, borderRadius: 6, paddingHorizontal: 8, flexDirection: "row", alignItems: "center", gap: 5 }, widePanelText: { fontFamily: "Inter_500Medium", fontSize: 9 },
  explorerLabel: { fontFamily: "Inter_600SemiBold", fontSize: 9, letterSpacing: 0.8 }, explorerActions: { flexDirection: "row", gap: 15, alignItems: "center" }, searchBox: { height: 34, borderWidth: 1, borderRadius: 7, margin: 8, paddingHorizontal: 8, flexDirection: "row", alignItems: "center", gap: 6 },
  searchInput: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 10, paddingVertical: 0 }, skeleton: { height: 12, borderRadius: 5, opacity: 0.65 }, fileRow: { minHeight: 34, flexDirection: "row", alignItems: "center", paddingRight: 5 },
  filePress: { flex: 1, minWidth: 0, minHeight: 34, flexDirection: "row", alignItems: "center", gap: 7, paddingRight: 3 }, fileName: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 10 }, fileAction: { width: 26, height: 32, alignItems: "center", justifyContent: "center" },
  editor: { flex: 1, minHeight: 0 }, editorHeader: { minHeight: 39, paddingHorizontal: 10, flexDirection: "row", alignItems: "center", gap: 8, borderBottomWidth: StyleSheet.hairlineWidth }, editorPath: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 10 }, lang: { fontFamily: "Inter_400Regular", fontSize: 8 },
  codeArea: { flex: 1, minHeight: 0, flexDirection: "row" }, gutter: { width: 37, paddingTop: 12 }, lineNumbers: { fontFamily: "monospace", fontSize: 10, lineHeight: 19, textAlign: "right", paddingRight: 8 }, codeInput: { ...StyleSheet.absoluteFill, left: 37, right: 0, zIndex: 2, minWidth: 0, fontFamily: "monospace", lineHeight: 19, paddingHorizontal: 9, paddingTop: 12, paddingBottom: 20, includeFontPadding: false, textAlignVertical: "top" },
  highlightLayer: { ...StyleSheet.absoluteFill, left: 46, paddingTop: 12, paddingHorizontal: 9, paddingBottom: 20, zIndex: 1 },
  statusBar: { minHeight: 27, borderTopWidth: StyleSheet.hairlineWidth, paddingHorizontal: 9, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, statusText: { fontFamily: "Inter_400Regular", fontSize: 8 },
  editorEmpty: { flex: 1, alignItems: "center", justifyContent: "center", gap: 8, padding: 20 }, emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 }, emptyText: { fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 17, textAlign: "center" },
  bottomNav: { minHeight: 58, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-around", paddingTop: 5 }, bottomItem: { minWidth: 47, alignItems: "center", gap: 3 }, bottomText: { fontFamily: "Inter_500Medium", fontSize: 8 },
  panel: { flex: 1, padding: 14 }, panelHeader: { height: 39, flexDirection: "row", alignItems: "center", paddingHorizontal: 10, borderBottomWidth: StyleSheet.hairlineWidth, gap: 12 }, panelTab: { height: 39, justifyContent: "center", borderBottomWidth: 2, borderBottomColor: "transparent", paddingHorizontal: 4 }, panelTabText: { fontFamily: "Inter_500Medium", fontSize: 11 }, aiState: { fontFamily: "Inter_500Medium", fontSize: 9 },
  attachHeader: { height: 36, borderBottomWidth: StyleSheet.hairlineWidth, paddingHorizontal: 11, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, attachToggle: { flexDirection: "row", alignItems: "center", gap: 6 }, attachTitle: { fontFamily: "Inter_400Regular", fontSize: 10 }, attachmentList: { maxHeight: 170, borderBottomWidth: StyleSheet.hairlineWidth, padding: 8 },
  attachmentRow: { minHeight: 31, flexDirection: "row", alignItems: "center", gap: 9 }, attachmentName: { flex: 1, minWidth: 0, flexDirection: "row", alignItems: "center", gap: 7 }, attachText: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 10 }, attachSize: { fontFamily: "monospace", fontSize: 8 }, panelHint: { fontFamily: "Inter_400Regular", fontSize: 9, lineHeight: 14, marginTop: 5 },
  warningText: { fontFamily: "Inter_400Regular", fontSize: 10, paddingHorizontal: 11, paddingVertical: 6 }, chatMessages: { flex: 1 }, chatContent: { padding: 10, gap: 9 }, chatEmpty: { alignItems: "center", justifyContent: "center", padding: 24, gap: 8 }, messageCard: { borderWidth: 1, borderRadius: 10, padding: 10 }, messageMeta: { flexDirection: "row", justifyContent: "space-between" }, messageRole: { fontFamily: "Inter_600SemiBold", fontSize: 8, letterSpacing: 0.6 }, messageText: { fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 17, marginTop: 6 }, changeRow: { minHeight: 30, borderWidth: 1, borderRadius: 6, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 8 }, changeText: { flex: 1, fontFamily: "monospace", fontSize: 9 },
  composer: { flexDirection: "row", alignItems: "flex-end", gap: 7, padding: 8, borderTopWidth: StyleSheet.hairlineWidth }, chatInput: { flex: 1, maxHeight: 120, minHeight: 43, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 9, fontFamily: "Inter_400Regular", fontSize: 11 }, sendButton: { width: 39, height: 39, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  activityRow: { minHeight: 51, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", gap: 9 }, activityDot: { width: 6, height: 6, borderRadius: 3 }, activityAction: { fontFamily: "Inter_500Medium", fontSize: 10 }, activityTime: { fontFamily: "monospace", fontSize: 8 }, panelTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 }, unavailable: { flex: 1, alignItems: "center", justifyContent: "center", padding: 26, gap: 10 }, unavailableIcon: { width: 52, height: 52, borderWidth: 1, borderRadius: 16, alignItems: "center", justifyContent: "center", marginBottom: 2 }, unavailableBody: { maxWidth: 360, textAlign: "center", fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 18 },
  problemRow: { minHeight: 54, borderWidth: 1, borderRadius: 8, paddingHorizontal: 9, marginTop: 8, flexDirection: "row", alignItems: "center", gap: 8 },
  logRow: { minHeight: 30, flexDirection: "row", alignItems: "flex-start", gap: 7, paddingVertical: 4 }, logTime: { fontFamily: "monospace", fontSize: 8 }, logLevel: { width: 32, fontFamily: "monospace", fontSize: 8 }, logMessage: { flex: 1, fontFamily: "monospace", fontSize: 9 }, toolOption: { minHeight: 44, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", gap: 10 }, modalBackdrop: { ...StyleSheet.absoluteFill, backgroundColor: "#0009", justifyContent: "center", padding: 19 }, modalCard: { borderWidth: 1, borderRadius: 15, padding: 16, maxWidth: 540, width: "100%", alignSelf: "center" },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 16, marginBottom: 9 }, modalHint: { fontFamily: "Inter_400Regular", fontSize: 10, lineHeight: 16, marginBottom: 10 }, modalInput: { minHeight: 43, borderWidth: 1, borderRadius: 9, paddingHorizontal: 10, fontFamily: "monospace", fontSize: 11 }, modalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 8, marginTop: 14 }, primaryButton: { minHeight: 39, paddingHorizontal: 13, borderRadius: 9, alignItems: "center", justifyContent: "center", flexDirection: "row" }, primaryText: { fontFamily: "Inter_600SemiBold", fontSize: 10 }, secondaryButton: { minHeight: 39, borderWidth: 1, borderRadius: 9, alignItems: "center", justifyContent: "center", paddingHorizontal: 12 }, actionText: { fontFamily: "Inter_500Medium", fontSize: 10 }, projectOption: { paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth }, projectOptionTitle: { fontFamily: "Inter_500Medium", fontSize: 12 }, modalLink: { paddingTop: 12, alignSelf: "flex-start" },
});
