import { useAuth, useClerk, useUser } from "@clerk/expo";
import { reloadAppAsync } from "expo";
import React, { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import NativeProjectsScreen from "./NativeProjectsScreen";
import NativeSignInScreen from "./NativeSignInScreen";
import NativeWorkspaceScreen from "./NativeWorkspaceScreen";
import { apiRequest, getMe, setNativeAuthTokenGetter, type Identity, type Project, type TokenGetter } from "../lib/api";
import { useColors } from "../hooks/useColors";

type TermsDocument = {
  title: string;
  version: string;
  accepted: boolean;
  sections: { heading: string; body: string }[];
};

function LoadingScreen({ label }: { label: string }) {
  const colors = useColors();
  return <View style={[styles.center, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /><Text style={[styles.loadingText, { color: colors.mutedForeground }]}>{label}</Text></View>;
}

export default function NativeSpikeApp() {
  const { isLoaded, isSignedIn, getToken } = useAuth();
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [terms, setTerms] = useState<TermsDocument | null>(null);
  const [authError, setAuthError] = useState("");
  const [authTimedOut, setAuthTimedOut] = useState(false);
  const [loading, setLoading] = useState(false);
  const [project, setProject] = useState<Project | null>(null);
  const { signOut } = useClerk();
  const { user } = useUser();
  const colors = useColors();

  const tokenGetter: TokenGetter = useCallback(() => getToken(), [getToken]);
  useEffect(() => {
    setNativeAuthTokenGetter(tokenGetter);
    return () => setNativeAuthTokenGetter(null);
  }, [tokenGetter]);

  useEffect(() => {
    if (isLoaded) {
      setAuthTimedOut(false);
      return;
    }
    const timeout = setTimeout(() => setAuthTimedOut(true), 25000);
    return () => clearTimeout(timeout);
  }, [isLoaded]);

  const loadIdentity = useCallback(async () => {
    if (!isSignedIn) {
      setIdentity(null);
      setTerms(null);
      setAuthError("");
      return;
    }
    setLoading(true);
    setAuthError("");
    try {
      const current = await getMe();
      const currentTerms = await apiRequest<TermsDocument>("/api/terms");
      setIdentity(current);
      setTerms(currentTerms);
    } catch (cause) {
      const status = cause && typeof cause === "object" && "status" in cause ? Number(cause.status) : 0;
      setIdentity(null);
      setTerms(null);
      setAuthError(status === 403
        ? "To konto nie ma dostępu do Spike. Administrator musi dopuścić dokładnie ten zweryfikowany adres e-mail."
        : cause instanceof Error ? cause.message : "Nie udało się zweryfikować konta.");
    } finally {
      setLoading(false);
    }
  }, [isSignedIn, tokenGetter]);

  useEffect(() => {
    if (isLoaded) void loadIdentity();
  }, [isLoaded, isSignedIn, loadIdentity]);

  if (!isLoaded) {
    if (!authTimedOut) return <LoadingScreen label="Przygotowywanie logowania…" />;
    return (
      <View style={[styles.center, styles.errorScreen, { backgroundColor: colors.background }]}>
        <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
        <Text style={[styles.errorText, { color: colors.mutedForeground }]}>
          Logowanie nie odpowiedziało. Sprawdź połączenie internetowe i uruchom Spike ponownie.
        </Text>
        <Pressable
          accessibilityRole="button"
          testID="retry-auth-startup"
          onPress={() => void reloadAppAsync()}
          style={[styles.action, { backgroundColor: colors.primary }]}
        >
          <Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>Uruchom ponownie Spike</Text>
        </Pressable>
      </View>
    );
  }
  if (!isSignedIn) return <NativeSignInScreen />;
  if (loading) return <LoadingScreen label="Sprawdzanie dostępu…" />;
  if (authError) {
    return (
      <View style={[styles.center, styles.errorScreen, { backgroundColor: colors.background }]}>
        <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
        <Text style={[styles.errorText, { color: colors.mutedForeground }]}>{authError}</Text>
        <Pressable onPress={() => void signOut()} style={[styles.action, { backgroundColor: colors.primary }]}><Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>Wyloguj</Text></Pressable>
        <Pressable onPress={() => void loadIdentity()}><Text style={[styles.retry, { color: colors.primary }]}>Sprawdź ponownie</Text></Pressable>
      </View>
    );
  }
  if (!identity || !terms) return <LoadingScreen label="Wczytywanie konta…" />;
  if (!terms.accepted) {
    return <TermsScreen terms={terms} onAccepted={() => void loadIdentity()} onSignOut={() => void signOut()} />;
  }
  if (project) return <NativeWorkspaceScreen project={project} onBack={() => setProject(null)} />;
  return (
    <NativeProjectsScreen
      displayName={identity.displayName || user?.firstName || identity.email}
      email={identity.email}
      onOpen={setProject}
      onSignOut={() => void signOut()}
    />
  );
}

function TermsScreen({ terms, onAccepted, onSignOut }: { terms: TermsDocument; onAccepted: () => void; onSignOut: () => void }) {
  const colors = useColors();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const accept = async () => {
    setBusy(true);
    setError("");
    try {
      await apiRequest("/api/terms/accept", { method: "POST", body: JSON.stringify({ version: terms.version }) });
      onAccepted();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się zapisać akceptacji.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <View style={[styles.termsScreen, { backgroundColor: colors.background }]}>
      <View style={[styles.termsHeader, { borderBottomColor: colors.border }]}>
        <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
        <Pressable onPress={onSignOut}><Text style={[styles.retry, { color: colors.mutedForeground }]}>Wyloguj</Text></Pressable>
      </View>
      <ScrollView contentContainerStyle={styles.termsContent}>
        <Text style={[styles.termsTitle, { color: colors.foreground }]}>{terms.title}</Text>
        <Text style={[styles.termsIntro, { color: colors.mutedForeground }]}>Przeczytaj i zaakceptuj, aby kontynuować.</Text>
        {terms.sections.map((section) => (
          <View key={section.heading} style={styles.termsSection}>
            <Text style={[styles.termsHeading, { color: colors.foreground }]}>{section.heading}</Text>
            <Text style={[styles.termsBody, { color: colors.mutedForeground }]}>{section.body}</Text>
          </View>
        ))}
        {error ? <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text> : null}
        <Pressable disabled={busy} onPress={() => void accept()} style={[styles.action, { backgroundColor: colors.primary, opacity: busy ? 0.6 : 1 }]}>
          {busy ? <ActivityIndicator color={colors.primaryForeground} /> : <Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>Akceptuję regulamin</Text>}
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24 },
  loadingText: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 12 },
  errorScreen: { gap: 12 },
  brand: { fontFamily: "Inter_700Bold", fontSize: 22 },
  errorText: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 20, textAlign: "center" },
  action: { minHeight: 46, borderRadius: 13, alignItems: "center", justifyContent: "center", paddingHorizontal: 16, marginTop: 8 },
  actionLabel: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  retry: { fontFamily: "Inter_500Medium", fontSize: 12, marginTop: 4 },
  termsScreen: { flex: 1 },
  termsHeader: { minHeight: 56, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18 },
  termsContent: { padding: 20, paddingBottom: 40 },
  termsTitle: { fontFamily: "Inter_700Bold", fontSize: 21 },
  termsIntro: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 6, marginBottom: 18 },
  termsSection: { marginBottom: 16 },
  termsHeading: { fontFamily: "Inter_600SemiBold", fontSize: 13, marginBottom: 5 },
  termsBody: { fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 18 },
});
