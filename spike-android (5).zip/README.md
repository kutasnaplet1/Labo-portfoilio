# Spike na Androida

Spike Android jest aplikacją Expo z natywnymi ekranami logowania, projektów,
plików i edycji kodu. Nie osadza strony Spike ani nie używa WebView. Projekty i
pliki są pobierane i zapisywane przez zabezpieczone API Spike.

## Logowanie

Logowanie Google korzysta z natywnego SDK Clerk i otwiera bezpieczną
przeglądarkę systemową zamiast osadzonego WebView. Dzięki temu może korzystać
z sesji Google zapisanych w Chrome. Lista kont systemowych Androida nie jest
gwarantowana, jeśli nie są zalogowane w przeglądarce. Po logowaniu serwer
sprawdza zweryfikowany adres e-mail i uprawnienia Spike.

APK pobiera publiczny klucz Clerk z endpointu serwera. Nie umieszczaj sekretów
Clerk w repozytorium GitHub ani w APK. Endpoint `/api/auth/public-config`
zwraca klucz publishable i, w produkcji, adres proxy Clerk pod tą samą domeną.
Opublikuj zaktualizowany serwer przed budową APK, inaczej logowanie może nie
zakończyć inicjalizacji.

## Funkcje natywne dostępne obecnie

- logowanie Google przez Clerk,
- akceptacja regulaminu i sprawdzenie dostępu po stronie serwera,
- wyszukiwanie i tworzenie projektów,
- zmiana nazwy i usuwanie projektu z potwierdzeniem,
- lista plików i folderów, tworzenie, zmiana ścieżki i usuwanie,
- edycja tekstu pliku i zapis na serwerze z kontrolą wersji.

To jest pierwsza natywna wersja mobilna, a nie pełny port funkcji desktopowego
IDE. Natywna wersja nie ma jeszcze panelu AI, preview/run, panelu admina ani
edytora z podświetlaniem składni. Pozostają dostępne w aplikacji webowej.

## Budowanie APK przez GitHub Actions

1. Wypakuj zawartość ZIP-a do głównego katalogu repozytorium GitHub.
2. Wypchnij pliki na gałąź `main`.
3. Otwórz **Actions → Build APK → Run workflow**.
4. Pobierz artefakt `spike-android-apk`, który zawiera `spike-android.apk`.

Workflow ustawia domenę serwera jako `EXPO_PUBLIC_DOMAIN`. Jeśli domena Spike
się zmieni, zaktualizuj tę wartość w `.github/workflows/build-apk.yml`.

## Podpis i aktualizacje

Do kolejnych aktualizacji użyj dokładnie tego samego klucza podpisu. Możesz
przechowywać go jako sekrety GitHub Actions:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Jeśli obecna instalacja jest podpisana kluczem debug, kolejny build również
musi użyć tego samego klucza debug. Zmiana klucza podpisu wymaga odinstalowania
starej aplikacji i powoduje utratę jej lokalnych danych.

Identyfikator aplikacji pozostaje `com.labo17dev.spike`. Dla tej wersji
`VERSION` to `1.0.3`, a `VERSION_CODE` to `4`. Przy następnym APK zwiększ
`VERSION_CODE`, zachowaj identyfikator aplikacji i ten sam klucz podpisu.
Android zainstaluje taki APK jako aktualizację bez usuwania danych.

Play Protect może ostrzegać o aplikacjach instalowanych spoza Google Play.
Nie da się bezpiecznie wyłączyć tego ostrzeżenia kodem aplikacji.
