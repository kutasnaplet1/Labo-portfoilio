const spikePalette = {
  text: "#e9e9e2",
  tint: "#aad643",
  background: "#121217",
  foreground: "#e9e9e2",
  card: "#17181e",
  cardForeground: "#e9e9e2",
  primary: "#aad643",
  primaryForeground: "#101119",
  secondary: "#22232a",
  secondaryForeground: "#e9e9e2",
  muted: "#1e1f25",
  mutedForeground: "#9194a1",
  accent: "#24262d",
  accentForeground: "#e9e9e2",
  destructive: "#df4e49",
  destructiveForeground: "#ffffff",
  border: "#24262d",
  input: "#24262d",
};

const colors = {
  light: spikePalette,
  dark: spikePalette,
  radius: 8,
};

export default colors;
