import { Feather } from "@expo/vector-icons";
import {
  createProject,
  deleteProject,
  listProjects,
  renameProject,
  type Project,
  type ProjectInputTemplate,
} from "../lib/api";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useColors } from "../hooks/useColors";

type Props = {
  displayName: string;
  email: string;
  onOpen: (project: Project) => void;
  onSignOut: () => void;
};

const TEMPLATES: { id: ProjectInputTemplate; label: string; detail: string }[] = [
  { id: "blank", label: "Pusty", detail: "README.md" },
  { id: "web", label: "Web", detail: "HTML, CSS i JavaScript" },
  { id: "typescript", label: "TypeScript", detail: "Projekt TypeScript" },
];

export default function NativeProjectsScreen({ displayName, email, onOpen, onSignOut }: Props) {
  const colors = useColors();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState<"create" | "rename" | null>(null);
  const [editing, setEditing] = useState<Project | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [template, setTemplate] = useState<ProjectInputTemplate>("blank");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async (quiet = false) => {
    if (quiet) setRefreshing(true);
    else setLoading(true);
    setError("");
    try {
      setProjects(await listProjects());
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się pobrać projektów.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const visibleProjects = useMemo(() => {
    const needle = search.trim().toLocaleLowerCase();
    return projects
      .filter((project) => !needle || `${project.name} ${project.description}`.toLocaleLowerCase().includes(needle))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }, [projects, search]);

  const openCreate = () => {
    setEditing(null);
    setName("");
    setDescription("");
    setTemplate("blank");
    setModal("create");
  };

  const openRename = (project: Project) => {
    setEditing(project);
    setName(project.name);
    setModal("rename");
  };

  const submit = async () => {
    const cleanName = name.trim();
    if (!cleanName) return;
    setSaving(true);
    setError("");
    try {
      if (modal === "create") {
        const project = await createProject({ name: cleanName, description: description.trim(), template });
        setProjects((current) => [project, ...current]);
        setModal(null);
        onOpen(project);
      } else if (modal === "rename" && editing) {
        const updated = await renameProject(editing.id, { name: cleanName });
        setProjects((current) => current.map((project) => project.id === updated.id ? updated : project));
        setModal(null);
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się zapisać projektu.");
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = (project: Project) => Alert.alert(
    "Usunąć projekt?",
    `Projekt „${project.name}” i jego pliki zostaną trwale usunięte.`,
    [
      { text: "Anuluj", style: "cancel" },
      {
        text: "Usuń",
        style: "destructive",
        onPress: () => {
          void deleteProject(project.id)
            .then(() => setProjects((current) => current.filter((item) => item.id !== project.id)))
            .catch((cause) => setError(cause instanceof Error ? cause.message : "Nie udało się usunąć projektu."));
        },
      },
    ],
  );

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <View style={styles.brandRow}>
          <Text style={[styles.brand, { color: colors.foreground }]}>Spike</Text>
          <View style={[styles.onlineDot, { backgroundColor: colors.primary }]} />
        </View>
        <Pressable onPress={onSignOut} accessibilityRole="button" accessibilityLabel={`Wyloguj ${email}`} style={styles.profileButton} testID="native-signout">
          <Feather name="log-out" size={17} color={colors.mutedForeground} />
        </Pressable>
      </View>
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(true)} tintColor={colors.primary} />}
      >
        <Text style={[styles.eyebrow, { color: colors.primary }]}>PRZESTRZEŃ ROBOCZA</Text>
        <Text style={[styles.heading, { color: colors.foreground }]}>Cześć, {displayName}</Text>
        <Text style={[styles.subheading, { color: colors.mutedForeground }]}>Twoje projekty, zapisane na serwerze Spike.</Text>

        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            accessibilityLabel="Szukaj projektów"
            value={search}
            onChangeText={setSearch}
            placeholder="Szukaj projektów"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.searchInput, { color: colors.foreground }]}
            testID="native-project-search"
          />
          {search ? <Pressable onPress={() => setSearch("")}><Feather name="x" size={16} color={colors.mutedForeground} /></Pressable> : null}
        </View>

        <Pressable
          accessibilityRole="button"
          onPress={openCreate}
          style={({ pressed }) => [styles.createButton, { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 }]}
          testID="native-create-project"
        >
          <Feather name="plus" size={18} color={colors.primaryForeground} />
          <Text style={[styles.createLabel, { color: colors.primaryForeground }]}>Nowy projekt</Text>
        </Pressable>

        <View style={styles.sectionHeading}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Projekty</Text>
          <Text style={[styles.count, { color: colors.mutedForeground }]}>{visibleProjects.length}</Text>
        </View>

        {loading ? (
          <View style={styles.stateBox}><ActivityIndicator color={colors.primary} /><Text style={[styles.stateText, { color: colors.mutedForeground }]}>Ładowanie projektów…</Text></View>
        ) : error ? (
          <View style={[styles.stateBox, styles.errorState, { borderColor: colors.destructive }]}>
            <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
            <Pressable onPress={() => void load()}><Text style={[styles.retryText, { color: colors.primary }]}>Spróbuj ponownie</Text></Pressable>
          </View>
        ) : visibleProjects.length === 0 ? (
          <View style={[styles.stateBox, styles.emptyBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name={search ? "search" : "folder"} size={23} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{search ? "Brak wyników" : "Nie masz jeszcze projektów"}</Text>
            <Text style={[styles.stateText, { color: colors.mutedForeground }]}>{search ? "Zmień wyszukiwaną frazę." : "Utwórz projekt, aby zacząć."}</Text>
          </View>
        ) : (
          <View style={styles.projectList}>
            {visibleProjects.map((project) => (
              <View key={project.id} style={[styles.projectCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Pressable onPress={() => onOpen(project)} style={({ pressed }) => [styles.projectMain, { opacity: pressed ? 0.72 : 1 }]} testID={`native-project-${project.id}`}>
                  <View style={[styles.projectIcon, { backgroundColor: colors.muted }]}>
                    <Feather name={project.template === "web" ? "globe" : "code"} size={17} color={colors.primary} />
                  </View>
                  <View style={styles.projectInfo}>
                    <Text numberOfLines={1} style={[styles.projectName, { color: colors.foreground }]}>{project.name}</Text>
                    <Text numberOfLines={1} style={[styles.projectDescription, { color: colors.mutedForeground }]}>{project.description || project.template}</Text>
                    <Text style={[styles.projectDate, { color: colors.mutedForeground }]}>{formatDate(project.updatedAt)}</Text>
                  </View>
                  <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
                </Pressable>
                <View style={[styles.cardActions, { borderTopColor: colors.border }]}>
                  <Pressable onPress={() => openRename(project)} style={styles.actionButton} accessibilityRole="button" accessibilityLabel={`Zmień nazwę ${project.name}`}>
                    <Feather name="edit-2" size={14} color={colors.mutedForeground} /><Text style={[styles.actionLabel, { color: colors.mutedForeground }]}>Zmień nazwę</Text>
                  </Pressable>
                  <Pressable onPress={() => confirmDelete(project)} style={styles.actionButton} accessibilityRole="button" accessibilityLabel={`Usuń ${project.name}`}>
                    <Feather name="trash-2" size={14} color={colors.destructive} /><Text style={[styles.actionLabel, { color: colors.destructive }]}>Usuń</Text>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      <Modal transparent animationType="fade" visible={modal !== null} onRequestClose={() => setModal(null)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>{modal === "create" ? "Nowy projekt" : "Zmień nazwę"}</Text>
            <TextInput
              autoFocus
              value={name}
              onChangeText={setName}
              maxLength={80}
              placeholder="Nazwa projektu"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.modalInput, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]}
              testID="native-project-name"
            />
            {modal === "create" ? (
              <>
                <TextInput
                  value={description}
                  onChangeText={setDescription}
                  maxLength={500}
                  placeholder="Opis (opcjonalnie)"
                  placeholderTextColor={colors.mutedForeground}
                  style={[styles.modalInput, styles.descriptionInput, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]}
                />
                <Text style={[styles.templateLabel, { color: colors.mutedForeground }]}>SZABLON</Text>
                <View style={styles.templateRow}>
                  {TEMPLATES.map((item) => (
                    <Pressable
                      key={item.id}
                      onPress={() => setTemplate(item.id)}
                      style={[styles.templateChip, { borderColor: template === item.id ? colors.primary : colors.border, backgroundColor: template === item.id ? colors.primary + "18" : colors.background }]}
                    >
                      <Text style={[styles.templateName, { color: template === item.id ? colors.primary : colors.foreground }]}>{item.label}</Text>
                      <Text numberOfLines={1} style={[styles.templateDetail, { color: colors.mutedForeground }]}>{item.detail}</Text>
                    </Pressable>
                  ))}
                </View>
              </>
            ) : null}
            {error ? <Text style={[styles.modalError, { color: colors.destructive }]}>{error}</Text> : null}
            <View style={styles.modalActions}>
              <Pressable onPress={() => setModal(null)} style={[styles.cancelButton, { borderColor: colors.border }]}><Text style={[styles.cancelLabel, { color: colors.foreground }]}>Anuluj</Text></Pressable>
              <Pressable disabled={saving || !name.trim()} onPress={() => void submit()} style={[styles.confirmButton, { backgroundColor: colors.primary, opacity: saving || !name.trim() ? 0.5 : 1 }]}>
                {saving ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Text style={[styles.confirmLabel, { color: colors.primaryForeground }]}>{modal === "create" ? "Utwórz" : "Zapisz"}</Text>}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function formatDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Data niedostępna" : `Zmieniono ${date.toLocaleDateString("pl-PL")}`;
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { minHeight: 58, borderBottomWidth: StyleSheet.hairlineWidth, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  brand: { fontFamily: "Inter_700Bold", fontSize: 18 },
  onlineDot: { width: 7, height: 7, borderRadius: 4 },
  profileButton: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  content: { padding: 20, paddingBottom: 36 },
  eyebrow: { fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 1.2, marginTop: 8 },
  heading: { fontFamily: "Inter_700Bold", fontSize: 25, marginTop: 8 },
  subheading: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 19, marginTop: 5, marginBottom: 20 },
  searchBox: { height: 46, borderWidth: 1, borderRadius: 13, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 13 },
  searchInput: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 13, paddingVertical: 0 },
  createButton: { height: 48, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, marginTop: 12 },
  createLabel: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  sectionHeading: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 26, marginBottom: 12 },
  sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16 },
  count: { fontFamily: "Inter_500Medium", fontSize: 12 },
  projectList: { gap: 10 },
  projectCard: { borderWidth: 1, borderRadius: 16, overflow: "hidden" },
  projectMain: { minHeight: 76, flexDirection: "row", alignItems: "center", paddingHorizontal: 13, paddingVertical: 12, gap: 12 },
  projectIcon: { width: 39, height: 39, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  projectInfo: { flex: 1, gap: 3 },
  projectName: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  projectDescription: { fontFamily: "Inter_400Regular", fontSize: 11 },
  projectDate: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 1 },
  cardActions: { minHeight: 38, flexDirection: "row", borderTopWidth: StyleSheet.hairlineWidth, paddingHorizontal: 12, gap: 18 },
  actionButton: { flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 8 },
  actionLabel: { fontFamily: "Inter_500Medium", fontSize: 11 },
  stateBox: { minHeight: 120, alignItems: "center", justifyContent: "center", gap: 10, padding: 18 },
  stateText: { fontFamily: "Inter_400Regular", fontSize: 12, textAlign: "center" },
  errorState: { borderWidth: 1, borderRadius: 14, gap: 9 },
  errorText: { fontFamily: "Inter_400Regular", fontSize: 12, textAlign: "center" },
  retryText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  emptyBox: { borderWidth: 1, borderRadius: 16 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  modalBackdrop: { flex: 1, backgroundColor: "#0009", justifyContent: "center", padding: 20 },
  modalCard: { borderWidth: 1, borderRadius: 20, padding: 19 },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 18, marginBottom: 15 },
  modalInput: { borderWidth: 1, borderRadius: 11, minHeight: 46, paddingHorizontal: 12, fontFamily: "Inter_400Regular", fontSize: 13, marginBottom: 10 },
  descriptionInput: { minHeight: 42 },
  templateLabel: { fontFamily: "Inter_600SemiBold", fontSize: 9, letterSpacing: 1, marginTop: 2, marginBottom: 7 },
  templateRow: { flexDirection: "row", gap: 7 },
  templateChip: { flex: 1, borderWidth: 1, borderRadius: 10, padding: 9 },
  templateName: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  templateDetail: { fontFamily: "Inter_400Regular", fontSize: 8, marginTop: 3 },
  modalError: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 10 },
  modalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 9, marginTop: 16 },
  cancelButton: { minWidth: 86, minHeight: 42, borderWidth: 1, borderRadius: 11, justifyContent: "center", alignItems: "center" },
  cancelLabel: { fontFamily: "Inter_500Medium", fontSize: 12 },
  confirmButton: { minWidth: 100, minHeight: 42, borderRadius: 11, justifyContent: "center", alignItems: "center" },
  confirmLabel: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
});
