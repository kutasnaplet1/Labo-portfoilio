import { Feather } from "@expo/vector-icons";
import {
  createFile,
  deleteFile,
  listFiles,
  updateFile,
  type Project,
  type ProjectFile,
} from "../lib/api";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useColors } from "../hooks/useColors";

type Props = { project: Project; onBack: () => void };

export default function NativeWorkspaceScreen({ project, onBack }: Props) {
  const colors = useColors();
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [active, setActive] = useState<ProjectFile | null>(null);
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [modal, setModal] = useState<"file" | "folder" | "rename" | null>(null);
  const [pathInput, setPathInput] = useState("");

  const loadFiles = useCallback(async (keepSelection = true) => {
    setLoading(true);
    setError("");
    try {
      const result = await listFiles(project.id);
      setFiles(result);
      if (keepSelection && active) {
        const updated = result.find((file) => file.id === active.id);
        if (updated) {
          setActive(updated);
          setDraft(updated.content);
        } else {
          setActive(null);
          setDraft("");
        }
      } else if (!keepSelection) {
        setActive(null);
        setDraft("");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się pobrać plików.");
    } finally {
      setLoading(false);
    }
  }, [project.id, active]);

  useEffect(() => { void loadFiles(false); }, [loadFiles]);

  const shownFiles = useMemo(() => files.filter((file) => {
    if (search.trim()) return file.path.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase());
    const parts = file.path.split("/");
    return !parts.slice(0, -1).some((_, index) => collapsed.has(parts.slice(0, index + 1).join("/")));
  }), [files, search, collapsed]);

  const isDirty = !!active && active.kind === "file" && draft !== active.content;

  const selectFile = (file: ProjectFile) => {
    if (isDirty) {
      Alert.alert("Niezapisane zmiany", "Zapisz lub odrzuć zmiany przed otwarciem innego pliku.", [
        { text: "Zostań", style: "cancel" },
        { text: "Odrzuć", style: "destructive", onPress: () => { setActive(file); setDraft(file.content); } },
      ]);
      return;
    }
    if (file.kind === "folder") {
      setCollapsed((current) => {
        const next = new Set(current);
        if (next.has(file.path)) next.delete(file.path);
        else next.add(file.path);
        return next;
      });
      return;
    }
    setActive(file);
    setDraft(file.content);
  };

  const saveFile = async () => {
    if (!active || !isDirty) return;
    setSaving(true);
    setError("");
    try {
      const updated = await updateFile(project.id, active.id, { content: draft, version: active.version });
      setFiles((current) => current.map((file) => file.id === updated.id ? updated : file));
      setActive(updated);
      setDraft(updated.content);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się zapisać pliku.");
    } finally {
      setSaving(false);
    }
  };

  const openCreate = (kind: "file" | "folder") => {
    setPathInput("");
    setModal(kind);
  };

  const submitPath = async () => {
    const path = pathInput.trim().replace(/^\/+|\/+$/g, "");
    if (!path || path.split("/").some((part) => !part || part === "." || part === "..")) {
      setError("Podaj prawidłową ścieżkę bez segmentów „.” ani „..”.");
      return;
    }
    setError("");
    try {
      if (modal === "rename" && active) {
        const updated = await updateFile(project.id, active.id, { path, version: active.version });
        setFiles((current) => current.map((file) => file.id === updated.id ? updated : file));
        setActive(updated);
        setDraft(updated.content);
      } else if (modal === "file" || modal === "folder") {
        const created = await createFile(project.id, { path, kind: modal });
        setFiles((current) => [...current, created].sort((a, b) => a.path.localeCompare(b.path)));
        if (created.kind === "file") {
          setActive(created);
          setDraft(created.content);
        }
      }
      setModal(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się wykonać operacji na pliku.");
    }
  };

  const confirmDelete = (file: ProjectFile) => Alert.alert(
    file.kind === "folder" ? "Usunąć folder?" : "Usunąć plik?",
    file.kind === "folder" ? `Folder „${file.path}” i jego zawartość zostaną trwale usunięte.` : `Plik „${file.path}” zostanie trwale usunięty.`,
    [
      { text: "Anuluj", style: "cancel" },
      {
        text: "Usuń",
        style: "destructive",
        onPress: () => {
          void deleteFile(project.id, file.id)
            .then(() => {
              if (active?.id === file.id || (file.kind === "folder" && active?.path.startsWith(`${file.path}/`))) {
                setActive(null);
                setDraft("");
              }
              void loadFiles(false);
            })
            .catch((cause) => setError(cause instanceof Error ? cause.message : "Nie udało się usunąć elementu."));
        },
      },
    ],
  );

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => {
          if (isDirty) {
            Alert.alert("Niezapisane zmiany", "Czy na pewno wrócić bez zapisywania?", [
              { text: "Zostań", style: "cancel" },
              { text: "Wróć", style: "destructive", onPress: onBack },
            ]);
          } else onBack();
        }} style={styles.headerIcon} accessibilityRole="button" accessibilityLabel="Wróć do projektów">
          <Feather name="arrow-left" size={19} color={colors.foreground} />
        </Pressable>
        <View style={styles.headerTitleWrap}>
          <Text numberOfLines={1} style={[styles.brand, { color: colors.foreground }]}>{project.name}</Text>
          <Text style={[styles.headerCaption, { color: colors.mutedForeground }]}>Przestrzeń projektu</Text>
        </View>
        <Pressable
          onPress={() => void saveFile()}
          disabled={!isDirty || saving}
          style={[styles.saveButton, { backgroundColor: isDirty ? colors.primary : colors.muted, opacity: saving ? 0.7 : 1 }]}
          accessibilityRole="button"
          accessibilityLabel="Zapisz plik"
          testID="native-save-file"
        >
          {saving ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Feather name="save" size={15} color={isDirty ? colors.primaryForeground : colors.mutedForeground} />}
          <Text style={[styles.saveText, { color: isDirty ? colors.primaryForeground : colors.mutedForeground }]}>Zapisz</Text>
        </Pressable>
      </View>

      <View style={[styles.toolbar, { borderBottomColor: colors.border }]}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={14} color={colors.mutedForeground} />
          <TextInput value={search} onChangeText={setSearch} placeholder="Szukaj pliku" placeholderTextColor={colors.mutedForeground} style={[styles.searchInput, { color: colors.foreground }]} />
        </View>
        <Pressable onPress={() => openCreate("file")} style={styles.toolButton} accessibilityLabel="Utwórz plik"><Feather name="file-plus" size={17} color={colors.foreground} /></Pressable>
        <Pressable onPress={() => openCreate("folder")} style={styles.toolButton} accessibilityLabel="Utwórz folder"><Feather name="folder-plus" size={17} color={colors.foreground} /></Pressable>
        <Pressable onPress={() => void loadFiles()} style={styles.toolButton} accessibilityLabel="Odśwież pliki"><Feather name="refresh-cw" size={16} color={colors.foreground} /></Pressable>
      </View>

      {error ? <View style={[styles.errorBanner, { borderBottomColor: colors.border }]}><Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text><Pressable onPress={() => setError("")}><Feather name="x" size={16} color={colors.mutedForeground} /></Pressable></View> : null}

      <View style={styles.body}>
        <View style={[styles.filePane, { borderRightColor: colors.border }]}>
          <Text style={[styles.paneLabel, { color: colors.mutedForeground }]}>PLIKI</Text>
          {loading ? <ActivityIndicator style={styles.loader} color={colors.primary} /> : (
            <ScrollView keyboardShouldPersistTaps="handled">
              {shownFiles.map((file) => {
                const depth = Math.max(0, file.path.split("/").length - 1);
                const isActive = active?.id === file.id;
                const isFolderCollapsed = collapsed.has(file.path);
                return (
                  <View key={file.id} style={[styles.fileRow, isActive && { backgroundColor: colors.accent }]}>
                    <Pressable onPress={() => selectFile(file)} style={styles.fileSelect} testID={`native-file-${file.id}`}>
                      <View style={{ width: Math.min(depth * 11, 44) }} />
                      <Feather
                        name={file.kind === "folder" ? "folder" : iconForPath(file.path)}
                        size={14}
                        color={isActive ? colors.primary : colors.mutedForeground}
                      />
                      <Text numberOfLines={1} style={[styles.fileName, { color: isActive ? colors.foreground : colors.mutedForeground }]}>{file.path.split("/").pop()}</Text>
                    </Pressable>
                    <Pressable onPress={() => {
                      setPathInput(file.path);
                      setModal("rename");
                    }} accessibilityLabel={`Zmień nazwę ${file.path}`} style={styles.fileAction}><Feather name="edit-2" size={12} color={colors.mutedForeground} /></Pressable>
                    <Pressable onPress={() => confirmDelete(file)} accessibilityLabel={`Usuń ${file.path}`} style={styles.fileAction}><Feather name="trash-2" size={12} color={colors.mutedForeground} /></Pressable>
                  </View>
                );
              })}
              {!loading && shownFiles.length === 0 ? <Text style={[styles.noFiles, { color: colors.mutedForeground }]}>{search ? "Brak wyników." : "Brak plików."}</Text> : null}
            </ScrollView>
          )}
        </View>

        <View style={styles.editorPane}>
          {active ? (
            <>
              <View style={[styles.editorHeader, { borderBottomColor: colors.border }]}>
                <Feather name={iconForPath(active.path)} size={14} color={colors.primary} />
                <Text numberOfLines={1} style={[styles.editorFileName, { color: colors.foreground }]}>{active.path}</Text>
                {isDirty ? <View style={[styles.dirtyDot, { backgroundColor: colors.primary }]} /> : null}
                <Pressable onPress={() => { setPathInput(active.path); setModal("rename"); }} style={styles.toolButton} accessibilityLabel="Zmień nazwę pliku"><Feather name="edit-2" size={14} color={colors.mutedForeground} /></Pressable>
              </View>
              <View style={styles.codeArea}>
                <ScrollView style={[styles.gutter, { backgroundColor: colors.background }]} scrollEnabled={false}>
                  <Text style={[styles.lineNumbers, { color: colors.mutedForeground }]}>{Array.from({ length: Math.max(draft.split("\n").length, 1) }, (_, i) => i + 1).join("\n")}</Text>
                </ScrollView>
                <TextInput
                  value={draft}
                  onChangeText={setDraft}
                  multiline
                  autoCapitalize="none"
                  autoCorrect={false}
                  spellCheck={false}
                  textAlignVertical="top"
                  style={[styles.codeInput, { color: colors.foreground }]}
                  placeholder="Wpisz kod…"
                  placeholderTextColor={colors.mutedForeground}
                  testID="native-code-editor"
                />
              </View>
              <View style={[styles.statusBar, { borderTopColor: colors.border }]}>
                <Text style={[styles.statusText, { color: colors.mutedForeground }]}>{isDirty ? "Niezapisane zmiany" : `v${active.version} · Zapisano`}</Text>
                <Text style={[styles.statusText, { color: colors.mutedForeground }]}>{draft.split("\n").length} linii</Text>
              </View>
            </>
          ) : (
            <View style={styles.editorEmpty}>
              <Feather name="file-text" size={25} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Otwórz plik</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Wybierz plik z listy albo utwórz nowy.</Text>
            </View>
          )}
        </View>
      </View>

      <Modal transparent animationType="fade" visible={modal !== null} onRequestClose={() => setModal(null)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>{modal === "rename" ? "Zmień ścieżkę" : modal === "folder" ? "Nowy folder" : "Nowy plik"}</Text>
            <Text style={[styles.modalHint, { color: colors.mutedForeground }]}>Ścieżka w projekcie, np. src/app.ts</Text>
            <TextInput
              autoFocus
              value={pathInput}
              onChangeText={setPathInput}
              autoCapitalize="none"
              autoCorrect={false}
              placeholder="folder/nazwa.ext"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.modalInput, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
              testID="native-file-path"
            />
            {error ? <Text style={[styles.modalError, { color: colors.destructive }]}>{error}</Text> : null}
            <View style={styles.modalActions}>
              <Pressable onPress={() => { setModal(null); setError(""); }} style={[styles.cancelButton, { borderColor: colors.border }]}><Text style={[styles.cancelText, { color: colors.foreground }]}>Anuluj</Text></Pressable>
              <Pressable onPress={() => void submitPath()} style={[styles.confirmButton, { backgroundColor: colors.primary }]}><Text style={[styles.confirmText, { color: colors.primaryForeground }]}>{modal === "rename" ? "Zapisz" : "Utwórz"}</Text></Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function iconForPath(path: string) {
  const extension = path.split(".").pop()?.toLowerCase();
  if (extension === "json") return "settings";
  if (extension === "md") return "book-open";
  if (["png", "jpg", "svg"].includes(extension ?? "")) return "image";
  return "file-text";
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { minHeight: 58, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", paddingHorizontal: 8, gap: 5 },
  headerIcon: { width: 42, height: 42, alignItems: "center", justifyContent: "center" },
  headerTitleWrap: { flex: 1 },
  brand: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  headerCaption: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 2 },
  saveButton: { minWidth: 76, height: 36, borderRadius: 11, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 9 },
  saveText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  toolbar: { height: 52, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 9 },
  searchBox: { flex: 1, height: 36, borderWidth: 1, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 9 },
  searchInput: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 11, paddingVertical: 0 },
  toolButton: { width: 34, height: 36, alignItems: "center", justifyContent: "center" },
  errorBanner: { minHeight: 35, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 12 },
  errorText: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 10 },
  body: { flex: 1, flexDirection: "row" },
  filePane: { width: 164, borderRightWidth: StyleSheet.hairlineWidth, paddingTop: 10 },
  paneLabel: { fontFamily: "Inter_600SemiBold", fontSize: 9, letterSpacing: 1, paddingHorizontal: 12, paddingBottom: 8 },
  loader: { marginTop: 20 },
  fileRow: { minHeight: 35, flexDirection: "row", alignItems: "center", paddingRight: 3 },
  fileSelect: { flex: 1, minWidth: 0, flexDirection: "row", alignItems: "center", gap: 6, paddingLeft: 5, height: 35 },
  fileName: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 10 },
  fileAction: { width: 22, height: 33, alignItems: "center", justifyContent: "center" },
  noFiles: { fontFamily: "Inter_400Regular", fontSize: 10, textAlign: "center", padding: 12 },
  editorPane: { flex: 1, minWidth: 0 },
  editorHeader: { height: 42, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", gap: 7, paddingLeft: 10 },
  editorFileName: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 10 },
  dirtyDot: { width: 6, height: 6, borderRadius: 3 },
  codeArea: { flex: 1, flexDirection: "row" },
  gutter: { width: 34, paddingTop: 12 },
  lineNumbers: { fontFamily: "monospace", fontSize: 10, lineHeight: 18, textAlign: "right", paddingRight: 7 },
  codeInput: { flex: 1, fontFamily: "monospace", fontSize: 11, lineHeight: 18, paddingHorizontal: 9, paddingTop: 12, paddingBottom: 18, includeFontPadding: false },
  statusBar: { height: 29, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 9 },
  statusText: { fontFamily: "Inter_400Regular", fontSize: 9 },
  editorEmpty: { flex: 1, alignItems: "center", justifyContent: "center", gap: 8, padding: 18 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 10, textAlign: "center" },
  modalBackdrop: { flex: 1, backgroundColor: "#0009", justifyContent: "center", padding: 20 },
  modalCard: { borderWidth: 1, borderRadius: 18, padding: 18 },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 17 },
  modalHint: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 6, marginBottom: 12 },
  modalInput: { borderWidth: 1, borderRadius: 10, minHeight: 45, paddingHorizontal: 11, fontFamily: "monospace", fontSize: 12 },
  modalError: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 8 },
  modalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 8, marginTop: 15 },
  cancelButton: { minWidth: 80, height: 40, borderWidth: 1, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  cancelText: { fontFamily: "Inter_500Medium", fontSize: 11 },
  confirmButton: { minWidth: 90, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  confirmText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
});
