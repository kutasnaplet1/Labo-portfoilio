import { Feather } from "@expo/vector-icons";
import * as AuthSession from "expo-auth-session";
import * as WebBrowser from "expo-web-browser";
import React, { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, View } from "react-native";
import { useSSO } from "@clerk/expo";
import { useColors } from "../hooks/useColors";

WebBrowser.maybeCompleteAuthSession();

export default function NativeSignInScreen() {
  const colors = useColors();
  const { startSSOFlow } = useSSO();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    void WebBrowser.warmUpAsync();
    return () => {
      void WebBrowser.coolDownAsync();
    };
  }, []);

  const signInWithGoogle = useCallback(async () => {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const result = await startSSOFlow({
        strategy: "oauth_google",
        redirectUrl: AuthSession.makeRedirectUri({ scheme: "spike", path: "sso-callback" }),
      });
      if (result.createdSessionId && result.setActive) {
        await result.setActive({ session: result.createdSessionId });
      } else {
        setError("Logowanie wymaga dodatkowych danych. Spróbuj ponownie albo skontaktuj się z administratorem.");
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Nie udało się zalogować przez Google.");
    } finally {
      setBusy(false);
    }
  }, [busy, startSSOFlow]);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Image source={require("../assets/images/icon.png")} style={styles.logo} resizeMode="contain" />
        <Text style={[styles.title, { color: colors.foreground }]}>Spike</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Zaloguj się, aby otworzyć swoje projekty.
        </Text>
        {error ? (
          <View style={[styles.errorBox, { borderColor: colors.destructive }]}>
            <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
          </View>
        ) : null}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Zaloguj się przez Google"
          disabled={busy}
          onPress={() => void signInWithGoogle()}
          style={({ pressed }) => [
            styles.googleButton,
            { backgroundColor: colors.primary, opacity: busy ? 0.65 : pressed ? 0.82 : 1 },
          ]}
          testID="native-google-signin"
        >
          {busy ? (
            <ActivityIndicator color={colors.primaryForeground} />
          ) : (
            <Feather name="log-in" size={17} color={colors.primaryForeground} />
          )}
          <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>
            {busy ? "Otwieranie bezpiecznego logowania…" : "Zaloguj się przez Google"}
          </Text>
        </Pressable>
        <Text style={[styles.note, { color: colors.mutedForeground }]}>
          Logowanie otworzy bezpieczną przeglądarkę systemową. Po powrocie Spike sprawdzi dostęp przypisany do zweryfikowanego adresu e-mail.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, justifyContent: "center", padding: 22 },
  card: { alignItems: "center", borderWidth: 1, borderRadius: 22, padding: 24 },
  logo: { width: 76, height: 76, marginBottom: 12 },
  title: { fontFamily: "Inter_700Bold", fontSize: 25 },
  subtitle: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", marginTop: 7, marginBottom: 22 },
  googleButton: { minHeight: 50, width: "100%", borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingHorizontal: 14 },
  buttonText: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  note: { fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 17, textAlign: "center", marginTop: 18 },
  errorBox: { width: "100%", borderWidth: 1, borderRadius: 12, padding: 11, marginBottom: 14 },
  errorText: { fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 17 },
});
