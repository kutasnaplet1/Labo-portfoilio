import { Feather } from "@expo/vector-icons";
import { useSignIn, useSignUp } from "@clerk/expo";
import React, { useState } from "react";
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAwareScrollViewCompat } from "./KeyboardAwareScrollViewCompat";
import { useColors } from "../hooks/useColors";

type AuthMode = "sign-in" | "sign-up";
type AuthStep = "credentials" | "verification" | "reset-code" | "reset-new-password";

function authErrorMessage(error: unknown) {
  if (error && typeof error === "object" && "errors" in error) {
    const errors = (error as { errors?: Array<{ message?: string; longMessage?: string }> }).errors;
    const message = errors?.[0]?.longMessage || errors?.[0]?.message;
    if (message) return message;
  }
  if (error instanceof Error && error.message) return error.message;
  return "Nie udało się zalogować. Sprawdź dane i spróbuj ponownie.";
}

export default function NativeSignInScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { signIn, fetchStatus: signInFetchStatus } = useSignIn();
  const { signUp, fetchStatus: signUpFetchStatus } = useSignUp();
  const [mode, setMode] = useState<AuthMode>("sign-in");
  const [step, setStep] = useState<AuthStep>("credentials");
  const [emailAddress, setEmailAddress] = useState("");
  const [password, setPassword] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fetching = busy || signInFetchStatus === "fetching" || signUpFetchStatus === "fetching";

  const submitCredentials = async () => {
    if (fetching || !emailAddress.trim() || !password) return;
    setBusy(true);
    setError("");
    try {
      if (mode === "sign-in") {
        const result = await signIn.password({
          emailAddress: emailAddress.trim(),
          password,
        });
        if (result.error) throw result.error;
        if (signIn.status === "complete") {
          await signIn.finalize();
        } else if (signIn.status === "needs_client_trust" || signIn.status === "needs_second_factor") {
          const emailFactor = signIn.supportedSecondFactors?.find((factor) => factor.strategy === "email_code");
          if (!emailFactor) {
            setError("To konto wymaga dodatkowego sposobu weryfikacji, którego ta aplikacja jeszcze nie obsługuje.");
            return;
          }
          await signIn.mfa.sendEmailCode();
          setStep("verification");
        } else {
          setError("Logowanie wymaga dodatkowego potwierdzenia. Sprawdź dane i spróbuj ponownie.");
        }
      } else {
        const result = await signUp.password({
          emailAddress: emailAddress.trim(),
          password,
        });
        if (result.error) throw result.error;
        await signUp.verifications.sendEmailCode();
        setStep("verification");
      }
    } catch (cause) {
      setError(authErrorMessage(cause));
    } finally {
      setBusy(false);
    }
  };

  const verifyEmailCode = async () => {
    if (fetching || !verificationCode.trim()) return;
    setBusy(true);
    setError("");
    try {
      if (step === "reset-code") {
        const result = await signIn.resetPasswordEmailCode.verifyCode({ code: verificationCode.trim() });
        if (result.error) throw result.error;
        if (signIn.status !== "needs_new_password") {
          setError("Nie udało się potwierdzić kodu. Sprawdź go i spróbuj ponownie.");
          return;
        }
        setPassword("");
        setStep("reset-new-password");
      } else if (mode === "sign-up") {
        const result = await signUp.verifications.verifyEmailCode({ code: verificationCode.trim() });
        if (result.error) throw result.error;
        if (signUp.status !== "complete") {
          setError("Kod nie zakończył rejestracji. Sprawdź kod i spróbuj ponownie.");
          return;
        }
        await signUp.finalize();
      } else {
        const result = await signIn.mfa.verifyEmailCode({ code: verificationCode.trim() });
        if (result.error) throw result.error;
        if (signIn.status !== "complete") {
          setError("Kod nie zakończył logowania. Sprawdź kod i spróbuj ponownie.");
          return;
        }
        await signIn.finalize();
      }
    } catch (cause) {
      setError(authErrorMessage(cause));
    } finally {
      setBusy(false);
    }
  };

  const resendCode = async () => {
    if (fetching) return;
    setBusy(true);
    setError("");
    try {
      if (step === "reset-code") await signIn.resetPasswordEmailCode.sendCode();
      else if (mode === "sign-up") await signUp.verifications.sendEmailCode();
      else await signIn.mfa.sendEmailCode();
    } catch (cause) {
      setError(authErrorMessage(cause));
    } finally {
      setBusy(false);
    }
  };

  const startPasswordReset = async () => {
    if (fetching || !emailAddress.trim()) {
      setError("Najpierw wpisz adres e-mail.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await signIn.create({ identifier: emailAddress.trim() });
      if (result.error) throw result.error;
      const sent = await signIn.resetPasswordEmailCode.sendCode();
      if (sent.error) throw sent.error;
      setPassword("");
      setVerificationCode("");
      setStep("reset-code");
    } catch (cause) {
      setError(authErrorMessage(cause));
    } finally {
      setBusy(false);
    }
  };

  const saveNewPassword = async () => {
    if (fetching || password.length < 1) return;
    setBusy(true);
    setError("");
    try {
      const result = await signIn.resetPasswordEmailCode.submitPassword({ password });
      if (result.error) throw result.error;
      if (signIn.status === "complete") await signIn.finalize();
      else setError("Hasło zostało zmienione, ale logowanie nie zostało zakończone. Wróć i zaloguj się nowym hasłem.");
    } catch (cause) {
      setError(authErrorMessage(cause));
    } finally {
      setBusy(false);
    }
  };

  const changeMode = (nextMode: AuthMode) => {
    setMode(nextMode);
    setStep("credentials");
    setVerificationCode("");
    setError("");
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + 24, paddingBottom: insets.bottom + 28 }]}
      bottomOffset={72}
      keyboardShouldPersistTaps="handled"
    >
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Image source={require("../assets/images/icon.png")} style={styles.logo} resizeMode="contain" />
        <Text style={[styles.eyebrow, { color: colors.primary }]}>SPIKE WORKSPACE</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>
          {step === "verification" || step === "reset-code"
            ? step === "reset-code" ? "Potwierdź kod" : "Sprawdź e-mail"
            : step === "reset-new-password" ? "Ustaw nowe hasło" : mode === "sign-in" ? "Witaj ponownie" : "Utwórz konto"}
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          {step === "verification" || step === "reset-code"
            ? `Wpisz kod wysłany na ${emailAddress.trim()}.`
            : step === "reset-new-password"
              ? "Ustaw nowe hasło do swojego konta."
            : mode === "sign-in"
              ? "Zaloguj się adresem e-mail i hasłem, aby otworzyć swoje projekty."
              : "Załóż konto przez e-mail. Dostęp do Spike nadal wymaga zatwierdzenia adresu przez administratora."}
        </Text>

        {error ? (
          <View accessibilityRole="alert" style={[styles.errorBox, { backgroundColor: colors.destructive + "18", borderColor: colors.destructive }]}>
            <Feather name="alert-circle" size={16} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
          </View>
        ) : null}

        {step === "verification" || step === "reset-code" ? (
          <>
            <Text style={[styles.label, { color: colors.foreground }]}>
              {step === "reset-code" ? "Kod zmiany hasła" : "Kod weryfikacyjny"}
            </Text>
            <TextInput
              accessibilityLabel="Kod weryfikacyjny"
              autoComplete="one-time-code"
              autoCapitalize="none"
              keyboardType="number-pad"
              maxLength={10}
              onChangeText={(value) => setVerificationCode(value.replace(/\s/g, ""))}
              onSubmitEditing={() => void verifyEmailCode()}
              placeholder={step === "reset-code" ? "Wpisz kod do zmiany hasła" : "Wpisz kod z wiadomości"}
              placeholderTextColor={colors.mutedForeground}
              returnKeyType="done"
              style={[styles.input, { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground }]}
              testID="native-auth-code"
              value={verificationCode}
            />
            <AuthButton
              busy={fetching}
              disabled={!verificationCode.trim()}
              label="Potwierdź kod"
              onPress={() => void verifyEmailCode()}
              colors={colors}
              testID="native-auth-verify"
            />
            <Pressable disabled={fetching} onPress={() => void resendCode()} style={styles.textButton}>
              <Text style={[styles.switchText, { color: colors.primary }]}>Wyślij kod ponownie</Text>
            </Pressable>
            <Pressable disabled={fetching} onPress={() => { setStep("credentials"); setVerificationCode(""); setError(""); }} style={styles.textButton}>
              <Text style={[styles.switchText, { color: colors.mutedForeground }]}>Wróć do danych logowania</Text>
            </Pressable>
          </>
        ) : step === "reset-new-password" ? (
          <>
            <Text style={[styles.label, { color: colors.foreground }]}>Nowe hasło</Text>
            <TextInput
              accessibilityLabel="Nowe hasło"
              autoComplete="new-password"
              autoCapitalize="none"
              onChangeText={setPassword}
              onSubmitEditing={() => void saveNewPassword()}
              placeholder="Wpisz nowe hasło"
              placeholderTextColor={colors.mutedForeground}
              returnKeyType="go"
              secureTextEntry
              style={[styles.input, { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground }]}
              testID="native-auth-new-password"
              textContentType="newPassword"
              value={password}
            />
            <AuthButton
              busy={fetching}
              disabled={!password}
              label="Zapisz nowe hasło"
              onPress={() => void saveNewPassword()}
              colors={colors}
              testID="native-auth-reset-password"
            />
          </>
        ) : (
          <>
            <Text style={[styles.label, { color: colors.foreground }]}>Adres e-mail</Text>
            <TextInput
              accessibilityLabel="Adres e-mail"
              autoComplete="email"
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              onChangeText={setEmailAddress}
              onSubmitEditing={() => void submitCredentials()}
              placeholder="nazwa@example.com"
              placeholderTextColor={colors.mutedForeground}
              returnKeyType="next"
              style={[styles.input, { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground }]}
              testID="native-auth-email"
              textContentType="emailAddress"
              value={emailAddress}
            />
            <Text style={[styles.label, { color: colors.foreground }]}>Hasło</Text>
            <TextInput
              accessibilityLabel="Hasło"
              autoComplete={mode === "sign-up" ? "new-password" : "current-password"}
              autoCapitalize="none"
              onChangeText={setPassword}
              onSubmitEditing={() => void submitCredentials()}
              placeholder="Wpisz hasło"
              placeholderTextColor={colors.mutedForeground}
              returnKeyType="go"
              secureTextEntry
              style={[styles.input, { backgroundColor: colors.input, borderColor: colors.border, color: colors.foreground }]}
              testID="native-auth-password"
              textContentType={mode === "sign-up" ? "newPassword" : "password"}
              value={password}
            />
            {mode === "sign-up" ? (
              <Text style={[styles.note, { color: colors.mutedForeground }]}>
                Potwierdzisz adres kodem e-mail. Administrator musi wcześniej przyznać temu adresowi dostęp do Spike.
              </Text>
            ) : null}
            <AuthButton
              busy={fetching}
              disabled={!emailAddress.trim() || !password}
              label={mode === "sign-in" ? "Zaloguj się" : "Utwórz konto"}
              onPress={() => void submitCredentials()}
              colors={colors}
              testID="native-auth-submit"
            />
            {mode === "sign-in" ? (
              <Pressable disabled={fetching} onPress={() => void startPasswordReset()} style={styles.textButton}>
                <Text style={[styles.switchText, { color: colors.mutedForeground }]}>Nie pamiętam hasła</Text>
              </Pressable>
            ) : null}
            <View style={styles.switchRow}>
              <Text style={[styles.note, { color: colors.mutedForeground }]}>
                {mode === "sign-in" ? "Nie masz jeszcze konta?" : "Masz już konto?"}
              </Text>
              <Pressable disabled={fetching} onPress={() => changeMode(mode === "sign-in" ? "sign-up" : "sign-in")} hitSlop={8}>
                <Text style={[styles.switchText, { color: colors.primary }]}>
                  {mode === "sign-in" ? "Utwórz konto" : "Zaloguj się"}
                </Text>
              </Pressable>
            </View>
          </>
        )}
        <View style={[styles.securityNote, { borderTopColor: colors.border }]}>
          <Feather name="shield" size={14} color={colors.mutedForeground} />
          <Text style={[styles.note, styles.securityText, { color: colors.mutedForeground }]}>
            Konto jest weryfikowane przez Spike. Sam wpisany adres e-mail nie nadaje dostępu.
          </Text>
        </View>
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

function AuthButton({
  busy,
  disabled,
  label,
  onPress,
  colors,
  testID,
}: {
  busy: boolean;
  disabled: boolean;
  label: string;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
  testID: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={busy || disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.submitButton,
        { backgroundColor: colors.primary, opacity: busy || disabled ? 0.55 : pressed ? 0.82 : 1 },
      ]}
      testID={testID}
    >
      {busy ? <ActivityIndicator color={colors.primaryForeground} /> : <Feather name="log-in" size={17} color={colors.primaryForeground} />}
      <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>{busy ? "Chwila…" : label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { flexGrow: 1, justifyContent: "center", paddingHorizontal: 20 },
  card: { width: "100%", maxWidth: 440, alignSelf: "center", alignItems: "stretch", borderWidth: 1, borderRadius: 22, padding: 24 },
  logo: { width: 62, height: 62, alignSelf: "center", marginBottom: 15 },
  eyebrow: { fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 1.6, textAlign: "center" },
  title: { fontFamily: "Inter_700Bold", fontSize: 25, textAlign: "center", marginTop: 9 },
  subtitle: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 20, textAlign: "center", marginTop: 8, marginBottom: 23 },
  label: { fontFamily: "Inter_500Medium", fontSize: 12, marginBottom: 7, marginTop: 12 },
  input: { minHeight: 49, borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, fontFamily: "Inter_400Regular", fontSize: 14 },
  submitButton: { minHeight: 50, width: "100%", borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingHorizontal: 14, marginTop: 20 },
  buttonText: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  note: { fontFamily: "Inter_400Regular", fontSize: 11, lineHeight: 17 },
  switchRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", flexWrap: "wrap", gap: 5, marginTop: 18 },
  switchText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  textButton: { alignSelf: "center", paddingHorizontal: 12, paddingVertical: 10 },
  securityNote: { borderTopWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 23, paddingTop: 16 },
  securityText: { flex: 1, textAlign: "center", marginTop: 0 },
  errorBox: { width: "100%", borderWidth: 1, borderRadius: 12, padding: 12, marginBottom: 8, flexDirection: "row", alignItems: "flex-start", gap: 8 },
  errorText: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 18 },
});
