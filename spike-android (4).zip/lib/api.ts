export function getServerOrigin(): string | null {
  const value = process.env.EXPO_PUBLIC_DOMAIN?.trim();
  if (!value) return null;
  try {
    const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
    if (url.protocol !== "https:" || url.username || url.password) return null;
    return url.origin;
  } catch {
    return null;
  }
}

export const SERVER_ORIGIN = getServerOrigin();

export type TokenGetter = () => Promise<string | null>;
export type Identity = { id: string; email: string; role: "owner" | "admin" | "member"; displayName: string };
export type Project = {
  id: string;
  name: string;
  description: string;
  template: string;
  status: string;
  createdAt: string;
  updatedAt: string;
};
export type ProjectInputTemplate = "blank" | "web" | "typescript";
export type ProjectFile = {
  id: string;
  projectId: string;
  path: string;
  kind: "file" | "folder";
  content: string;
  version: number;
  updatedAt: string;
};
export type FileInput = { path: string; kind: "file" | "folder"; content?: string };
export type FileUpdate = { path?: string; content?: string; version: number };

let nativeTokenGetter: TokenGetter | null = null;

export function setNativeAuthTokenGetter(getToken: TokenGetter | null) {
  nativeTokenGetter = getToken;
}

export async function apiRequest<T>(
  path: string,
  init: RequestInit = {},
): Promise<T> {
  if (!SERVER_ORIGIN) throw new Error("Brak adresu serwera Spike.");
  const getToken = nativeTokenGetter;
  if (!getToken) {
    throw Object.assign(new Error("Sesja logowania nie jest jeszcze gotowa. Spróbuj ponownie."), { status: 401 });
  }
  const token = await getToken();
  if (!token) {
    throw Object.assign(new Error("Nie udało się pobrać sesji logowania. Zaloguj się ponownie."), { status: 401 });
  }
  const headers = new Headers(init.headers);
  headers.set("Accept", "application/json");
  headers.set("Authorization", `Bearer ${token}`);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");

  const response = await fetch(`${SERVER_ORIGIN}${path}`, { ...init, headers });
  const text = await response.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }
  if (!response.ok) {
    const message =
      data && typeof data === "object" && "error" in data && typeof data.error === "string"
        ? data.error
        : `Błąd serwera (${response.status}).`;
    throw Object.assign(new Error(message), { status: response.status });
  }
  return data as T;
}

export const getMe = (init?: RequestInit) => apiRequest<Identity>("/api/me", init);
export const listProjects = () => apiRequest<Project[]>("/api/projects");
export const createProject = (input: { name: string; description?: string; template: ProjectInputTemplate }) =>
  apiRequest<Project>("/api/projects", { method: "POST", body: JSON.stringify(input) });
export const renameProject = (id: string, input: { name: string }) =>
  apiRequest<Project>(`/api/projects/${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify(input) });
export const deleteProject = (id: string) =>
  apiRequest<void>(`/api/projects/${encodeURIComponent(id)}`, { method: "DELETE" });
export const listFiles = (projectId: string) =>
  apiRequest<ProjectFile[]>(`/api/projects/${encodeURIComponent(projectId)}/files`);
export const createFile = (projectId: string, input: FileInput) =>
  apiRequest<ProjectFile>(`/api/projects/${encodeURIComponent(projectId)}/files`, { method: "POST", body: JSON.stringify(input) });
export const updateFile = (projectId: string, fileId: string, input: FileUpdate) =>
  apiRequest<ProjectFile>(`/api/projects/${encodeURIComponent(projectId)}/files/${encodeURIComponent(fileId)}`, { method: "PATCH", body: JSON.stringify(input) });
export const deleteFile = (projectId: string, fileId: string) =>
  apiRequest<void>(`/api/projects/${encodeURIComponent(projectId)}/files/${encodeURIComponent(fileId)}`, { method: "DELETE" });
