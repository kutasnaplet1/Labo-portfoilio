import NativeSpikeApp from "../components/NativeSpikeApp";

export default function IndexScreen() {
  return <NativeSpikeApp />;
}
