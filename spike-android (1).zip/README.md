# Spike na Androida

To jest instalowalna aplikacja Android oparta na Expo i natywnym `WebView`.
Nie jest to osobny, ręcznie przepisany interfejs IDE: otwiera opublikowaną
stronę Spike w aplikacji, więc korzysta z jej logowania, projektów, API i
zapisanych danych.

## Budowanie APK przez GitHub Actions

1. Rozpakuj zawartość ZIP-a do głównego katalogu repozytorium GitHub.
2. Wypchnij pliki na gałąź `main`.
3. Otwórz **Actions → Build APK → Run workflow**.
4. Po zakończeniu pobierz artefakt `spike-android-apk`. Zawiera on
   `spike-android.apk`.

Workflow jest w `.github/workflows/build-apk.yml`. Nie wymaga klucza API ani
innych sekretów do samego zbudowania. Adres opublikowanego serwera jest ustawiany w workflow jako
`EXPO_PUBLIC_DOMAIN`. Jeśli domena Spike się zmieni, zaktualizuj tę wartość.

## Podpis APK i ostrzeżenia Androida

Workflow obsługuje trwały podpis wydania, który pomaga utrzymać tę samą
tożsamość aplikacji przy kolejnych aktualizacjach. W ustawieniach repozytorium
GitHub dodaj sekrety Actions:

- `ANDROID_KEYSTORE_BASE64` — plik klucza JKS zakodowany jako Base64
- `ANDROID_KEYSTORE_PASSWORD` — hasło magazynu
- `ANDROID_KEY_ALIAS` — alias klucza
- `ANDROID_KEY_PASSWORD` — hasło klucza

Wygeneruj własny klucz poleceniem `keytool -genkeypair -v -keystore
spike-release.jks -alias spike -keyalg RSA -keysize 2048 -validity 10000`,
a plik zakoduj do Base64 lokalnie. Nie dodawaj klucza ani haseł do repozytorium
lub ZIP-a. Bez tych sekretów workflow nadal tworzy APK testowe podpisane
kluczem debug — może wtedy pojawić się ostrzeżenie przy instalacji. Podpis nie
gwarantuje, że Play Protect nie pokaże ostrzeżenia dla aplikacji instalowanej
spoza Google Play; nie da się tego bezpiecznie wyłączyć z poziomu aplikacji.

## Logowanie

Aplikacja korzysta z tej samej strony Spike i tego samego logowania Clerk.
Logowanie musi być dozwolone w osadzonym Android WebView przez konfigurację
Clerk. Jeżeli ekran logowania zgłosi blokadę osadzonej przeglądarki, trzeba
włączyć obsługę logowania w aplikacjach natywnych/WebView po stronie
konfiguracji dostawcy. Kod aplikacji nie obchodzi ani nie osłabia kontroli
dostępu.

## Ustawienia

- Nazwa aplikacji: `Spike`
- Identyfikator Androida: `com.labo17dev.spike`
- Wersja początkowa: `1.0.0` (kod wersji `1`)
- Ikona korzysta z postaci Spike z projektu.

APK nie jest dołączony do ZIP-a — workflow tworzy go przy każdym uruchomieniu.
